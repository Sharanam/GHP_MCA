# calculate the Gini Impurity for a dataset
from math import log2

def calculate_mean_gini(class_value_counts_list):
    class_probabilities_list = [ [ x / sum(value_counts) for x in value_counts ] for value_counts in class_value_counts_list ]
    data_point_count = 0
    for class_value_count in class_value_counts_list:
        data_point_count = data_point_count + sum(class_value_count)
    print('data_point_count={0}'.format(data_point_count))
    print('class probabilities={0}'.format(class_probabilities_list))

    # calculate gini
    weighted_mean_gini = 0
    for i in range(len(class_probabilities_list)):
        class_probabilities = class_probabilities_list[i]
        print('List[{0}] = {1}'.format(i, class_value_counts_list[i]))
        gini = 0
        for probability in class_probabilities:
            gini = gini + (probability * probability)
        gini = 1 - gini
        print('{0:.5f}'.format(gini))
        weighted_mean_gini = weighted_mean_gini + gini * sum(class_value_counts_list[i]) / data_point_count
    return weighted_mean_gini


class_value_counts_list = [ [ 2, 2 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_gini_1 = calculate_mean_gini(class_value_counts_list)
print('mean gini: {0:.5f} '.format(mean_gini_1))
print('---------------------------------')
print()
print('Splitting on X:')
class_value_counts_list = [ [ 0, 1 ], [ 2, 1 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_gini_2 = calculate_mean_gini(class_value_counts_list)
print('weighted mean gini: {0:.5f} '.format(mean_gini_2))
print('---------------------------------')
print()
print('Splitting on Y:')
class_value_counts_list = [ [ 0, 2 ], [ 2, 0 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_gini_2 = calculate_mean_gini(class_value_counts_list)
print('weighted mean gini: {0:.5f} '.format(mean_gini_2))
print('---------------------------------')
print()
print('Splitting on Z:')
class_value_counts_list = [ [ 1, 1 ], [ 1, 1 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_gini_2 = calculate_mean_gini(class_value_counts_list)
print('weighted mean gini: {0:.5f} '.format(mean_gini_2))
print('---------------------------------')
print()

