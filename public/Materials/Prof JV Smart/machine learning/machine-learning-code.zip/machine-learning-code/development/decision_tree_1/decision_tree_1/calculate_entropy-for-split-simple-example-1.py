# calculate the entropy for a dataset
from math import log2

def calculate_mean_entropy(class_value_counts_list):
    class_probabilities_list = [ [ x / sum(value_counts) for x in value_counts ] for value_counts in class_value_counts_list ]
    data_point_count = 0
    for class_value_count in class_value_counts_list:
        data_point_count = data_point_count + sum(class_value_count)
    print('data_point_count={0}'.format(data_point_count))
    print('class probabilities={0}'.format(class_probabilities_list))

    # calculate entropy
    weighted_mean_entropy = 0
    for i in range(len(class_probabilities_list)):
        class_probabilities = class_probabilities_list[i]
        print('List[{0}] = {1}'.format(i, class_value_counts_list[i]))
        entropy = 0
        for probability in class_probabilities:
            if probability > 0:
                entropy = entropy - ( probability * log2(probability) )
        print('{0:.5f}'.format(entropy))
        weighted_mean_entropy = weighted_mean_entropy + entropy * sum(class_value_counts_list[i]) / data_point_count
    return weighted_mean_entropy


class_value_counts_list = [ [ 2, 2 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_entropy_1 = calculate_mean_entropy(class_value_counts_list)
print('mean entropy: {0:.5f} bits'.format(mean_entropy_1))
print('---------------------------------')
print()
print('Splitting on X:')
class_value_counts_list = [ [ 0, 1 ], [ 2, 1 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_entropy_2 = calculate_mean_entropy(class_value_counts_list)
print('weighted mean entropy: {0:.5f} bits'.format(mean_entropy_2))
print('Information Gain={0:.5f} bits'.format(mean_entropy_1 - mean_entropy_2))
print('---------------------------------')
print()
print('Splitting on Y:')
class_value_counts_list = [ [ 0, 2 ], [ 2, 0 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_entropy_2 = calculate_mean_entropy(class_value_counts_list)
print('weighted mean entropy: {0:.5f} bits'.format(mean_entropy_2))
print('Information Gain={0:.5f} bits'.format(mean_entropy_1 - mean_entropy_2))
print('---------------------------------')
print()
print('Splitting on Z:')
class_value_counts_list = [ [ 1, 1 ], [ 1, 1 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_entropy_2 = calculate_mean_entropy(class_value_counts_list)
print('weighted mean entropy: {0:.5f} bits'.format(mean_entropy_2))
print('Information Gain={0:.5f} bits'.format(mean_entropy_1 - mean_entropy_2))
print('---------------------------------')
print()

