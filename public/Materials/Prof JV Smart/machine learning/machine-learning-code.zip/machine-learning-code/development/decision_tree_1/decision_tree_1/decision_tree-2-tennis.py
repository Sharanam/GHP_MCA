# importing libraries
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

from colors import *

#importing datasets
data_set= pd.read_csv('tennis-coded.csv')

#Extracting Independent and dependent Variable
x= data_set.iloc[:, [1, 2, 3, 4]].values
y= data_set.iloc[:, 5].values
print(x)
print(y)

# Splitting the dataset into training and test set.
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test= train_test_split(x, y, test_size= 0.25, random_state=0)

#feature Scaling
from sklearn.preprocessing import StandardScaler

#st_x= StandardScaler()
#x_train= st_x.fit_transform(x_train)
#x_test= st_x.transform(x_test)

# Fitting Decision Tree classifier to the training set
from sklearn.tree import DecisionTreeClassifier
classifier= DecisionTreeClassifier(criterion='entropy', random_state=0,
##                max_depth=2,
#            ccp_alpha = 0.1,
##                min_samples_split = 8,
##                max_leaf_nodes=10
            )
classifier.fit(x_train, y_train)
#print(classifier)
print(classifier.get_params())

from sklearn import tree
feature_names = [ 'Outlook', 'Temp', 'Humidity', 'Wind' ]
class_names = [ 'Do not play tennis', 'Play tennis' ]

text_representation = tree.export_text(classifier, feature_names=feature_names)
print(text_representation)

tree.export_graphviz(classifier, out_file="decision_tree-2.dot",  
                     feature_names=feature_names ,  
                     class_names=True)

# Figure size is in inches
#plt.figure(1, figsize=(7,7))
plt.figure(1)
_ = tree.plot_tree(classifier,
               feature_names=feature_names,
               class_names=class_names,
#                   fontsize = 10,
               filled=True)
# Rasterized output
#plt.savefig('Decision_Tree-2.png', bbox_inches='tight')
# Vector output
#plt.savefig('Decision_Tree-2.pdf', bbox_inches='tight')
plt.savefig('Decision_Tree-2.svg', bbox_inches='tight')
#plt.savefig('Decision_Tree-2.svg')
#plt.show()

#import graphviz
## DOT data
#dot_data = tree.export_graphviz(classifier, out_file=None,
#                                feature_names=feature_names,
#                                class_names=class_names,
#                                filled=True)
## Draw graph
#graph = graphviz.Source(dot_data, format="png")
#graph.view()

# Predicting the test set result
y_pred = classifier.predict(x_test)

#print(feature_names)
#print(x_test)
#print(y_test)
#print(y_pred)
for i in range(4):
    print('Outlook={0}, Temp={1}, Humidity={2}, Wind={3}: Prediction={4}, Actual={5}'.format(
        x_test[i][0], x_test[i][1], x_test[i][2], x_test[i][3], y_pred[i], y_test[i]))

for i in range(len(y_test)):
    if (i%10) == 0:
        print()
    output_data = '[{0} {1}], '.format(y_pred[i], y_test[i])
    if y_pred[i] == y_test[i]:
        print(color(output_data, fg='green'), end='')
    elif y_pred[i] == 1:
        print(color(output_data, fg='red'), end='')
    else:
        print(color(output_data, fg='orange'), end='')
print()

from sklearn import metrics
print('Accuracy Score:', metrics.accuracy_score(y_test,y_pred))

# Creating the Confusion matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
print('Confussion Matrix:')
print(cm)

# Visualising the Decision Tree Classifier results

x_data = np.linspace(0, len(y_test), len(y_test))
y_data = [ x_data[i]+(y_pred[i]-y_test[i])*3 for i in range(len(y_test)) ]
#print(x_data)
#print(y_data)
#print(len(x_data), len(y_data))
plt.figure(2)
plt.scatter(x_data, y_data, color = 'blue')
plt.title('Decision Tree Classification Example')

plt.show()

plt.figure(3)

##Visulaizing the trianing set result
#from matplotlib.colors import ListedColormap
#x_set, y_set = x_train, y_train
#x1, x2 = np.meshgrid(np.arange(start = x_set[:, 0].min() - 1, stop = x_set[:, 0].max() + 1, step  =0.01),
#np.arange(start = x_set[:, 1].min() - 1, stop = x_set[:, 1].max() + 1, step = 0.01))
#plt.contourf(x1, x2, classifier.predict(np.array([x1.ravel(), x2.ravel()]).T).reshape(x1.shape),
#                                alpha = 0.75, cmap = ListedColormap(('purple','green' )))
#plt.xlim(x1.min(), x1.max())
#plt.ylim(x2.min(), x2.max())
#for i, j in enumerate(np.unique(y_set)):
#    plt.scatter(x_set[y_set == j, 0], x_set[y_set == j, 1],
#        c = ListedColormap(('purple', 'green'))(i), label = j)
#plt.title('Decision Tree Algorithm (Training set)')
#plt.xlabel('Age')
#plt.ylabel('Estimated Salary')
#plt.legend()
#plt.show()

##Visulaizing the test set result
#from matplotlib.colors import ListedColormap
#x_set, y_set = x_test, y_test
#x1, x2 = np.meshgrid(np.arange(start = x_set[:, 0].min() - 1, stop = x_set[:, 0].max() + 1, step  =0.01),
#np.arange(start = x_set[:, 1].min() - 1, stop = x_set[:, 1].max() + 1, step = 0.01))
#plt.contourf(x1, x2, classifier.predict(np.array([x1.ravel(), x2.ravel()]).T).reshape(x1.shape),
#alpha = 0.75, cmap = ListedColormap(('purple','green' )))
#plt.xlim(x1.min(), x1.max())
#plt.ylim(x2.min(), x2.max())
#for i, j in enumerate(np.unique(y_set)):
#    plt.scatter(x_set[y_set == j, 0], x_set[y_set == j, 1],
#        c = ListedColormap(('purple', 'green'))(i), label = j)
#plt.title('Decision Tree Algorithm(Test set)')
#plt.xlabel('Age')
#plt.ylabel('Estimated Salary')
#plt.legend()
#plt.show()

