# calculate the Gini Impurity for a dataset
from math import log2

def calculate_mean_gini(class_value_counts_list):
    class_probabilities_list = [ [ x / sum(value_counts) for x in value_counts ] for value_counts in class_value_counts_list ]
    data_point_count = 0
    for class_value_count in class_value_counts_list:
        data_point_count = data_point_count + sum(class_value_count)
    print('data_point_count={0}'.format(data_point_count))
    print('class probabilities={0}'.format(class_probabilities_list))

    # calculate gini
    weighted_mean_gini = 0
    for i in range(len(class_probabilities_list)):
        class_probabilities = class_probabilities_list[i]
        print('List[{0}] = {1}'.format(i, class_value_counts_list[i]))
        gini = 0
        for probability in class_probabilities:
            gini = gini + (probability * probability)
        gini = 1 - gini
        print('{0:.5f}'.format(gini))
        weighted_mean_gini = weighted_mean_gini + gini * sum(class_value_counts_list[i]) / data_point_count
    return weighted_mean_gini


class_value_counts_list = [ [ 6, 4 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_gini_1 = calculate_mean_gini(class_value_counts_list)
print('mean gini: {0:.5f} '.format(mean_gini_1))
print('---------------------------------')
print()
print('Splitting on Past Trend:')
print('Negative, Positive')
class_value_counts_list = [ [ 4, 0 ], [ 2, 4 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_gini_2 = calculate_mean_gini(class_value_counts_list)
print('weighted mean gini: {0:.5f} '.format(mean_gini_2))
print('---------------------------------')
print()
print('Splitting on Open Interest:')
print('Low, High')
class_value_counts_list = [ [ 4, 2 ], [ 2, 2 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_gini_2 = calculate_mean_gini(class_value_counts_list)
print('weighted mean gini: {0:.5f} '.format(mean_gini_2))
print('---------------------------------')
print()
print('Splitting on Trading Volume:')
print('Low, High')
class_value_counts_list = [ [ 3, 0 ], [ 3, 4 ] ]
print('class value counts={0}'.format(class_value_counts_list))
mean_gini_2 = calculate_mean_gini(class_value_counts_list)
print('weighted mean gini: {0:.5f} '.format(mean_gini_2))
print('---------------------------------')
print()

