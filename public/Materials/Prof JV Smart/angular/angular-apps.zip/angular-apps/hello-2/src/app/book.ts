export interface Book {
  bookCode: string;
  bookTitle: string;
  edition: number;
  isAvailable: boolean;

}
