export class Book {
  bookCode: string = "ANG001";
  bookTitle: string = "Introduction to Angular 16 Development";
  bookEdition: number = 2;
  bookIsIssued: boolean = true;
}
