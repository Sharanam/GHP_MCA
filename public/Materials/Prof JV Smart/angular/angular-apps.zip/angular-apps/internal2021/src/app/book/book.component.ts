import { Component, OnInit } from '@angular/core';
import { Book } from '../book';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  book: Book;
  userName: string = '';

  issueBook() {
    if (this.userName.length > 0) {
      this.book.issuedTo = this.userName;
      this.book.isAvailable = false;
    }
  }

  returnBook() {
    this.book.issuedTo = '';
    this.book.isAvailable = true;
  }

  constructor() {
    this.book = {
      bookNo: 101,
      title: 'Abc',
      authors: 'pqr, lmn',
      isAvailable: true,
      issuedTo: ''
    };
   }

  ngOnInit() {
  }

}
