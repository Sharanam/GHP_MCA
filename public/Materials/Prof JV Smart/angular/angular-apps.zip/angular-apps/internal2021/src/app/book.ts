export interface Book {
  bookNo: number,
  title: string,
  authors: string,
  isAvailable: boolean,
  issuedTo: string
}
