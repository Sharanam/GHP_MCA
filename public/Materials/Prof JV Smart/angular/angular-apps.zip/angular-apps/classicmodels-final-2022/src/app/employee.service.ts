import { MessageService } from './message.service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, of, tap, map } from 'rxjs';
import { Employee } from './Employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  // employeesDirectoryUrl = 'http://localhost:8080/employees';
  employeesDirectoryUrl = "http://localhost/ClassicModelsCodeIgniter/employee";
  appUrl: string = 'http://localhost/ClassicModelsCodeIgniter/employee';

  getEmployees(): Observable<Employee[]> {
    // Display message in browser's developer tools console
    // Use launch configuration in launch.json to attach
    // to the browser's debug interface
    // console.log('getEmployees() called...');
    this.messageService.log('getEmployees() called...');
    return this.http.get<Employee[]>(this.employeesDirectoryUrl).pipe(
      tap(_ => {
        // console.log('fetched data:\n' + JSON.stringify(_).substr(0, 40) + '...');
        this.messageService.log('fetched data:\n' + JSON.stringify(_).substr(0, 40) + '...');
        // Use when th web service returns an array
        // console.log('rowCount=' + _.length);
        // this.messageService.log('rowCount=' + _.length);
      }),
      //      tap(_ => this.log('fetched data:\n' + JSON.stringify(_, null, 4))),

      // Use the mapping if the web service returns the array inside an object
      // The following DOES NOT work, "this" is not available in map
      // map(this.mapGetResponse),
      map((response) => this.mapResponseToArray(response)),
      catchError(this.handleError<Employee[]>('getEmployees', []))
    );
  }


  public getEmployeeByNumber(employeeNumber: number): Observable<Employee> {
    // console.log("getEmployees() called...");
    this.messageService.log("getEmployeeByNumber(" +
                              employeeNumber + ") called...");
    return this.http.get<Employee>(this.appUrl + "/" +
    employeeNumber).pipe(
      tap(_ => {
        // console.log('fetched data:\n' + JSON.stringify(_).substr(0, 40) + '...');
        this.messageService.log('fetched data:\n' + JSON.stringify(_).substr(0, 40) + '...');
        // this.messageService.log('rowCount=' + _.length);
      }),
      // No need to map, web service returns employee object only
      // The following DOES NOT work, "this" is not available in map
      // map(this.mapGetResponse),
      // map(response => this.mapGetResponse(response)),
      catchError(this.handleError<Employee>('getEmployeeByNumber', undefined))
    );
  }


  public addEmployee(employee: Employee): Observable<string> {
    // console.log("getEmployees() called...");
    this.messageService.log("addEmployee(" + employee +
     ") called...");
    return this.http.post<string>(this.appUrl, employee).pipe(
      tap(_ => {
        // console.log('fetched data:\n' + JSON.stringify(_).substr(0, 40) + '...');
        this.messageService.log('fetched data:\n' + JSON.stringify(_).substr(0, 40) + '...');
        // this.messageService.log('rowCount=' + _.length);
      }),
      // The following DOES NOT work, "this" is not available in map
      // map(this.mapGetResponse),
      // map(response => this.mapGetResponse(response)),
      catchError(this.handleError<string>('addEmployee', 'Error'))
    );
  }


  updateEmployee(employee: Employee): Observable<string> {
    // Display message in browser's developer tools console
    // Use launch configuration in launch.json to attach
    // to the browser's debug interface
    // console.log('updateEmployees() called...');
    let employeeNumber: number = employee.employeeNumber;
    this.messageService.log('updateEmployee(' + employeeNumber + ') called...');
    return this.http.put<string>(
          this.employeesDirectoryUrl + '/' + employeeNumber, employee)
          .pipe(
      tap(_ => this.messageService.log('fetched data:\n' +
              JSON.stringify(_).substr(0, 150) + '...')),
      //      tap(_ => this.log('fetched data:\n' + JSON.stringify(_, null, 4))),
      // The following DOES NOT work, "this" is not available in map
      // map(this.extractResponse),
      map(response => this.mapResponseToMessage(response)),
      catchError(this.handleError<string>('updateEmployees', 'Error'))
    );
  }

  deleteEmployee(employeeNumber: number): Observable<string> {
    // Display message in browser's developer tools console
    // Use launch configuration in launch.json to attach
    // to the browser's debug interface
    // console.log('updateEmployees() called...');
    this.messageService.log('deleteEmployee(' + employeeNumber + ') called...');
    return this.http.delete<string>(
          this.employeesDirectoryUrl + '/' + employeeNumber)
          .pipe(
      tap(_ => this.messageService.log('fetched data:\n' +
              JSON.stringify(_).substr(0, 150) + '...')),
      //      tap(_ => this.log('fetched data:\n' + JSON.stringify(_, null, 4))),
      // The following DOES NOT work, "this" is not available in map
      // map(this.extractResponse),
      map(response => this.mapResponseToMessage(response)),
      catchError(this.handleError<string>('deleteEmployees', 'Error'))
    );
  }


  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      // console.error(error); // log to console instead
      this.messageService.log('error:' + JSON.stringify(error));

      // TODO: better job of transforming error for user consumption
      // console.log(`${operation} failed: ${error.message}`);
      this.messageService.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }


  mapResponseToArray(response: any, thisArg?: any) {
    // console.log('this.messageService: ' + this.messageService);
    // this.messageService.log('response: ' + JSON.stringify(response));
    // console.log('response: ' + JSON.stringify(response).substr(0, 40) + '...');
    this.messageService.log('response: ' + JSON.stringify(response).substr(0, 40) + '...');
    let body = response['employees'];
    // console.log('body: ' + JSON.stringify(body));
    // this.messageService.log('body: ' + JSON.stringify(body));
    // console.log('body: ' + JSON.stringify(body).substr(0, 40) + '...');
    this.messageService.log('body: ' + JSON.stringify(body).substr(0, 40) + '...');
    // console.log('rowCount=' + body.length);
    this.messageService.log('rowCount=' + body.length);
    return body || [];
  }


  mapResponseToMessage(response: any, thisArg?: any) {
    let errorMessage = '';
    let message = '';
    // console.log('this.messageService: ' + this.messageService);
    // this.messageService.log('response: ' + JSON.stringify(response));
    // console.log('response: ' + JSON.stringify(response).substr(0, 40) + '...');
    this.messageService.log('response: ' + JSON.stringify(response).substr(0, 40) + '...');
    if ('error' in response) {
      errorMessage = response['error'];
      if (errorMessage != null) {
        // console.log('ERROR: ' + errorMessage);
        this.messageService.log('ERROR: ' + errorMessage);
      }
    }
    if ('messages' in response) {
      let messages = response['messages'];
      if ('message' in messages) {
        message = messages['message'];
        if (message != null) {
          // console.log('Mapped message: ' + message);
          this.messageService.log('Mapped message: ' + message);
        }
      }
    }
    if (errorMessage != null)
      return errorMessage;
    else if (message != null)
      return message;
    else
      return '';
  }

  constructor(private http: HttpClient,
    private messageService: MessageService) {
  }
}
