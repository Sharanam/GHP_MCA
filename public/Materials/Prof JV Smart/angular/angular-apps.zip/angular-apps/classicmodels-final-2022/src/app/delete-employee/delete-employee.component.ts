import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { EmployeeService } from '../employee.service';
import { MessageService } from '../message.service';

@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.css']
})
export class DeleteEmployeeComponent implements OnInit {

  employeeNumber: number = -1;

  constructor(  private messageService: MessageService,
                private employeeService: EmployeeService,
                private route: ActivatedRoute,
                private router: Router) {
    let id: string | null = route.snapshot.paramMap.get('id');
    if (id != null) {
      this.employeeNumber = parseInt(id);
    }
  }


  ngOnInit() {
    let subscription: Subscription = new Subscription();
    subscription.add(this.employeeService.deleteEmployee(this.employeeNumber)
    .subscribe(message => { this.messageService.log('Subscription returned:' + message);
                            this.employeeService.getEmployees().subscribe();
                            this.router.navigate(['/employees']);
  }));
  }

}
