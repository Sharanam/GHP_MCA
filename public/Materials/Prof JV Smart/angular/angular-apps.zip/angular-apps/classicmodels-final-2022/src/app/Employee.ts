export interface Employee {
  employeeNumber: number;
  lastName: string;
  firstName: string;
  extension: string;
  email: string;
  officeCode: number;
  reportsTo: number|null;
  jobTitle: string;
}
