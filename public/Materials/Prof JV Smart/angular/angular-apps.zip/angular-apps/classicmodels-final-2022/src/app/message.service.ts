import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MessageService {

  messages: string[] = [];

  getMessages(): string[] {
    return this.messages;
  }

  clearMessages() {
    console.log('MessageService clearMessages()')
    // Creates a new array, Angular continues to use old reference somewhere
    // this.messages = [];
    while(this.messages.length > 0) {
      this.messages.pop();
    }
    // this.messages.splice(0, this.messages.length);
  }

  log(message: string) {
    this.messages.push(message);
    // console.log('message.constructor.name: ' + message.constructor.name);
    // let x = message.toString();
    // console.log(x);
    console.log(message);
  }

constructor() { }

}
