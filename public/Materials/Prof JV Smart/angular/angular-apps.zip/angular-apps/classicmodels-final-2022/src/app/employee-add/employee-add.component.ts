import { EmployeeService } from '../employee.service';
import { MessageService } from '../message.service';
import { Employee } from './../Employee';
import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {

  employee: Employee;
  message: string = '';

  addEmployee() {
    this.messageService.log(JSON.stringify(this.employee, null, 4));
    let subscription: Subscription = new Subscription();
    subscription.add(this.employeeService.addEmployee(this.employee)
              .subscribe(message => {
                this.message = JSON.stringify(message);
                this.messageService.log(message);
                // this.router.navigate(['employees'])
              }));
  }

  goBack(): void {
    this.location.back();
  }

  constructor(private messageService: MessageService,
                private employeeService: EmployeeService,
                private location: Location,
                private router: Router) {
    // In TypeScript, type compatibility is
    // solely based on their members
    this.messageService.log('In EmployeeAddComponent constructor...');
    this.employee = {
      employeeNumber: 0,
      lastName: '',
      firstName: '',
      extension: '',
      email: '',
      officeCode: 0,
      reportsTo: null,
      jobTitle: ''
    };
  }

  ngOnInit() {
  }

}
