import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { Employee } from '../Employee';
import { EmployeeService } from '../employee.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  private subscription: Subscription = new Subscription();

  employee: Employee | null = null;

  goBack(): void {
    this.location.back();
  }

  constructor(private employeesService: EmployeeService,
    private location: Location,
    private route: ActivatedRoute) { }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    if (id != null) {
      let employeeNumber: number = parseInt(id);
      this.subscription.add(this.employeesService
        .getEmployeeByNumber(employeeNumber)
        .subscribe(employee => {
          this.employee = employee;
        }));
    }

  }

}
