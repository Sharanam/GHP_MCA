import { Router } from '@angular/router';
import { MessageService } from './../message.service';
import { Observable, Subscription } from 'rxjs';
import { EmployeeService } from './../employee.service';
import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  employees$ : Observable<Employee[]>;
  employeesList : Employee[] = [];

  public showEmployee(employeeNumber: number) {
    this.router.navigate(['/employees/' + employeeNumber]);
  }

  public updateEmployee(employeeNumber: number) {
    this.router.navigate(['/employees/update/' + employeeNumber]);
  }

  public deleteEmployee(employeeNumber: number) {
    if (confirm("Are you sure you want to delete employee number " + employeeNumber + "?"))
      this.router.navigate(['/employees/delete/' + employeeNumber]);
  }

  public addEmployee() {
    this.messageService.log('navigating to /employees/add/new ...');
    this.router.navigate(['/employees/add/new']);
  }

  constructor(private employeeService: EmployeeService,
              private messageService: MessageService,
              private router: Router) {
    this.employees$ = employeeService.getEmployees();
    let subscription : Subscription = new Subscription();
    subscription.add(this.employees$.subscribe(employees => {
      // console.log('Data from server...\n' + JSON.stringify(employees));
      // this.messageService.log('Data from server...\n' + JSON.stringify(employees));
      // console.log('Data from server...\n' + JSON.stringify(employees).substring(0, 40) + '...');
      this.messageService.log('Mapped data from server...\n' + JSON.stringify(employees).substring(0, 40) + '...');
      this.employeesList = employees;
    }));
   }

  ngOnInit() {
  }

}
