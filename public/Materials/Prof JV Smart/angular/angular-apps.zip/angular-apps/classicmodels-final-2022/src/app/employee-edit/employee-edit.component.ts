import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Employee } from '../Employee';
import { EmployeeService } from '../employee.service';
import { MessageService } from '../message.service';

@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrls: ['./employee-edit.component.css']
})
export class EmployeeEditComponent implements OnInit {

  employee: Employee | null = null;
  employeeNumber: number = -1;
  message: string = '';

  updateEmployee(employee: Employee) {
    this.messageService.log(JSON.stringify(employee, null, 4));
    if (this.employee != null) {
      let subscription: Subscription = new Subscription();
      subscription.add(this.employeeService.updateEmployee(employee)
              .subscribe(message => {
                this.message = message;
                this.messageService.log(message);
                this.router.navigate(['/employees']);
              }));
    }
  }

  constructor(private messageService: MessageService,
                private employeeService: EmployeeService,
                private route: ActivatedRoute,
                private router: Router) {
    let id: string | null = route.snapshot.paramMap.get('id');
    if (id != null) {
      this.employeeNumber = parseInt(id);
    }
  }

  ngOnInit() {
    let subscription: Subscription = new Subscription();
    subscription.add(this.employeeService.getEmployeeByNumber(this.employeeNumber)
    .subscribe(employee => {this.employee = employee;}));
  }

}
