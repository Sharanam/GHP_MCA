import { Component, OnInit } from '@angular/core';
import { Book } from '../Book';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  book: Book;
  userName: string;

  issueBook() {
    this.book.issuedTo = this.userName;
    this.book.isAvailable = false;
  }

  returnBook() {
    this.book.issuedTo = '';
    this.book.isAvailable = true;
  }

  constructor() {
    this.book = {
      bookNo: 101,
      title: 'Learning Angular Development',
      authors: 'Abc, Xyz',
      isAvailable: true,
      issuedTo: ''
    };
    this.userName = '';
   }

  ngOnInit(): void {
  }

}
