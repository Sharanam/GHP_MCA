import { Component, OnInit } from '@angular/core';
import { Hero } from '../hero';
import { HEROES } from '../mock-heroes';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css']
})
export class HeroesComponent implements OnInit {


  heroes:Hero[] = HEROES;

  selectedHero?: Hero;

  isDisabled:boolean = true;

  toggleEnabled() {
      if (this.isDisabled)
        this.isDisabled = false;
        else
        this.isDisabled = true;
  }

  onSelect(hero: Hero): void {
    this.selectedHero = hero;
  }

  constructor() { }

  ngOnInit() {
  }

}
