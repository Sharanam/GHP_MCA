export interface Student {
  rollNo: number,
  name: string,
  programme: string,
  semester: number,
  gpa: number
}
