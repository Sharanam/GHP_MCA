import { Component } from '@angular/core';
import { Student } from './student';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'Student Result';
  student : Student;
  result: string;
  resultBackgroundColor: string;

  marksChanged(newValue:number) {
    console.log('newValue=' + newValue);
    if (newValue < 4) {
      this.result = "Dropped - F";
      this.resultBackgroundColor = "red";
    } else if (newValue < 5) {
      this.result = "Pass Class with E";
      this.resultBackgroundColor = "orange";
    }else if (newValue < 6) {
      this.result = "Second Class with D";
      this.resultBackgroundColor = "blue";
    } else if (newValue < 7) {
      this.result = "First Class with C";
      this.resultBackgroundColor = "green";
    } else if (newValue < 8) {
      this.result = "First Class with B";
      this.resultBackgroundColor = "green";
    } else if (newValue < 9) {
      this.result = "First Class with A";
      this.resultBackgroundColor = "green";
    } else {
      this.result = "First Class with O";
      this.resultBackgroundColor = "green";
    }
  }

  constructor() {
    this.student = {
      rollNo: 101,
      name: "Abc",
      programme: "MCA",
      semester: 3,
      gpa: 7.5
    };
    this.result = 'First Class with B';
    this.resultBackgroundColor = 'green';
  }
}
