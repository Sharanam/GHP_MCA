package org.gdcst.jigneshsmart.handleintentimage;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity
{

    public String TAG;
    ImageView imageViewContents;
    TextView textViewMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TAG = getApplication().getPackageName();

        // imageViewContents = (imageViewContents)
        // findViewById(R.id.imageviewcontents);
        imageViewContents = (ImageView) findViewById(R.id.imageviewcontents);
        textViewMessage = (TextView) findViewById(R.id.textViewMessage);
        Intent intent = getIntent();
        Log.i(TAG, "intent.getComponent()=" + intent.getComponent());
        if (intent.getCategories() != null)
            for (String category : intent.getCategories())
            {
                Log.i(TAG, "category=" + category);
            }
        String action = intent.getAction();
        Log.i(TAG, "intent.getAction()=" + action);
        String mimeType = intent.getType();
        Log.i(TAG, "intent.getType()=" + mimeType);
        Uri contentUri = intent.getData();
        Log.i(TAG, "intent.getData()=" + contentUri);
        if (contentUri != null)
        {
            Log.i(TAG, "intent.getData()=" + contentUri.toString());
            Object params[] = {contentUri, this};
            LoadFile loadFile = new LoadFile();
            loadFile.execute(params);
        }
        Bundle extrasBundle = intent.getExtras();
        if (extrasBundle == null) {
            Log.i(TAG, "extrasBundle is null");
        } else {
            for (String key : extrasBundle.keySet()) {
                Log.i(TAG, "Key: " + key + " Value: " + extrasBundle.get(key));
            }
            contentUri = (Uri)extrasBundle.get("android.intent.extra.STREAM");
            Log.d(TAG, "contentUri in Extras: " + contentUri);
            Object params[] = {contentUri, this};
            LoadFile loadFile = new LoadFile();
            loadFile.execute(params);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings)
        {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    class LoadFileAsyncTaskReturnValue
    {
        boolean isError;
        String message;
        Bitmap bitmapImage;
    }

    class LoadFile extends
            AsyncTask<Object, Void, LoadFileAsyncTaskReturnValue>
    {

        @Override
        protected LoadFileAsyncTaskReturnValue doInBackground(Object... params)
        {
            Uri contentUri = (Uri) params[0];
            Context context = (Context) params[1];
            LoadFileAsyncTaskReturnValue loadFileAsyncTaskReturnValue = new LoadFileAsyncTaskReturnValue();
            loadFileAsyncTaskReturnValue.isError = false;
            loadFileAsyncTaskReturnValue.message = null;
            loadFileAsyncTaskReturnValue.bitmapImage = null;
            InputStream inputStream = null;
            try
            {
                inputStream = context.getContentResolver()
                        .openInputStream(contentUri);

                Bitmap receivedBitmapImage = BitmapFactory
                        .decodeStream(inputStream);
                if (receivedBitmapImage == null)
                {
                    loadFileAsyncTaskReturnValue.isError = true;
                    loadFileAsyncTaskReturnValue.message = "Could not decode the image";
                } else
                {
                    loadFileAsyncTaskReturnValue.bitmapImage = receivedBitmapImage;
                }
                return loadFileAsyncTaskReturnValue;
            } catch (FileNotFoundException e)
            {
                loadFileAsyncTaskReturnValue.isError = true;
                loadFileAsyncTaskReturnValue.message = "FileNotFoundException reading "
                        + contentUri.toString();
                return loadFileAsyncTaskReturnValue;
            }
            finally {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                    }
                }
            }
        }

        @Override
        protected void onPostExecute(LoadFileAsyncTaskReturnValue result)
        {
            if (result.isError)
            {
                textViewMessage.setText(result.message);
                imageViewContents.setVisibility(View.GONE);
                textViewMessage.setVisibility(View.VISIBLE);
            } else
            {
                imageViewContents.setImageBitmap(result.bitmapImage);
                imageViewContents.setVisibility(View.VISIBLE);
                textViewMessage.setText("Image loaded");
//                textViewMessage.setVisibility(View.GONE);
            }
            super.onPostExecute(result);
        }
    }

}
