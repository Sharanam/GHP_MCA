package org.gdcst.jigneshsmart.sharedpreferences1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ConstraintLayout constraintLayoutMain;
    TextView textViewQuote;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        constraintLayoutMain = findViewById(R.id.constraintLayoutMain);
        textViewQuote = findViewById(R.id.textViewQuote);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if
        // it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int itemId = item.getItemId();

        switch (itemId)
        {
            case R.id.menu_settings:
                Intent intentSettings = new Intent(this,
                        SettingsActivity.class);
                startActivity(intentSettings);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        setThemeAndFontSize();
        super.onResume();
    }

    void setThemeAndFontSize() {
        SharedPreferences sharedPreferences = getApplicationContext().
                getSharedPreferences("SharedPreferences1",
                        0); // 0 - for private mode
        String theme = sharedPreferences.getString("theme", "light");
        String fontSizeString = sharedPreferences.getString("fontSize", "12");
        int fontSize = Integer.parseInt(fontSizeString);
        int colorBlack  = getResources().getColor(R.color.black);
        int colorWhite  = getResources().getColor(R.color.white);
        switch (theme) {
            case "light":
                constraintLayoutMain.setBackgroundColor(colorWhite);
                textViewQuote.setBackgroundColor(colorWhite);
                textViewQuote.setTextColor(colorBlack);
                textViewQuote.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSize);
                break;
            case "dark":
                constraintLayoutMain.setBackgroundColor(colorBlack);
                textViewQuote.setBackgroundColor(colorBlack);
                textViewQuote.setTextColor(colorWhite);
                textViewQuote.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSize);
                break;
        }
    }

}