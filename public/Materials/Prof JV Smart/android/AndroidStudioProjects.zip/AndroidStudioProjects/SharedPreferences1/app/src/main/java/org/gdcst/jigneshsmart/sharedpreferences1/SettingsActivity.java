package org.gdcst.jigneshsmart.sharedpreferences1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class SettingsActivity extends AppCompatActivity {

    RadioGroup radioGroupTheme;
    RadioButton radioButtonLight;
    RadioButton radioButtonDark;
    Spinner spinnerFontSize;
    Button buttonSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        radioGroupTheme = findViewById(R.id.radioGroupTheme);
        radioButtonLight = findViewById(R.id.radioButtonLight);
        radioButtonDark = findViewById(R.id.radioButtonDark);
        spinnerFontSize = findViewById(R.id.spinnerFontSize);
        buttonSave = findViewById(R.id.buttonSave);

        ArrayList<String> fontSizes = new ArrayList();
        for (int i = 6; i <= 32; i+=2) {
            fontSizes.add(String.valueOf(i));
        }

        // Create an ArrayAdapter using the string array and a default spinner layout
        // ArrayAdapter<String> adapter = new ArrayAdapter<String>(context,
        // android.R.layout.simple_spinner_item, planets);
        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(this, R.layout.spinner_item_layout,
                        fontSizes);
        // Specify the layout to use when the list of choices appears
        // adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item_layout);
        // Apply the adapter to the spinner
        spinnerFontSize.setAdapter(adapter);

        SharedPreferences sharedPreferences = getApplicationContext().
                getSharedPreferences("SharedPreferences1",
                        0); // 0 - for private mode
        String theme = sharedPreferences.getString("theme", "light");
        switch (theme) {
            case "light":
                radioButtonLight.setChecked(true);
                break;
            case "dark":
                radioButtonDark.setChecked(true);
                break;
        }
        String fontSize = sharedPreferences.getString("fontSize", "12");
        spinnerFontSize.setSelection(fontSizes.indexOf(fontSize));

//        radioGroupTheme.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(RadioGroup group, int checkedId) {
//                switch (checkedId) {
//                    case R.id.radioButtonLight:
//                        Toast.makeText(SettingsActivity.this,
//                                "Light theme selected", Toast.LENGTH_SHORT).show();
//                        saveSharedPreference("theme", "light");
//                        break;
//                    case R.id.radioButtonDark:
//                        Toast.makeText(SettingsActivity.this,
//                                "Dark theme selected", Toast.LENGTH_SHORT).show();
//                        saveSharedPreference("theme", "dark");
//                        break;
//                }
//            }
//        });
//
//        spinnerFontSize.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String fontSize = fontSizes[position];
//                Toast.makeText(SettingsActivity.this,
//                        "Font Size " + fontSize + " selected", Toast.LENGTH_SHORT).show();
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioButtonId = radioGroupTheme.getCheckedRadioButtonId();
                String theme = "light";
                switch (radioButtonId) {
                    case R.id.radioButtonLight:
                        theme = "light";
                        break;
                    case R.id.radioButtonDark:
                        theme = "dark";
                        break;
                }
                int position = spinnerFontSize.getSelectedItemPosition();
                String fontSize = fontSizes.get(position);
                saveSharedPreference("theme", theme);
                saveSharedPreference("fontSize", fontSize);
                finish();
            }
        });
    }

    void saveSharedPreference(String key, String value) {
        SharedPreferences sharedPreferences = getApplicationContext().
                getSharedPreferences("SharedPreferences1",
                        0); // 0 - for private mode
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

}