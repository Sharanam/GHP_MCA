package org.gdcst.jigneshsmart.activitylifecycledemo1;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;

public class EditingActivity extends AppCompatActivity {

    public static final String TAG = "ActivityLifeCycleDemo";
    public static Activity editingActivity;
    EditText editText1;
    EditText editText2;
    EditText editText3;
    TextView textViewData;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        context = getApplicationContext();
        Log.i(TAG, "onCreate()...");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editing);
		Toast.makeText(this, "onCreate()...", Toast.LENGTH_LONG).show();
        editingActivity = this;
        editText1 = (EditText) findViewById(R.id.editText1);
        editText2 = (EditText) findViewById(R.id.editText2);
        editText3 = new EditText(context);
        editText3.setHint(R.string.editText3);
        editText3.setInputType(InputType.TYPE_CLASS_TEXT);
        editText3.setTextAppearance(this, android.R.style.TextAppearance);
        editText3.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT));
        LinearLayout linearLayout1 = (LinearLayout) findViewById(R.id.LinearLayout1);
        linearLayout1.addView(editText3, 2);
        textViewData = (TextView) findViewById(R.id.textViewData);
        Button buttonTransferData = (Button) findViewById(R.id.buttonTransfer);
        buttonTransferData.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String data;
                data = editText1.getText().toString();
                data += " ";
                data += editText2.getText().toString();
                data += " ";
                data += editText3.getText().toString();
                textViewData.setText(data);
            }
        });
        Button buttonLaunchAnotherActivity = (Button) findViewById(R.id.buttonLaunchAnotherActivity);
        buttonLaunchAnotherActivity.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),
                        DisplayActivity.class);
                startActivity(intent);
            }
        });

        Button buttonLaunchLoginActivity = findViewById(R.id.buttonLaunchLoginActivity);
        buttonLaunchLoginActivity.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),
                        LoginActivity.class);
                startActivity(intent);
            }
        });

        // Show the Up button in the action bar.
        setupActionBar();
//		String message = getResources().getString(R.string.message);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Message");
        alertDialogBuilder.setMessage(R.string.message);
        alertDialogBuilder.setCancelable(true);
        alertDialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialogInterface, int arg1) {
                dialogInterface.dismiss();
            }
        });
        alertDialogBuilder.create().show();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onStart()
     */
    @Override
    protected void onStart() {
        Log.i(TAG, "onStart()...");
//		Toast.makeText(context,"onStart()...", Toast.LENGTH_SHORT).show();
        super.onStart();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onResume()
     */
    @Override
    protected void onResume() {
        Log.i(TAG, "onResume()...");
//		Toast.makeText(context,"onResume()...", Toast.LENGTH_SHORT).show();
        super.onResume();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onPause()
     */
    @Override
    protected void onPause() {
        Log.i(TAG, "onPause()...");
//		Toast.makeText(context,"onPause()...", Toast.LENGTH_SHORT).show();
        super.onPause();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onStop()
     */
    @Override
    protected void onStop() {
        Log.i(TAG, "onStop()...");
//		Toast.makeText(context,"onStop()...", Toast.LENGTH_SHORT).show();
        super.onStop();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onRestart()
     */
    @Override
    protected void onRestart() {
        Log.i(TAG, "onRestart()...");
//		Toast.makeText(context,"onRestart()...", Toast.LENGTH_SHORT).show();
        super.onRestart();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.app.Activity#onDestroy()
     */
    @Override
    protected void onDestroy() {
        Log.i(TAG, "onDestroy()...");
//		Toast.makeText(context,"onDestroy()...", Toast.LENGTH_SHORT).show();
        super.onDestroy();
    }

    // DON'T use the below event as
// it is only called for activities created with the attribute R.attr.persistableMode set to
//                                                                          persistAcrossReboot
//	@Override
//	public void onSaveInstanceState(@NonNull Bundle outState,
//                          	@NonNull PersistableBundle outPersistentState) {

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        Log.d("ActivityLifeCycleDemo", "onSaveInstanceState()...");
//		Toast.makeText(context,"onSaveInstanceState()...", Toast.LENGTH_SHORT).show();
        outState.putString("editText3Content", editText3.getText().toString());
        outState.putString("textViewDataContent", textViewData.getText().toString());
        // The contents of views with unique id
        // and user-editability are saved and restored
        // automatically by Android in super.onSaveInstanceState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        Log.d("ActivityLifeCycleDemo", "onRestoreInstanceState()...");
//		Toast.makeText(context,"onRestoreInstanceState()...", Toast.LENGTH_SHORT).show();
        // The contents of views with unique id
        // and user-editability are restored
        // automatically by Android in super.onRestoreInstanceState(savedInstanceState);
        super.onRestoreInstanceState(savedInstanceState);
        editText3.setText(savedInstanceState.getString("editText3Content"));
        textViewData.setText(savedInstanceState.getString("textViewDataContent"));
    }

    /**
     * Set up the {@link android.app.ActionBar}, if the API is available.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void setupActionBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.editing, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // This ID represents the Home or Up button. In the case of this
                // activity, the Up button is shown. Use NavUtils to allow users
                // to navigate up one level in the application structure. For
                // more details, see the Navigation pattern on Android Design:
                //
                // http://developer.android.com/design/patterns/navigation.html#up-vs-back
                //
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
