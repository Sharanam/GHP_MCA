package org.gdcst.jigneshsmart.listviewdemo2cricketers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "ListViewDemo2Cricketers";

    ListView listViewCricketers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewCricketers = findViewById(R.id.listViewCricketers);
        MyCricketersArrayAdapter adapter =
                new MyCricketersArrayAdapter(this,R.layout.layout_listitem, Cricketer.cricketers);
        listViewCricketers.setAdapter(adapter);
    }
}