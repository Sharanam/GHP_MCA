package org.gdcst.jigneshsmart.listviewdemo2cricketers;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Base64;
import java.util.List;
import static org.gdcst.jigneshsmart.listviewdemo2cricketers.MainActivity.TAG;

public class MyCricketersArrayAdapter extends BaseAdapter {

    Context context;
    int layoutResourceId;
    List<Cricketer> list;

    MyCricketersArrayAdapter(Context context, int layoutResourceId, List<Cricketer> list) {
        super();
        this.context = context;
        this.layoutResourceId = layoutResourceId;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Cricketer cricketer = list.get(position);
        if (convertView == null) {
            Log.i(TAG, "Creating view for position:" + position);
            LayoutInflater layoutInflater =
                    (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.layout_listitem, null);
        } else {
            Log.i(TAG, "Reusing view for position:" + position);
        }
        ImageView imageView = convertView.findViewById(R.id.imageViewCricketerThumbnail);
        TextView textViewCricketerName = convertView.findViewById(R.id.textViewCricketerName);
        TextView textViewCricketerRole = convertView.findViewById(R.id.textViewCricketerRole);
        TextView textViewCricketerGrade = convertView.findViewById(R.id.textViewCricketerGrade);
        String cricketerThumbnailBase64 = cricketer.getThumbnailImageBase64();
        byte[] decodedContent = Base64.getDecoder().decode(cricketerThumbnailBase64);
        Bitmap bitmapThumbnailImage = BitmapFactory.decodeByteArray(decodedContent, 0, decodedContent.length);
        imageView.setImageBitmap(bitmapThumbnailImage);
        textViewCricketerName.setText(cricketer.getName());
        textViewCricketerRole.setText(cricketer.getRole());
        textViewCricketerGrade.setText(cricketer.getGrade());
        return convertView;
    }
}

