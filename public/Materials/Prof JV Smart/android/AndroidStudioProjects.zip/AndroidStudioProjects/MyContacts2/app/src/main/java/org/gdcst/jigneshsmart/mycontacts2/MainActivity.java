package org.gdcst.jigneshsmart.mycontacts2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MyContacts2";

    ArrayList<Contact> contacts;
    ListView listViewContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contacts = new ArrayList<>();
        contacts.add(new Contact("Qwerty", "+919876543210",
                "qwerty@example.com"));
        contacts.add(new Contact("Asdfg", "+917654321098",
                "asdfg@example.com"));
        for (int i = 0; i < 1000; i++) {
            String name = String.format("Name-%03d", i);
            String phone = String.format("0000000-%03d", i);
            String email = String.format("name-%03d@example.com", i);
            contacts.add(new Contact(name, phone, email));
        }
        listViewContacts = findViewById(R.id.listViewContacts);

        MyContactsArrayAdapter myContactsArrayAdapter =
                new MyContactsArrayAdapter(this,
                        R.layout.contact_list_item_layout,
                        contacts);
        listViewContacts.setAdapter(myContactsArrayAdapter);

    }
}
