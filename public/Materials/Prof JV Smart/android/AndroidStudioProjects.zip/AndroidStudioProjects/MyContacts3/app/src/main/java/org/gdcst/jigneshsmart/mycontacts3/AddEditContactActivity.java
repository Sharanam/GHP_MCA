package org.gdcst.jigneshsmart.mycontacts3;

import static org.gdcst.jigneshsmart.mycontacts3.MainActivity.TAG;
import static org.gdcst.jigneshsmart.mycontacts3.MainActivity.contacts;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class AddEditContactActivity extends AppCompatActivity {

    EditText editTextName;
    EditText editTextPhone;
    EditText editTextEmail;

    int selectedContactId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        editTextName = findViewById(R.id.editTextName);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextEmail = findViewById(R.id.editTextEmail);
        Intent intent = getIntent();
        selectedContactId = intent.getIntExtra("selectedContactId", -1);
        if (selectedContactId == -1) {
            Log.d(TAG, "Adding contact...");
        } else {
            Log.d(TAG, "Editing contact " + selectedContactId + "...");
            Contact contact = contacts.get(selectedContactId);
            editTextName.setText(contact.getName());
            editTextPhone.setText(contact.getPhone());
            editTextEmail.setText(contact.getEmail());
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = this.getMenuInflater();
        menuInflater.inflate(R.menu.add_contact_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int menuItemId = item.getItemId();
        switch (menuItemId) {
            case R.id.menu_save:
                Toast.makeText(this, "Saving contact...", Toast.LENGTH_SHORT).show();
                String name = editTextName.getText().toString();
                String phone = editTextPhone.getText().toString();
                String email = editTextEmail.getText().toString();
                Contact contact = new Contact(name, phone, email);
                if (selectedContactId == -1) {
                    contacts.add(contact);
                } else {
                    contacts.get(selectedContactId).setName(contact.getName());
                    contacts.get(selectedContactId).setPhone(contact.getPhone());
                    contacts.get(selectedContactId).setEmail(contact.getEmail());
                }
                setResult(RESULT_OK);
                finish();
                break;
            case R.id.menu_cancel:
                setResult(RESULT_CANCELED);
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}