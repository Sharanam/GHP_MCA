package org.gdcst.jigneshsmart.mycontacts3;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MyContacts3";
    public static ArrayList<Contact> contacts;
    MyContactsArrayAdapter myContactsArrayAdapter;

    ListView listViewContacts;
    FloatingActionButton fabAddContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewContacts = findViewById(R.id.listViewContacts);
        fabAddContact = findViewById(R.id.fab_add_contact);

        CoordinatorLayout coordinatorLayout = findViewById(R.id.coordinatorLayout);
        Snackbar.make(this, coordinatorLayout,
                "onCreate()...", Snackbar.LENGTH_LONG).show();

        contacts = new ArrayList<>();
        contacts.add(new Contact("Qwerty", "+919876543210",
                "qwerty@example.com"));
        contacts.add(new Contact("Asdfg", "+917654321098",
                "asdfg@example.com"));
//        for (int i = 0; i < 1000; i++) {
//            String name = String.format("Name-%03d", i);
//            String phone = String.format("0000000-%03d", i);
//            String email = String.format("name-%03d@example.com", i);
//            contacts.add(new Contact(name, phone, email));
//        }

        myContactsArrayAdapter =
                new MyContactsArrayAdapter(this,
                        R.layout.contact_list_item_layout,
                        contacts);
        listViewContacts.setAdapter(myContactsArrayAdapter);

        registerForContextMenu(listViewContacts);

        fabAddContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "fab pressed...", Toast.LENGTH_SHORT).show();
                Intent intentAddEditContactActivity = new Intent(MainActivity.this, AddEditContactActivity.class);
//                startActivity(intentAddContactActivity);
                startActivityForResult(intentAddEditContactActivity, 123);
                Log.d(TAG, "After startActivityForResult()...");
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.contacts_list_context_menu, menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info =
                (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int selectedContactId = (int)info.id;
        Log.i(TAG, "selectedContactId=" + selectedContactId);

        int menuItemId = item.getItemId();
        switch (menuItemId) {
            case R.id.context_menu_edit:
                Toast.makeText(this, "Edit pressed... selectedContactId=" + selectedContactId,
                        Toast.LENGTH_SHORT).show();
                Intent intentAddEditContactDetails = new Intent(this,
                        AddEditContactActivity.class);
                intentAddEditContactDetails.putExtra("selectedContactId", selectedContactId);
                startActivityForResult(intentAddEditContactDetails, 123);
                break;
            case R.id.context_menu_delete:
                Toast.makeText(this, "Delete pressed... selectedContactId=" + selectedContactId,
                        Toast.LENGTH_SHORT).show();
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Confirmation");
                String are_you_sure = this.getString(R.string.are_you_sure);
                builder.setMessage(are_you_sure);
//                builder.setCancelable(false);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                contacts.remove(selectedContactId);
                                Log.d(TAG, "contacts.size()=" + contacts.size());
                                myContactsArrayAdapter.notifyDataSetChanged();
                                dialog.dismiss();
                            }
                        }
                );
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }
                );
                builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        Toast.makeText(MainActivity.this, "AlertDialog cancelled by the user...",
                                Toast.LENGTH_SHORT).show();
                    }
                });
                builder.show();
                Log.d(TAG, "After showing AlertDialog...");
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch(requestCode) {
            case 123:
                if (resultCode == Activity.RESULT_OK) {
                    myContactsArrayAdapter.notifyDataSetChanged();
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
