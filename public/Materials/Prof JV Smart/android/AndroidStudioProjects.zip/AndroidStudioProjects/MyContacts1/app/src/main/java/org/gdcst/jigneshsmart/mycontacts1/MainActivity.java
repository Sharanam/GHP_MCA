package org.gdcst.jigneshsmart.mycontacts1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> contacts;
    ListView listViewContacts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contacts = new ArrayList<>();
        contacts.add("Qwerty");
        contacts.add("Asdfg");
        listViewContacts = findViewById(R.id.listViewContacts);

        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter<>(this,
                        R.layout.contact_list_item_layout_name_only,
                        R.id.listItemContactName,
                        contacts);
        listViewContacts.setAdapter(arrayAdapter);

    }
}