package org.gdcst.jigneshsmart.employeemanagement6;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.Context;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.ActionMode;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

/**
 * @author Jignesh Smart
 */
public class EmployeeManagement extends Activity implements
        LoaderCallbacks<Cursor>
{

    private static final String TAG = "EmployeeManagement6";
    public static Context context;
    ActivityState activityState;
    public ListView listViewContacts;
    public static SimpleCursorAdapter adapterContacts;
    public ActionMode actionMode;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        context = getApplicationContext();
        // The Action Bar is a window feature. The feature must be
        // requested
        // before setting a content view. Normally this is set
        // automatically
        // by your Activity's theme in your manifest. The provided
        // system
        // theme Theme.WithActionBar enables this for you. Use it
        // as you would
        // use Theme.NoTitleBar. You can add an Action Bar to your
        // own themes
        // by adding the element <item
        // name="android:windowActionBar">true</item>
        // to your style definition.
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);

        setContentView(R.layout.activity_employee_management);
        listViewContacts =
                (ListView) findViewById(R.id.ListViewContacts);
        // listViewContacts
        // .setOnItemClickListener(new AdapterView
        // .OnItemClickListener() {
        //
        // @Override
        // public void onItemClick(AdapterView<?> adapter, View view,
        // int position, long id)
        // {
        // listViewContacts.setSelection(position);
        // }
        // });

        listViewContacts
                .setOnItemClickListener(
                        new AdapterView.OnItemClickListener()
                        {

                            @Override
                            public void onItemClick(
                                    AdapterView<?> adapterView,
                                    View view, int position, long id)
                            {
                                view.setSelected(true);
                                if (actionMode == null)
                                {
                                    actionMode =
                                            EmployeeManagement.this
                                                    .startActionMode(
                                                            actionModeCallback);
                                }
                                Log.i(TAG, "view selected");
                            }
                        });
        listViewContacts
                .setOnItemSelectedListener(
                        new AdapterView.OnItemSelectedListener()
                        {

                            @Override
                            public void onItemSelected(
                                    AdapterView<?> adapterView,
                                    View view, int position, long id)
                            {
                                Log.i(TAG, "onItemSelected");
                            }

                            @Override
                            public void onNothingSelected(
                                    AdapterView<?> arg0)
                            {
                                actionMode = null;
                            }
                        });

        listViewContacts.setVisibility(View.INVISIBLE);
        fillData();
        activityState = ActivityState.DISPLAYING;
        getLoaderManager().initLoader(0, null, this);
        ActionBar actionBar = getActionBar();
//		Log.i(TAG, "MainActivity actionBar="
//				+ ((actionBar == null) ? "null" : actionBar.toString
// ()));
        if (actionBar != null)
        {
            actionBar.show();
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private final ActionMode.Callback actionModeCallback =
            new ActionMode.Callback()
            {

                @Override
                public boolean onPrepareActionMode(ActionMode mode,
                        Menu menu)
                {
                    return false;
                }

                @Override
                public void onDestroyActionMode(ActionMode mode)
                {
                    actionMode = null;
                    listViewContacts.clearChoices();
                    adapterContacts.notifyDataSetChanged();
                }

                @Override
                public boolean onCreateActionMode(ActionMode mode,
                        Menu menu)
                {
                    Log.i(TAG, "ActionMode.onCreateActionMode()");
                    MenuInflater inflater = mode.getMenuInflater();
                    inflater.inflate(
                            R.menu.main_selected_item_action_mode,
                            menu);
                    return true;
                }

                @Override
                public boolean onActionItemClicked(ActionMode mode,
                        MenuItem item)
                {
                    int itemId = item.getItemId();
                    long selectedContactId = -1;
                    int selectedItemPosition = -1;
                    String selectedContactName = null;
                    Intent editContactDetails = new Intent(context,
                            EmployeeDetailsActivity.class);
                    Uri contactUri;
                    selectedContactId =
                            listViewContacts.getCheckedItemIds()[0];
                    selectedItemPosition =
                            listViewContacts.getCheckedItemPosition();
//			Log.i(TAG, "selectedItemPosition=" +
// selectedItemPosition);
//			Log.i(TAG, "selectedContactId=" + selectedContactId);
                    Cursor cursor =
                            ((SimpleCursorAdapter) listViewContacts
                                    .getAdapter()).getCursor();
                    cursor.moveToPosition(selectedItemPosition);
                    String selectedContactFirstName =
                            cursor.getString(2);
                    String selectedContactMiddleName =
                            cursor.getString(3);
                    String selectedContactLastName =
                            cursor.getString(4);
                    selectedContactName =
                            selectedContactFirstName + " "
                                    + selectedContactMiddleName +
                                    " " + selectedContactLastName;
                    switch (itemId)
                    {
                        case R.id.view_contact:
                            editContactDetails.putExtra(
                                    "org.gdcst.jigneshsmart" +
                                            ".employeemanagement6.action",
                                    ActivityState.VIEWING.ordinal());
                            contactUri = Uri.parse(
                                    EmployeesContentProvider
                                            .CONTENT_URI
                                            + "/" +
                                            selectedContactId);
                            editContactDetails
                                    .putExtra(
                                            "org.gdcst.jigneshsmart" +
                                                    ".employeemanagement6.contactUri",
                                            contactUri);
                            startActivity(editContactDetails);
                            activityState = ActivityState.VIEWING;
                            // mode.finish();
                            return true;
                        case R.id.edit_contact:
                            editContactDetails.putExtra(
                                    "org.gdcst.jigneshsmart" +
                                            ".employeemanagement6.action",
                                    ActivityState.EDITING.ordinal());
                            contactUri = Uri.parse(
                                    EmployeesContentProvider
                                            .CONTENT_URI
                                            + "/" +
                                            selectedContactId);
                            editContactDetails
                                    .putExtra(
                                            "org.gdcst.jigneshsmart" +
                                                    ".employeemanagement6.contactUri",
                                            contactUri);
                            startActivity(editContactDetails);
                            activityState = ActivityState.EDITING;
                            // mode.finish();
                            return true;
                        case R.id.delete_contact:
                            confirm(getString(R.string.want_to_delete)
                                            + " " + selectedContactName + "?",
                                    getString(R.string.yes),
                                    getString(R.string.no), selectedContactId);
                            // mode.finish();
                            return true;
                    }
                    return false;
                }
            };

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if
        // it is present.
        getMenuInflater().inflate(R.menu.employee_management, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int itemId = item.getItemId();
        Intent editContactDetails = new Intent(context,
                EmployeeDetailsActivity.class);
        Uri contactUri;

        switch (itemId)
        {
            case R.id.menu_new:
                editContactDetails = new Intent(context,
                        EmployeeDetailsActivity.class);
                editContactDetails.putExtra(
                        "org.gdcst.jigneshsmart" +
                                ".employeemanagement6.action",
                        ActivityState.ADDING.ordinal());
                contactUri = EmployeesContentProvider.CONTENT_URI;
                editContactDetails.putExtra(
                        "org.gdcst.jigneshsmart" +
                                ".employeemanagement6.contactUri",
                        contactUri);
                startActivity(editContactDetails);
                activityState = ActivityState.ADDING;
                break;
            case R.id.action_settings:
                Toast.makeText(context,
                        "Settings not implemented yet",
                        Toast.LENGTH_LONG).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
            ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    private void deleteContact(long selectedContactId)
    {
        {
            Uri contactUri =
                    Uri.parse(EmployeesContentProvider.CONTENT_URI
                            + "/" + selectedContactId);
            getContentResolver().delete(contactUri, null, null);
            adapterContacts.notifyDataSetChanged();
        }
    }

    private void confirm(String message, String okButtonText,
            String cancelButtonText, final long selectedContactId)
    {
        Context context = this;
        String title = getString(R.string.confirmation);
        final AlertDialog.Builder ad =
                new AlertDialog.Builder(context);
        ad.setTitle(title);
        ad.setMessage(message);
        ad.setPositiveButton(okButtonText,
                new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog,
                            int arg1)
                    {
                        deleteContact(selectedContactId);
                    }
                });
        ad.setNegativeButton(cancelButtonText,
                new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog,
                            int arg1)
                    {
                        // No action
                    }
                });
        ad.setCancelable(true);
        ad.setOnCancelListener(new DialogInterface.OnCancelListener()
        {
            @Override
            public void onCancel(DialogInterface dialog)
            {
                // No action
            }
        });
        ad.show();
    }

    /*
     * (non-Javadoc)
     *
     * @see android.app.LoaderManager
     * .LoaderCallbacks#onCreateLoader(int,
     * android.os.Bundle)
     */
    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args)
    {
        String[] projection = EmployeesDatabaseOpenHelper.allColumns;
        CursorLoader cursorLoader = new CursorLoader(this,
                EmployeesContentProvider.CONTENT_URI, projection,
                null, null,
                EmployeesDatabaseOpenHelper.COLUMN_FIRSTNAME);
        return cursorLoader;
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * android.app.LoaderManager.LoaderCallbacks#onLoadFinished(android.content
     * .Loader, java.lang.Object)
     */
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data)
    {
        adapterContacts.swapCursor(data);
        listViewContacts.setVisibility(View.VISIBLE);
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * android.app.LoaderManager.LoaderCallbacks#onLoaderReset(android.content
     * .Loader)
     */
    @Override
    public void onLoaderReset(Loader<Cursor> loader)
    {
        adapterContacts.swapCursor(null);
    }

    private void fillData()
    {

        String[] from = new String[]{
                EmployeesDatabaseOpenHelper.COLUMN_FIRSTNAME,
                EmployeesDatabaseOpenHelper.COLUMN_MIDDLENAME,
                EmployeesDatabaseOpenHelper.COLUMN_LASTNAME,
                EmployeesDatabaseOpenHelper.COLUMN_ID}; // ID is MUST!
        // Fields on the UI to which we map
        int[] to = new int[]{R.id.textViewListViewItemFName,
                R.id.textViewListViewItemMName,
                R.id.textViewListViewItemLName};
        getLoaderManager().initLoader(0, null, this);
        adapterContacts = new SimpleCursorAdapter(this,
                R.layout.listview_layout, null, from, to, 0);
        listViewContacts.setAdapter(adapterContacts);
    }
}
