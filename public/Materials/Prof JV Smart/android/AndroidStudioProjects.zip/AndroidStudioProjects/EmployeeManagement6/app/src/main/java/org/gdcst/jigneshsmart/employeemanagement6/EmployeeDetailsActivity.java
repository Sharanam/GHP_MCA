package org.gdcst.jigneshsmart.employeemanagement6;

import android.app.ActionBar;
import android.app.Activity;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.ContentValues;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

public class EmployeeDetailsActivity extends Activity implements
		LoaderCallbacks<Cursor>
{

	private static final String TAG = "EmployeeManagement1";
	public static Context context;
	public static EditText editTextEmployeeNumber;
	public static EditText editTextFirstName;
	public static EditText editTextMiddleName;
	public static EditText editTextLastName;
	public static EditText editTextDepartment;
	public static EditText editTextDesignation;
	public static EditText editTextPhoneNumber;
	public static EditText editTextEmail;
	public static DatePicker datePickerJoiningDate;
	public static EditText editTextSalary;
	public static ActivityState activityState;
	public static int action;
	public static Uri contentUri;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		context = getApplicationContext();

		// The Action Bar is a window feature. The feature must be requested
		// before setting a content view. Normally this is set automatically
		// by your Activity's theme in your manifest. The provided system
		// theme Theme.WithActionBar enables this for you. Use it as you would
		// use Theme.NoTitleBar. You can add an Action Bar to your own themes
		// by adding the element <item
		// name="android:windowActionBar">true</item>
		// to your style definition.
		getWindow().requestFeature(Window.FEATURE_ACTION_BAR);

		setContentView(R.layout.employee_details);
		editTextEmployeeNumber = (EditText) findViewById(R.id.editTextEmployeeNumber);
		editTextFirstName = (EditText) findViewById(R.id.editTextFirstName);
		editTextMiddleName = (EditText) findViewById(R.id.editTextMiddleName);
		editTextLastName = (EditText) findViewById(R.id.editTextLastName);
		editTextDepartment = (EditText) findViewById(R.id.editTextDepartment);
		editTextDesignation = (EditText) findViewById(R.id.editTextDesignation);
		editTextPhoneNumber = (EditText) findViewById(R.id.editTextPhoneNumber);
		editTextEmail = (EditText) findViewById(R.id.editTextEmail);
		datePickerJoiningDate = (DatePicker) findViewById(R.id.datePickerJoiningDate);
		editTextSalary = (EditText) findViewById(R.id.editSalary);
		int action = getIntent().getIntExtra(
				"org.gdcst.jigneshsmart.employeemanagement6.action", -1);
		Bundle extras = getIntent().getExtras();
		if (extras != null)
			contentUri = extras
					.getParcelable("org.gdcst.jigneshsmart.employeemanagement6.contactUri");
		else
			contentUri = null;
		Log.i(TAG, "Detail Activity: contentUri=" + contentUri);
		if (action == -1)
		{
			Toast.makeText(context, "Activity called incorrectly",
					Toast.LENGTH_LONG).show();
			setResult(RESULT_CANCELED);
			finish();
			return;
		}
		activityState = ActivityState.values()[action];
		if (activityState != ActivityState.ADDING && contentUri == null)
		{
			Toast.makeText(context, "Activity called incorrectly",
					Toast.LENGTH_LONG).show();
			setResult(RESULT_CANCELED);
			finish();
			return;
		}
		editTextEmployeeNumber.setVisibility(View.GONE);
		editTextFirstName.setVisibility(View.GONE);
		editTextMiddleName.setVisibility(View.GONE);
		editTextLastName.setVisibility(View.GONE);
		editTextDepartment.setVisibility(View.GONE);
		editTextDesignation.setVisibility(View.GONE);
		editTextPhoneNumber.setVisibility(View.GONE);
		editTextEmail.setVisibility(View.GONE);
		datePickerJoiningDate.setVisibility(View.GONE);
		editTextSalary.setVisibility(View.GONE);
		editTextEmployeeNumber.setText("");
		editTextFirstName.setText("");
		editTextMiddleName.setText("");
		editTextLastName.setText("");
		editTextDepartment.setText("");
		editTextDesignation.setText("");
		editTextPhoneNumber.setText("");
		editTextEmail.setText("");
		datePickerJoiningDate.updateDate(2001, 1, 1);
		editTextSalary.setText("");
		switch (activityState)
		{
		case ADDING:
			editTextEmployeeNumber.setEnabled(true);
			editTextFirstName.setEnabled(true);
			editTextMiddleName.setEnabled(true);
			editTextLastName.setEnabled(true);
			editTextDepartment.setEnabled(true);
			editTextDesignation.setEnabled(true);
			editTextPhoneNumber.setEnabled(true);
			editTextEmail.setEnabled(true);
			datePickerJoiningDate.setEnabled(true);
			editTextSalary.setEnabled(true);
			break;
		case EDITING:
			editTextEmployeeNumber.setEnabled(true);
			editTextFirstName.setEnabled(true);
			editTextMiddleName.setEnabled(true);
			editTextLastName.setEnabled(true);
			editTextDepartment.setEnabled(true);
			editTextDesignation.setEnabled(true);
			editTextPhoneNumber.setEnabled(true);
			editTextEmail.setEnabled(true);
			datePickerJoiningDate.setEnabled(true);
			editTextSalary.setEnabled(true);
			break;
		case VIEWING:
			editTextEmployeeNumber.setEnabled(false);
			editTextFirstName.setEnabled(false);
			editTextMiddleName.setEnabled(false);
			editTextLastName.setEnabled(false);
			editTextDepartment.setEnabled(false);
			editTextDesignation.setEnabled(false);
			editTextPhoneNumber.setEnabled(false);
			editTextEmail.setEnabled(false);
			datePickerJoiningDate.setEnabled(false);
			editTextSalary.setEnabled(false);
			break;
		default:
			Toast.makeText(context, "Activity called incorrectly",
					Toast.LENGTH_LONG).show();
			setResult(RESULT_CANCELED);
			finish();
			return;
		}
		if (activityState != ActivityState.ADDING)
			getLoaderManager().initLoader(0, null, this);
		else
		{
			editTextEmployeeNumber.setVisibility(View.VISIBLE);
			editTextFirstName.setVisibility(View.VISIBLE);
			editTextMiddleName.setVisibility(View.VISIBLE);
			editTextLastName.setVisibility(View.VISIBLE);
			editTextDepartment.setVisibility(View.VISIBLE);
			editTextDesignation.setVisibility(View.VISIBLE);
			editTextPhoneNumber.setVisibility(View.VISIBLE);
			editTextEmail.setVisibility(View.VISIBLE);
			datePickerJoiningDate.setVisibility(View.VISIBLE);
			editTextSalary.setVisibility(View.VISIBLE);
		}
		ActionBar actionBar = getActionBar();
		// Log.i(TAG, "Details Activity actionBar="
		// + ((actionBar == null) ? "null" : actionBar.toString()));
		if (actionBar != null)
		{
			actionBar.show();
			actionBar.setDisplayHomeAsUpEnabled(true);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.employee_details, menu);
		return true;
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu)
	{
		MenuItem menu_save = menu.findItem(R.id.menu_save);
		MenuItem menu_discard = menu.findItem(R.id.menu_discard);
		switch (activityState)
		{
		case ADDING:
			menu_save.setVisible(true);
			menu_discard.setVisible(true);
			break;
		case EDITING:
			menu_save.setVisible(true);
			menu_discard.setVisible(true);
			break;
		case VIEWING:
			menu_save.setVisible(false);
			menu_discard.setVisible(false);
			break;
		default:
			break;
		}
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		case android.R.id.home:
			NavUtils.navigateUpFromSameTask(this);
			return true;
		case R.id.menu_save:
			int contactId;
			ContentValues values = new ContentValues();
			if (activityState != ActivityState.ADDING)
			{
				contactId = Integer.parseInt(contentUri.getLastPathSegment());
				values.put(EmployeesDatabaseOpenHelper.COLUMN_ID, contactId);
			}
			int employeeNumber = Integer.parseInt(editTextEmployeeNumber
					.getText().toString());
			String firstName = editTextFirstName.getText().toString();
			String middleName = editTextMiddleName.getText().toString();
			String lastName = editTextLastName.getText().toString();
			String department = editTextDepartment.getText().toString();
			String designation = editTextDesignation.getText().toString();
			String phoneNumber = editTextPhoneNumber.getText().toString();
			String email = editTextEmail.getText().toString();
			String joiningDateString = datePickerJoiningDate.getYear() + "-"
					+ (datePickerJoiningDate.getMonth() + 1) + "-"
					+ datePickerJoiningDate.getDayOfMonth();
			Double salary = Double.parseDouble(editTextSalary.getText()
					.toString());
			values.put(EmployeesDatabaseOpenHelper.COLUMN_EMPLOYEENUMBER,
					employeeNumber);
			values.put(EmployeesDatabaseOpenHelper.COLUMN_FIRSTNAME, firstName);
			values.put(EmployeesDatabaseOpenHelper.COLUMN_MIDDLENAME,
					middleName);
			values.put(EmployeesDatabaseOpenHelper.COLUMN_LASTNAME, lastName);
			values.put(EmployeesDatabaseOpenHelper.COLUMN_DEPARTMRNT,
					department);
			values.put(EmployeesDatabaseOpenHelper.COLUMN_DESIGNATION,
					designation);
			values.put(EmployeesDatabaseOpenHelper.COLUMN_PHONENUMBER,
					phoneNumber);
			values.put(EmployeesDatabaseOpenHelper.COLUMN_EMAIL, email);
			values.put(EmployeesDatabaseOpenHelper.COLUMN_JOININGDATE,
					joiningDateString);
			values.put(EmployeesDatabaseOpenHelper.COLUMN_SALARY, salary);
			switch (activityState)
			{
			case ADDING:
				getContentResolver().insert(contentUri, values);
				break;
			case EDITING:
				getContentResolver().update(contentUri, values, null, null);
				break;
			default:
				break;
			}
			setResult(RESULT_OK);
			finish();
			break;
		case R.id.menu_discard:
			setResult(RESULT_CANCELED);
			finish();
			break;
		}
		return super.onOptionsItemSelected(item);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.LoaderManager.LoaderCallbacks#onCreateLoader(int,
	 * android.os.Bundle)
	 */
	@Override
	public Loader<Cursor> onCreateLoader(int id, Bundle bundle)
	{
		String[] projection = EmployeesDatabaseOpenHelper.allColumns;
		CursorLoader cursorLoader = new CursorLoader(this, contentUri,
				projection, null, null,
				EmployeesDatabaseOpenHelper.COLUMN_FIRSTNAME);
		return cursorLoader;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * android.app.LoaderManager.LoaderCallbacks#onLoadFinished(android.content
	 * .Loader, java.lang.Object)
	 */
	@Override
	public void onLoadFinished(Loader<Cursor> loader, Cursor cursor)
	{
		if (cursor.moveToFirst())
		{
			editTextEmployeeNumber.setText(Integer.valueOf(cursor.getInt(1))
					.toString());
			editTextFirstName.setText(cursor.getString(2));
			editTextMiddleName.setText(cursor.getString(3));
			editTextLastName.setText(cursor.getString(4));
			editTextDepartment.setText(cursor.getString(5));
			editTextDesignation.setText(cursor.getString(6));
			editTextPhoneNumber.setText(cursor.getString(7));
			editTextEmail.setText(cursor.getString(8));
			String joiningDateString = cursor.getString(9);
			int year = Integer.parseInt(joiningDateString.substring(0, 4));
			int position1 = joiningDateString.indexOf('-');
			int position2 = joiningDateString.indexOf('-', position1 + 1);
			int month = Integer.parseInt(joiningDateString.substring(
					position1 + 1, position2));
			int date = Integer.parseInt(joiningDateString
					.substring(position2 + 1));
			datePickerJoiningDate.updateDate(year, month - 1, date);
			editTextSalary.setText(Double.valueOf(cursor.getDouble(10))
					.toString());
		} else
			Toast.makeText(context, "Employee details not found!",
					Toast.LENGTH_LONG).show();
		editTextEmployeeNumber.setVisibility(View.VISIBLE);
		editTextFirstName.setVisibility(View.VISIBLE);
		editTextMiddleName.setVisibility(View.VISIBLE);
		editTextLastName.setVisibility(View.VISIBLE);
		editTextDepartment.setVisibility(View.VISIBLE);
		editTextDesignation.setVisibility(View.VISIBLE);
		editTextPhoneNumber.setVisibility(View.VISIBLE);
		editTextEmail.setVisibility(View.VISIBLE);
		datePickerJoiningDate.setVisibility(View.VISIBLE);
		editTextSalary.setVisibility(View.VISIBLE);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * android.app.LoaderManager.LoaderCallbacks#onLoaderReset(android.content
	 * .Loader)
	 */
	@Override
	public void onLoaderReset(Loader<Cursor> arg0)
	{
		// TODO Auto-generated method stub

	}

}
