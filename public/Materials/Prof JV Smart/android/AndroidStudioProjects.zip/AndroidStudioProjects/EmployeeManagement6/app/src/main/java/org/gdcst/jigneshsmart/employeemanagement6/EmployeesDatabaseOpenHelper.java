/**
 * 
 */
package org.gdcst.jigneshsmart.employeemanagement6;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * @author Jignesh Smart
 * 
 */
public class EmployeesDatabaseOpenHelper extends SQLiteOpenHelper
{

	public static final String TABLE_EMPLOYEES = "employees";
	public static final String COLUMN_ID = "_id";
	public static final String COLUMN_EMPLOYEENUMBER = "employeenuber";
	public static final String COLUMN_FIRSTNAME = "firstname";
	public static final String COLUMN_MIDDLENAME = "middlename";
	public static final String COLUMN_LASTNAME = "lastname";
	public static final String COLUMN_DEPARTMRNT = "department";
	public static final String COLUMN_DESIGNATION = "designation";
	public static final String COLUMN_PHONENUMBER = "phonenumber";
	public static final String COLUMN_EMAIL = "email";
	public static final String COLUMN_JOININGDATE = "joiningdate";
	public static final String COLUMN_SALARY = "salary";

	public static String[] allColumns = { COLUMN_ID, COLUMN_EMPLOYEENUMBER,
			COLUMN_FIRSTNAME, COLUMN_MIDDLENAME, COLUMN_LASTNAME,
			COLUMN_DEPARTMRNT, COLUMN_DESIGNATION, COLUMN_PHONENUMBER,
			COLUMN_EMAIL, COLUMN_JOININGDATE, COLUMN_SALARY };

	private static final String DATABASE_NAME = "employees.db";
	private static final int DATABASE_VERSION = 1;

	// Database creation sql statement
	private static final String DATABASE_CREATE = "create table "
			+ TABLE_EMPLOYEES + "(" + COLUMN_ID
			+ " integer primary key autoincrement, " + COLUMN_EMPLOYEENUMBER
			+ " integer unique not null, " + COLUMN_FIRSTNAME
			+ " text not null, " + COLUMN_MIDDLENAME + " text not null, "
			+ COLUMN_LASTNAME + " text not null, " + COLUMN_DEPARTMRNT
			+ " int, " + COLUMN_DESIGNATION + " text, " + COLUMN_PHONENUMBER
			+ " text, " + COLUMN_EMAIL + " text, " + COLUMN_JOININGDATE
			+ " date, " + COLUMN_SALARY + " double" + ");";

	public EmployeesDatabaseOpenHelper(Context context)
	{
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * android.database.sqlite.SQLiteOpenHelper#onCreate(android.database.sqlite
	 * .SQLiteDatabase)
	 */
	@Override
	public void onCreate(SQLiteDatabase database)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-M-d");
		database.execSQL(DATABASE_CREATE);
		try
		{
			insertInitialRow(database, 101, "faaa", "maaa", "laaa", 1,
					"Programmer", "1111", "aaa@aaa.com",
					dateFormat.parse("1991-1-1"), 1111.11);
			insertInitialRow(database, 102, "fbbb", "mbbb", "bbb", 2,
					"Operator", "1111", "aaa@aaa.com",
					dateFormat.parse("1991-1-1"), 1111.11);
			insertInitialRow(database, 103, "fccc", "mccc", "lccc", 1,
					"Manager", "1111", "aaa@aaa.com",
					dateFormat.parse("1991-1-1"), 1111.11);
		} catch (ParseException e)
		{
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * android.database.sqlite.SQLiteOpenHelper#onUpgrade(android.database.sqlite
	 * .SQLiteDatabase, int, int)
	 */
	@Override
	public void onUpgrade(SQLiteDatabase database, int oldVersion,
			int newVersion)
	{
		Log.w(EmployeesDatabaseOpenHelper.class.getName(),
				"Upgrading database from version " + oldVersion + " to "
						+ newVersion + ", which will destroy all old data");
		database.execSQL("DROP TABLE IF EXISTS " + TABLE_EMPLOYEES);
		onCreate(database);
	}

	public long insertInitialRow(SQLiteDatabase database, int empno,
			String fname, String mname, String lname, int dept, String desig,
			String phoneNumber, String email, Date jdate, double salary)
	{
		ContentValues values = new ContentValues();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-M-d");
		values.put(COLUMN_EMPLOYEENUMBER, empno);
		values.put(COLUMN_FIRSTNAME, fname);
		values.put(COLUMN_MIDDLENAME, mname);
		values.put(COLUMN_LASTNAME, lname);
		values.put(COLUMN_DEPARTMRNT, dept);
		values.put(COLUMN_DESIGNATION, desig);
		values.put(COLUMN_PHONENUMBER, phoneNumber);
		values.put(COLUMN_EMAIL, email);
		values.put(COLUMN_JOININGDATE, dateFormat.format(jdate));
		values.put(COLUMN_SALARY, salary);
		long insertId = database.insert(TABLE_EMPLOYEES, null, values);
		return insertId;
	}
}
