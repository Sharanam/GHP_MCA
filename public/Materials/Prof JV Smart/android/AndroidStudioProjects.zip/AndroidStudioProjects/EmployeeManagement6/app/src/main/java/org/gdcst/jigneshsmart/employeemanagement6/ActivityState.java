/**
 * 
 */
package org.gdcst.jigneshsmart.employeemanagement6;

/**
 * @author Jignesh Smart
 * 
 */
public enum ActivityState
{
	DISPLAYING, EDITING, ADDING, VIEWING
}
