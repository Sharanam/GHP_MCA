package org.gdcst.jigneshsmart.mycontacts4;

import static org.gdcst.jigneshsmart.mycontacts4.ContactsContentProvider.AUTHORITY;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MyContacts4";

    ListView listViewContacts;
    SimpleCursorAdapter adapter;
    FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listViewContacts = findViewById(R.id.listViewContacts);
        fab = findViewById(R.id.fab_add_contact);
        fillData();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "fab clicked");
                Intent intentAddEditContactActivity = new Intent(MainActivity.this, AddEditContactActivity.class);
                startActivity(intentAddEditContactActivity);
            }
        });
    }

    private void fillData()
    {

        Cursor cursor;

        String[] FROM = new String[]{ "name", "phone", "_id" };
        // ID is MUST!
        // Fields on the UI to which we map
        int[] TO = new int[]{R.id.textViewListViewItemContactName,
                R.id.textViewListViewItemContactNumber};

//        Using content provider

//        String[] PROJECTION = { "name", "phone", "_id" };
//        String SELECTION = null;
//        String[] SELECTIONARGS = { };
//        String SORTORDER = "name ASC, number";

//        Uri uri = Uri.parse("content://" + AUTHORITY);
//            cursor = getContentResolver().query(uri, PROJECTION, SELECTION,
//                SELECTIONARGS, SORTORDER);


//        Without using content provider
        
        ContactDatabaseOpenHelper dbOpenHelper = new ContactDatabaseOpenHelper(this);
        String[] SELECTIONARGS = { };
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();

        cursor = db.rawQuery("SELECT _id, name, phone, email, birthdate FROM contacts ORDER BY name, phone", SELECTIONARGS);
        adapter = new SimpleCursorAdapter(this,
                R.layout.list_view_item_layout,
                cursor, FROM, TO, 0);
        listViewContacts.setAdapter(adapter);
    }

}