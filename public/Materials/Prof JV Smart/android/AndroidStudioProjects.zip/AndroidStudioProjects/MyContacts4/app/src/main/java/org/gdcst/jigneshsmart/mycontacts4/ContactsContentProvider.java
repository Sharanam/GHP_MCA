package org.gdcst.jigneshsmart.mycontacts4;

import static org.gdcst.jigneshsmart.mycontacts4.MainActivity.TAG;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

public class ContactsContentProvider extends ContentProvider
{

    private ContactDatabaseOpenHelper dbOpenHelper;

    public static final String AUTHORITY = "org.gdcst.jigneshsmart.mycontacts4.contentprovider";

    @Override
    public boolean onCreate()
    {
        dbOpenHelper = new ContactDatabaseOpenHelper(getContext());
        Log.d(TAG, "ContactDatabaseOpenHelper.onCreate() " + dbOpenHelper);
        return false;
    }

    @Override
    public String getType(Uri uri)
    {
        // No MIME type for Contacts
        return null;
    }

    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {

        Log.d(TAG, "ContactDatabaseOpenHelper.query() " + dbOpenHelper);
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();

        Cursor cursor;
        cursor = db.rawQuery("SELECT _id, name, phone, email, birthdate FROM contacts ORDER BY name, phone", selectionArgs);

        // Make sure that potential listeners are getting notified
        cursor.setNotificationUri(getContext().getContentResolver(), uri);

        return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values)
    {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        long id = db.insert("contacts", null, values);
        getContext().getContentResolver().notifyChange(uri, null);
        return Uri.parse("content://" + AUTHORITY + "/" + id);
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs)
    {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        int rowsUpdated = db.update("contacts", values, selection, selectionArgs);
        getContext().getContentResolver().notifyChange(uri, null);
        return rowsUpdated;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs)
    {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        int rowsDeleted = db.delete("contacts", selection, selectionArgs);
        getContext().getContentResolver().notifyChange(uri, null);
        return rowsDeleted;
    }

}
