package org.gdcst.jigneshsmart.mycontacts4;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ContactDatabaseOpenHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "contacts.db";
    private static final int DATABASE_VERSION = 1;

    // Database creation SQL statement
    private static final String CREATE_TABLES =
            "create table contacts (" +
                    "_id integer primary key autoincrement, " +
                    "name text unique not null, " +
                    "phone text not null, " +
                    "email text, " +
                    "birthdate date);";

    public ContactDatabaseOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(CREATE_TABLES);
        database.execSQL("insert into contacts values(1, 'aaa', '12345', 'aaa@example.com', '2020-01-01')");
        database.execSQL("insert into contacts values(2, 'bbb', '67890', 'bbb@example.com', '2021-02-02')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        // We should have backed up the data for restoration after the upgrade
        database.execSQL("DROP TABLE IF EXISTS contacts");

        // Recreate the table
        onCreate(database);
    }
}
