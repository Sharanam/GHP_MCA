package org.gdcst.jigneshsmart.listviewdemo2database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ContactsDatabaseOpenHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "contacts.db";
    private static final int DATABASE_VERSION = 1;

    // Database creation SQL statement
    private static final String CREATE_TABLES =
            "create table contacts (" +
                    "_id integer primary key autoincrement, " +
                    "name text unique not null, " +
                    "phone text not null);";

    public ContactsDatabaseOpenHelper(Context context) {
//      SQLiteOpenHelper(Context context, String name,
//                              SQLiteDatabase.CursorFactory factory, int version)
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(CREATE_TABLES);
        insertInitialData(database);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        // We should have backed up the data for restoration after the upgrade
        database.execSQL("DROP TABLE IF EXISTS contacts");

        // Recreate the table
        onCreate(database);
    }

    void insertInitialData(SQLiteDatabase database) {
        database.execSQL("INSERT INTO contacts(name, phone) values('Diane Murphy', '9510278609');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Mary Patterson', '8114763215');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Jeff Firrelli', '8769884904');");
        database.execSQL("INSERT INTO contacts(name, phone) values('William Patterson', '9188105486');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Gerard Bondur', '8215295508');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Anthony Bow', '9709568274');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Leslie Jennings', '7261113785');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Leslie Thompson', '8387171650');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Julie Firrelli', '9294545919');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Steve Patterson', '7046475931');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Foon Yue Tseng', '7475358639');");
        database.execSQL("INSERT INTO contacts(name, phone) values('George Vanauf', '9655596504');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Loui Bondur', '8117181453');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Gerard Hernandez', '8090548904');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Pamela Castillo', '7523275153');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Larry Bott', '9191251030');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Barry Jones', '7184868552');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Andy Fixter', '9800605381');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Peter Marsh', '8819685658');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Tom King', '8930083110');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Mami Nishi', '9131240068');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Yoshimi Kato', '7221621933');");
        database.execSQL("INSERT INTO contacts(name, phone) values('Martin Gerard', '9112514598');");

    }
}
