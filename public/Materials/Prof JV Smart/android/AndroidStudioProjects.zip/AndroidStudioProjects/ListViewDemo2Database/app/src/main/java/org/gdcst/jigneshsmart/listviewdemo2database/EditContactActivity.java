package org.gdcst.jigneshsmart.listviewdemo2database;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class EditContactActivity extends AppCompatActivity {

    EditText editTextEditPersonName;
    EditText editTextEditPersonPhone;
    long contactId;
    String contactIdStr;
    String contactName;
    String contactPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_contact);
        editTextEditPersonName = findViewById(R.id.editTextEditPersonName);
        editTextEditPersonPhone = findViewById(R.id.editTextEditPersonPhone);

        Intent intent  = getIntent();
        contactId = intent.getLongExtra("contactId", -1);
        if (contactId == -1) {
            Toast.makeText(this, "contactId not passed", Toast.LENGTH_SHORT).show();
            setResult(Activity.RESULT_CANCELED);
            finish();;
        } else {
//            Log.d(MainActivity.TAG, "contactId: " + contactId);
            ContactsDatabaseOpenHelper contactsDatabaseOpenHelper = new ContactsDatabaseOpenHelper(this);
            SQLiteDatabase database = contactsDatabaseOpenHelper.getReadableDatabase();
            contactIdStr = String.valueOf(contactId);
            String[] selectionArgs = { contactIdStr };
            Cursor cursor = database. rawQuery(
                    "SELECT _id, name, phone FROM contacts WHERE _id=?", selectionArgs);
            if (cursor.moveToNext()) {
                contactName = cursor.getString(1);
                contactPhone = cursor.getString(2);
                editTextEditPersonName.setText(contactName);
                editTextEditPersonPhone.setText(contactPhone);
            } else {
                Toast.makeText(this, "contact with id " + contactId + " not found", Toast.LENGTH_SHORT).show();
                setResult(Activity.RESULT_CANCELED);
                finish();;
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_contact, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        switch(itemId) {
            case R.id.menu_save:
                if (saveContact()) {
                    setResult(Activity.RESULT_OK);
                    finish();
                }
                break;
            case R.id.menu_cancel:
                setResult(Activity.RESULT_CANCELED);
                finish();
        }
        return super.onOptionsItemSelected(item);
    }


    boolean saveContact() {
        String personName = editTextEditPersonName.getText().toString();
        if (personName.isEmpty()) {
            Toast.makeText(this, "You must enter the name", Toast.LENGTH_SHORT).show();
            return false;
        }
        String personPhone = editTextEditPersonPhone.getText().toString();
        if (personPhone.isEmpty()) {
            Toast.makeText(this, "You must enter the phone number", Toast.LENGTH_SHORT).show();
            return false;
        }
        ContactsDatabaseOpenHelper contactsDatabaseOpenHelper = new ContactsDatabaseOpenHelper(this);
        SQLiteDatabase database = contactsDatabaseOpenHelper.getWritableDatabase();
        Object[] bindParams = { personName, personPhone, contactIdStr };
        database.execSQL("UPDATE contacts SET name=?, phone=? WHERE _id=?", bindParams);
        return true;
    }

}