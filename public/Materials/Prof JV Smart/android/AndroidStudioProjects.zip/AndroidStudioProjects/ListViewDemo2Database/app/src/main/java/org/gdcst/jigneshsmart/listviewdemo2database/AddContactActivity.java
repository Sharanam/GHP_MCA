package org.gdcst.jigneshsmart.listviewdemo2database;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class AddContactActivity extends AppCompatActivity {

    EditText editTextPersonName;
    EditText editTextPersonPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        editTextPersonName = findViewById(R.id.editTextPersonName);
        editTextPersonPhone = findViewById(R.id.editTextPersonPhone);

    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add_contact, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        switch(itemId) {
            case R.id.menu_save:
                if (addContact()) {
                    setResult(Activity.RESULT_OK);
                    finish();
                }
                break;
            case R.id.menu_cancel:
                setResult(Activity.RESULT_CANCELED);
                finish();
        }
        return super.onOptionsItemSelected(item);
    }

    boolean addContact() {
        String personName = editTextPersonName.getText().toString();
        if (personName.isEmpty()) {
            Toast.makeText(this, "You must enter the name", Toast.LENGTH_SHORT).show();
            return false;
        }
        String personPhone = editTextPersonPhone.getText().toString();
        if (personPhone.isEmpty()) {
            Toast.makeText(this, "You must enter the phone number", Toast.LENGTH_SHORT).show();
            return false;
        }
        ContactsDatabaseOpenHelper contactsDatabaseOpenHelper = new ContactsDatabaseOpenHelper(this);
        SQLiteDatabase database = contactsDatabaseOpenHelper.getWritableDatabase();
        String[] bindParams = { personName, personPhone };
        database.execSQL("INSERT INTO  contacts(name, phone) values(?, ?)", bindParams);
        return true;
    }

}