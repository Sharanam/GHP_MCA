package org.gdcst.jigneshsmart.listviewdemo2database;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "ListViewDemo2Database";

    ListView listViewContacts;
    SimpleCursorAdapter adapter;
    int position;
    long id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listViewContacts = findViewById(R.id.listViewContacts);

        ContactsDatabaseOpenHelper contactsDatabaseOpenHelper = new ContactsDatabaseOpenHelper(this);
        SQLiteDatabase database = contactsDatabaseOpenHelper.getReadableDatabase();
        Cursor cursor = database.rawQuery(
                "SELECT _id, name, phone FROM contacts ORDER BY name", null);
        String[] from  = { "name", "phone", "_id"};
        int[] to = { R.id.textViewContactName, R.id.textViewContactPhone };
        adapter = new SimpleCursorAdapter(this,
                R.layout.contacts_listitem_layout, cursor, from, to);
        listViewContacts.setAdapter(adapter);

        registerForContextMenu(listViewContacts);
    }

    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        switch (itemId) {
            case R.id.menu_add:
//                Toast.makeText(this, "menu_add", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, AddContactActivity.class);
                startActivityForResult(intent, 123);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        Log.d(TAG, "requestCode=" + requestCode + " resultCode=" + resultCode);
        switch (requestCode) {
            case 123:
            case 124:
                if (resultCode == Activity.RESULT_OK) {
//                    adapter.notifyDataSetChanged() does not work with SimpleCursorAdapter
//                    because it is based on a cursor and cursor cannot be updated
                    ContactsDatabaseOpenHelper contactsDatabaseOpenHelper = new ContactsDatabaseOpenHelper(this);
                    SQLiteDatabase database = contactsDatabaseOpenHelper.getReadableDatabase();
                    Cursor cursor = database.rawQuery(
                            "SELECT _id, name, phone FROM contacts ORDER BY name", null);
                    adapter.swapCursor(cursor);
                    Log.d(TAG, "adapter notified");
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        position = adapterContextMenuInfo.position;
        id = adapterContextMenuInfo.id;
        Log.d(TAG, "position: "+ position + " id: " + id);
        getMenuInflater().inflate(R.menu.context_menu_contacts, menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        switch (itemId) {
            case R.id.menu_edit:
//                Toast.makeText(this, "Editing contact...", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, EditContactActivity.class);
                intent.putExtra("contactId", id);
                startActivityForResult(intent, 124);
                break;
            case R.id.menu_delete:
//                Toast.makeText(this, "Deleting contact...", Toast.LENGTH_SHORT).show();
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setIcon(R.drawable.ic_action_cancel);
                builder.setTitle("Do you want to delete this contact?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ContactsDatabaseOpenHelper contactsDatabaseOpenHelper =
                                new ContactsDatabaseOpenHelper(MainActivity.this);
                        SQLiteDatabase database = contactsDatabaseOpenHelper.getWritableDatabase();
                        Object[] bindParams = { id };
                        database.execSQL("DELETE FROM contacts WHERE _id=?", bindParams);
                        Cursor cursor = database.rawQuery(
                                "SELECT _id, name, phone FROM contacts ORDER BY name", null);
                        String[] from  = { "name", "phone", "_id"};
                        int[] to = { R.id.textViewContactName, R.id.textViewContactPhone };
                        adapter.swapCursor(cursor);
                        Log.d(TAG, "adapter notified");
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d(TAG, "Deletion calcelled by user");
                    }
                });
                builder.setCancelable(true);
                builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialogInterface) {
                        Log.d(TAG, "User cancelled the AlertDialog");
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                break;
        }
        return super.onContextItemSelected(item);
    }

}