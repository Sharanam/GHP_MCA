package org.gdcst.jigneshsmart.fragmentdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button buttonFirstFragment;
    Button buttonSecondFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonFirstFragment = findViewById(R.id.buttonFirstFragment);
        buttonSecondFragment = findViewById(R.id.buttonSecondFragment);

        buttonFirstFragment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Fragment fragment = new FirstFragment();
//                Bundle bundle = new Bundle();
//                bundle.putString("param1", "This is the First Fragment param1");
//                bundle.putInt("param2", 987654321);
//                fragment.setArguments(bundle);

                Fragment fragment = FirstFragment.newInstance("This is the First Fragment param1", 987654321);
                loadFragment(fragment);
            }
        });

        buttonSecondFragment.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

//            Fragment fragment = new SecondFragment();
//            Bundle bundle = new Bundle();
//            bundle.putString("param1", "This is the Second Fragment param1");
//            bundle.putFloat("param2", 1234.56f);
//            fragment.setArguments(bundle);

            Fragment fragment = SecondFragment.newInstance("This is the Second Fragment param1", 1234.56f);
            loadFragment(fragment);
            }
        });

    }

    private void loadFragment(Fragment fragment)
    {
        //create fragment Manager
        FragmentManager fragmentManager = getFragmentManager();
        // create fragment transaction
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        //replace the FrameLayout with the new Fragment
        fragmentTransaction.replace(R.id.frameLayout1, fragment);
        fragmentTransaction.commit();
    }

}