package org.gdcst.jigneshsmart.menudemo;

import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MenuDemo";

    CheckBox checkBoxTAndC;
    TextView textViewTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkBoxTAndC = findViewById(R.id.checkBoxTAndC);
        textViewTest = findViewById(R.id.textViewTest);

        registerForContextMenu(checkBoxTAndC);
        registerForContextMenu(textViewTest);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

//        if (id == R.id.action_settings) {
//            Toast.makeText(getApplicationContext(), "Settings not implemented yet.", Toast.LENGTH_LONG).show();
//            return true;
//        }

        switch (id)
        {
            case R.id.action1:
                Toast.makeText(getApplicationContext(), "Action 1", Toast
                        .LENGTH_SHORT).show();
                return true;
            case R.id.action2:
                Toast.makeText(getApplicationContext(), "Action 2", Toast
                        .LENGTH_SHORT).show();
                return true;
            case R.id.action3:
                Toast.makeText(getApplicationContext(), "Action 3", Toast
                        .LENGTH_SHORT).show();
                return true;
            case R.id.action4:
                Toast.makeText(getApplicationContext(), "Action 4", Toast
                        .LENGTH_SHORT).show();
                return true;
            case R.id.action5:
                Toast.makeText(getApplicationContext(), "Action 5", Toast
                        .LENGTH_SHORT).show();
                return true;
            case R.id.action6:
                Toast.makeText(getApplicationContext(), "Action 6", Toast
                        .LENGTH_SHORT).show();
                return true;
            case R.id.action7:
                Toast.makeText(getApplicationContext(), "Action 7", Toast
                        .LENGTH_SHORT).show();
                return true;
            case R.id.action_settings:
                Toast.makeText(getApplicationContext(), "Settings not " +
                        "implemented yet", Toast.LENGTH_SHORT).show();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        int viewId = v.getId();
        switch (viewId) {
            case R.id.checkBoxTAndC:
                getMenuInflater().inflate(R.menu.context_menu_checkbox, menu);
                break;
            case R.id.textViewTest:
                getMenuInflater().inflate(R.menu.context_menu_textview, menu);
                break;
        }
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        switch (itemId) {
            case R.id.contextMenuCheckboxShow:
                boolean isChecked = checkBoxTAndC.isChecked();
                Log.d(TAG, "Context menu item 'Show' called on checkbox... ");
                Log.d(TAG, "isChecked: " + isChecked);
                String checkboxStatus = isChecked ? "checked" : "not checked";
                Toast.makeText(this, "Checkbox T&C " + checkboxStatus, Toast.LENGTH_SHORT).show();
                return true;
            case R.id.contextMenuCheckboxClear:
                Log.d(TAG, "Context menu item 'Clear' called on checkbox... ");
                checkBoxTAndC.setChecked(false);
                Toast.makeText(this, "Checkbox T&C cleared", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.contextMenuTextViewShow:
                String textViewText = textViewTest.getText().toString();
                Log.d(TAG, "Context menu item 'Show' called on textView... ");
                Log.d(TAG, "textViewText: " + textViewText);
                Toast.makeText(this, "textViewText: " + textViewText, Toast.LENGTH_SHORT).show();
                return true;
            case R.id.contextMenuTextViewClear:
                Log.d(TAG, "Context menu item 'Clear' called on textView... ");
                textViewTest.setText("");
                Toast.makeText(this, "TextView cleared", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.contextMenuTextViewSetDefault:
                Log.d(TAG, "Context menu item 'Set Default' called on textView... ");
                String defaultString = getString(R.string.enter_something);
                textViewTest.setText(defaultString);
                Toast.makeText(this, "TextView text set to default", Toast.LENGTH_SHORT).show();
                return true;
        }
        return super.onContextItemSelected(item);
    }
}
