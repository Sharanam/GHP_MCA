package org.gdcst.jigneshsmart.logindemo;

import static org.gdcst.jigneshsmart.logindemo.MainActivity.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class Details extends AppCompatActivity {

    TextView textViewWelcomeMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        textViewWelcomeMessage = findViewById(R.id.textViewWelcomeMessage);
        Intent intent = getIntent();
        String userName = intent.getStringExtra("userName");
        int userId = intent.getIntExtra("userId", -1);
        Log.d(TAG, "userId=" + userId);
        String welcomeMessage;
        if (userName == null) {
            welcomeMessage = "Welcome user!";
        } else {
            welcomeMessage = "Welcome " + userName + "!";
        }
        textViewWelcomeMessage.setText(welcomeMessage);
    }
}