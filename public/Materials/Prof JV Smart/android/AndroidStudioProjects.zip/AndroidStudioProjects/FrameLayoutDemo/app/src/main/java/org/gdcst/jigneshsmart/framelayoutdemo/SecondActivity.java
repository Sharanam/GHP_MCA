package org.gdcst.jigneshsmart.framelayoutdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    private int currentImage = 1;
    private final int maxImages = 5;

    ImageView imageView2;
    TextView textViewDescription2;
    Button buttonPrevious;
    Button buttonNext;
    Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        imageView2 = findViewById(R.id.imageView2);
        textViewDescription2 = findViewById(R.id.textViewDescription2);
        buttonPrevious = findViewById(R.id.buttonPrevious);
        buttonNext = findViewById(R.id.buttonNext);
        button2 = findViewById(R.id.button2);

        setImageAndDescription(imageView2, textViewDescription2);

        buttonPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentImage == 1)
                    currentImage = maxImages;
                else
                    currentImage--;
                setImageAndDescription(imageView2, textViewDescription2);
            }
        });

        buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentImage == maxImages)
                    currentImage = 1;
                else
                    currentImage++;
                setImageAndDescription(imageView2, textViewDescription2);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentThirdActivity = new Intent(SecondActivity.this,
                        ThirdActivity.class);
                startActivity(intentThirdActivity);
            }
        });
    }

    void setImageAndDescription(ImageView imageView2, TextView textVewDescription2) {
        switch (currentImage) {
            case 1:
                imageView2.setImageResource(R.drawable.image1);
                textVewDescription2.setText(R.string.first_image);
                break;
            case 2:
                imageView2.setImageResource(R.drawable.image2);
                textVewDescription2.setText("Second Image");
                break;
            case 3:
                imageView2.setImageResource(R.drawable.image3);
                textVewDescription2.setText("Third Image");
                break;
            case 4:
                imageView2.setImageResource(R.drawable.image4);
                textVewDescription2.setText("Fourth Image");
                break;
            case 5:
                imageView2.setImageResource(R.drawable.image5);
                textVewDescription2.setText("Fifth Image");
                break;
        }
    }

}