package org.gdcst.jigneshsmart.handleintenttexthtml;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity
{

    public String TAG;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TAG = getApplication().getPackageName();
        textView = (TextView) findViewById(R.id.textViewContents);
        Intent intent = getIntent();
        Log.i(TAG, "intent.getComponent()=" + intent.getComponent());
        if (intent.getCategories() != null)
            for (String category : intent.getCategories())
            {
                Log.i(TAG, "category=" + category);
            }
        String action = intent.getAction();
        Log.i(TAG, "intent.getAction()=" + action);
        String mimeType = intent.getType();
        Log.i(TAG, "intent.getType()=" + mimeType);
        Uri contentUri = intent.getData();
        if (contentUri != null)
        {
            Log.i(TAG, "intent.getData()=" + contentUri.toString());
            Object params[] = {contentUri, this};
            LoadFile loadFile = new LoadFile();
            loadFile.execute(params);
        }
        Bundle extrasBundle = intent.getExtras();
        if (extrasBundle == null) {
            Log.i(TAG, "extrasBundle is null");
        } else {
            for (String key : extrasBundle.keySet()) {
                Log.i(TAG, "Key: " + key + " Value: " + extrasBundle.get(key));
            }
            contentUri = (Uri)extrasBundle.get("android.intent.extra.STREAM");
            Log.d(TAG, "contentUri in Extras: " + contentUri);
            Object params[] = {contentUri, this};
            LoadFile loadFile = new LoadFile();
            loadFile.execute(params);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings)
        {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    class LoadFile extends AsyncTask<Object, Void, String>
    {

        @Override
        protected String doInBackground(Object... params)
        {
            Uri contentUri = (Uri) params[0];
            Context context = (Context) params[1];
            StringBuilder stringBuilder = new StringBuilder();
            char[] buffer = new char[1024];
            try
            {
                InputStream inputStream = context.getContentResolver()
                        .openInputStream(contentUri);
                BufferedReader bufferedReader = new BufferedReader(
                        new InputStreamReader(inputStream));
                int readCount;
                while (true)
                {
                    readCount = bufferedReader.read(buffer);
                    if (readCount == -1)
                        break;
                    stringBuilder.append(buffer, 0, readCount);
                }
                return stringBuilder.toString();
            } catch (FileNotFoundException e)
            {
                return "FileNotFoundException reading " + contentUri.toString();
            } catch (IOException e)
            {
                return "IOException reading " + contentUri.toString();
            }
        }

        @Override
        protected void onPostExecute(String result)
        {
            textView.setText(result);
            super.onPostExecute(result);
        }
    }

}
