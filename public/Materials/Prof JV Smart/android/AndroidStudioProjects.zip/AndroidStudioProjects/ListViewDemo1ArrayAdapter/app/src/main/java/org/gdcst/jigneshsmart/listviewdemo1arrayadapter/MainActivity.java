package org.gdcst.jigneshsmart.listviewdemo1arrayadapter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "ListViewDemo1Adapter";

    ListView listViewNames;
    Button buttonContacts;

    String[] names = { "Diane Murphy", "Mary Patterson", "Jeff Firrelli", "William Patterson", "Gerard Bondur", "Anthony Bow", "Leslie Jennings", "Leslie Thompson", "Julie Firrelli", "Steve Patterson", "Foon Yue Tseng", "George Vanauf", "Loui Bondur", "Gerard Hernandez", "Pamela Castillo", "Larry Bott", "Barry Jones", "Andy Fixter", "Peter Marsh", "Tom King", "Mami Nishi", "Yoshimi Kato", "Martin Gerard"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listViewNames = findViewById(R.id.listViewNames);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                names);
        listViewNames.setAdapter(adapter);
        buttonContacts = findViewById(R.id.buttonContacts);
        buttonContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ContactsActivity.class);
                startActivity(intent);
            }
        });
    }
}