package org.gdcst.jigneshsmart.listviewdemo1arrayadapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;
import static org.gdcst.jigneshsmart.listviewdemo1arrayadapter.MainActivity.TAG;

public class MyContactsArrayAdapter extends BaseAdapter {

    Context context;
    int layoutResourceId;
    List<Contact> list;

    MyContactsArrayAdapter(Context context, int layoutResourceId, List<Contact> list) {
        super();
        this.context = context;
        this.layoutResourceId = layoutResourceId;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Contact contact = list.get(position);
        if (convertView == null) {
            Log.i(TAG, "Creating view for position:" + position);
            LayoutInflater layoutInflater =
                    (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.listitem, null);
        } else {
            Log.i(TAG, "Reusing view for position:" + position);
        }
        TextView textViewListItemName = convertView.findViewById(R.id.textViewListItemName);
        TextView textViewListItemNumber = convertView.findViewById(R.id.textViewListItemNumber);
        textViewListItemName.setText(contact.getName());
        textViewListItemNumber.setText(contact.getNumber());
        return convertView;
    }
}

