package org.gdcst.jigneshsmart.listviewdemo1arrayadapter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ContactsActivity extends AppCompatActivity {

    ArrayList<Contact> contacts;
    ListView listViewContacts2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
        insertContacts();
        listViewContacts2 = findViewById(R.id.listViewContacts2);
        MyContactsArrayAdapter adapter = new MyContactsArrayAdapter(this, R.layout.listitem, contacts);
        listViewContacts2.setAdapter(adapter);
    }

    void insertContacts() {
        contacts = new ArrayList<>();
        contacts.add(new Contact("Diane Murphy", "9510278609"));
        contacts.add(new Contact("Mary Patterson", "8114763215"));
        contacts.add(new Contact("Jeff Firrelli", "8769884904"));
        contacts.add(new Contact("William Patterson", "9188105486"));
        contacts.add(new Contact("Gerard Bondur", "8215295508"));
        contacts.add(new Contact("Anthony Bow", "9709568274"));
        contacts.add(new Contact("Leslie Jennings", "7261113785"));
        contacts.add(new Contact("Leslie Thompson", "8387171650"));
        contacts.add(new Contact("Julie Firrelli", "9294545919"));
        contacts.add(new Contact("Steve Patterson", "7046475931"));
        contacts.add(new Contact("Foon Yue Tseng", "7475358639"));
        contacts.add(new Contact("George Vanauf", "9655596504"));
        contacts.add(new Contact("Loui Bondur", "8117181453"));
        contacts.add(new Contact("Gerard Hernandez", "8090548904"));
        contacts.add(new Contact("Pamela Castillo", "7523275153"));
        contacts.add(new Contact("Larry Bott", "9191251030"));
        contacts.add(new Contact("Barry Jones", "7184868552"));
        contacts.add(new Contact("Andy Fixter", "9800605381"));
        contacts.add(new Contact("Peter Marsh", "8819685658"));
        contacts.add(new Contact("Tom King", "8930083110"));
        contacts.add(new Contact("Mami Nishi", "9131240068"));
        contacts.add(new Contact("Yoshimi Kato", "7221621933"));
        contacts.add(new Contact("Martin Gerard", "9112514598"));
    }
}