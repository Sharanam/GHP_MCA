package org.gdcst.jigneshsmart.androidinternal2021;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    TextView textViewEntryName;
    TextView textViewEntryGender;
    TextView textViewEntrySports;
    TextView textViewEntryMobileNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        textViewEntryName = findViewById(R.id.textViewEntryName);
        textViewEntryGender = findViewById(R.id.textViewEntryGender);
        textViewEntrySports = findViewById(R.id.textViewEntrySports);
        textViewEntryMobileNumber = findViewById(R.id.textViewEntryMobileNumber);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            String name = bundle.getString("name");
            String gender = bundle.getString("gender");
            String sports = bundle.getString("sports");
            String mobileNumber = bundle.getString("mobileNumber");

            textViewEntryName.setText(name);
            textViewEntryGender.setText(gender);
            textViewEntrySports.setText(sports);
            textViewEntryMobileNumber.setText(mobileNumber);
        }
    }
}