package org.gdcst.jigneshsmart.androidinternal2021;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    EditText editTextName;
    RadioButton radioButtonMale;
    RadioButton radioButtonFemale;
    CheckBox checkBoxPool;
    CheckBox checkBoxSnooker;
    EditText editTextMobileNumber;
    Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextName = findViewById(R.id.editTextName);
        radioButtonMale = findViewById(R.id.radioButtonMale);
        radioButtonFemale = findViewById(R.id.radioButtonFemale);
        checkBoxPool = findViewById(R.id.checkBoxPool);
        checkBoxSnooker = findViewById(R.id.checkBoxSnooker);
        editTextMobileNumber = findViewById(R.id.editTextMobileNumber);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentDisplayActivity =
                        new Intent(MainActivity.this, DisplayActivity.class);
                String name = editTextName.getText().toString();
                String gender;
                if (radioButtonMale.isChecked()) {
                    gender = "Male";
                } else if (radioButtonFemale.isChecked()) {
                    gender = "Female";
                } else {
                    gender = "";
                }
                String sports = null;
                if (checkBoxPool.isChecked()) {
                    sports = "Pool";
                }
                if (checkBoxSnooker.isChecked()) {
                    if (sports == null) {
                        sports = "Snookers";
                    } else {
                        sports = sports + ", Snookers";
                    }
                }
                String mobileNumber;
                mobileNumber = editTextMobileNumber.getText().toString();
                intentDisplayActivity.putExtra("name", name);
                intentDisplayActivity.putExtra("gender", gender);
                intentDisplayActivity.putExtra("sports", sports);
                intentDisplayActivity.putExtra("mobileNumber", mobileNumber);
                startActivity(intentDisplayActivity);
            }
        });
    }
}