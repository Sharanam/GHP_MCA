package org.gdcst.jigneshsmart.layoutsdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button buttonConstraintLayoutActivity;
    Button buttonLinearLayoutActivity;
    Button buttonRelativeLayoutActivity;
    Button buttonTableLayoutActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonConstraintLayoutActivity = findViewById(R.id.buttonConstraintLayoutActivity);
        buttonConstraintLayoutActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ConstraintLayoutActivity.class);
                startActivity(intent);
            }
        });

        buttonLinearLayoutActivity = findViewById(R.id.buttonLinearLayoutActivity);
        buttonLinearLayoutActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LinearLayoutActivity.class);
                startActivity(intent);
            }
        });

        buttonRelativeLayoutActivity = findViewById(R.id.buttonRelativeLayoutActivity);
        buttonRelativeLayoutActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, RelativeLayoutActivity.class);
                startActivity(intent);
            }
        });

        buttonTableLayoutActivity = findViewById(R.id.buttonTableLayoutActivity);
        buttonTableLayoutActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TableLayoutActivity.class);
                startActivity(intent);
            }
        });
    }
}