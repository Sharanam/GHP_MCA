package org.gdcst.jigneshsmart.implicitintentdemo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import org.gdcst.jigneshsmart.implicitintentdemo.databinding.ActivityMainBinding;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "ImplicitIntentDemo";

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    Context applicationContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        applicationContext = getApplicationContext();

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                Intent implicitIntent;
//                Uri uri = Uri.parse("tel:1234567890");
//                implicitIntent = new Intent(Intent.ACTION_DIAL, uri);

//                implicitIntent = new Intent();
//                implicitIntent.setAction(Intent.ACTION_PICK);
//                implicitIntent.setType("image/*");
//                Toast.makeText(MainActivity.this, "Before startActivity()...",
//                        Toast.LENGTH_SHORT).show();
//                startActivityForResult(implicitIntent, 123);
//                Toast.makeText(MainActivity.this, "After startActivity()...",
//                        Toast.LENGTH_SHORT).show();

//                StringBuilder sb = new StringBuilder();
//                sb.append("aaaa\nbbbb\ncccc\ndddd");
//                implicitIntent = new Intent(Intent.ACTION_SEND);
//                implicitIntent.setType("text/plain");
//                implicitIntent.putExtra(Intent.EXTRA_TEXT, sb.toString());
//                implicitIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//                Intent shareIntent = Intent.createChooser(implicitIntent, null);
//                startActivity(shareIntent);

//                String image_path = "/sdcard/Download/MyTimeTable-JS.txt";
                String image_path = "/sdcard/Download/Cherry_Tree_in_Lakones_by_elenastravoravdi.jpg";
                File file = new File(image_path);
//                No longer works since Nougat
//                Uri uri = Uri.fromFile(file);
                MediaScannerConnection.scanFile(applicationContext,
                        new String[]{file.getAbsolutePath()},
                        null /*mimeTypes*/, new MediaScannerConnection.OnScanCompletedListener() {
                    @Override
                    public void onScanCompleted(String s, Uri uri) {
                        // uri is in format content://...
                        Log.d(TAG, "contentUri: " + uri);
                        Intent intent;
                        intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("image/*");
                        intent.putExtra(Intent.EXTRA_STREAM, uri);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(intent);
                    }
                });

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode) {
            case 123:
                if (resultCode == Activity.RESULT_OK) {
                    Log.d(TAG, "Image pick successful");
                    if (data != null) {
                        Bundle dataBundle = data.getExtras();
                        if (dataBundle == null) {
                            Log.d(TAG, "Extras bundle is null");
                        } else {
                            for (String key : dataBundle.keySet()) {
                                Log.d(TAG, "key=" + key + " value=" + dataBundle.get(key));
                            }
                        }
                        Uri dataUri = data.getData();
                        Log.d(TAG, "dataUri=" + dataUri);
                    }
                } else if (resultCode == Activity.RESULT_CANCELED) {
                    Log.d(TAG, "Image pick cancelled");
                } else {
                    Log.d(TAG, "Image pick terminated");
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}