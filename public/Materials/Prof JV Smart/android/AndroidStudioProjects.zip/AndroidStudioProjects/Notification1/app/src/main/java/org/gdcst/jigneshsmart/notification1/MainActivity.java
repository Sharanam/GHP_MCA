package org.gdcst.jigneshsmart.notification1;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "Notification1";

    EditText editTextNotificationId;
    EditText editTextNotificationContent;
    Button buttonMissedCallNotification;
    Button buttonNewsNotification;
    boolean hasPostNotificationPermission;
    private static int requestCode = 1;

//    Declared below
//        private ActivityResultLauncher<String> requestPermissionLauncher =

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNotificationId = findViewById(R.id.editTextNotificationId);
        editTextNotificationContent = findViewById(R.id.editTextNotificatonContent);
        buttonMissedCallNotification = findViewById(R.id.buttonMissedCallNotification);
        buttonNewsNotification = findViewById(R.id.buttonNewsNotification);
        hasPostNotificationPermission = false;

        Intent creatorIntent = getIntent();
        String notificationContent = creatorIntent.getStringExtra("notification_content");
        if (notificationContent != null) {
            Log.d(TAG, "notificationContent:" + notificationContent);
            Toast.makeText(this, notificationContent, Toast.LENGTH_LONG).show();
        }

        createNotificationChannel("MISSED_CALL", "Missed Call",
                "Missed call notification channel", NotificationManager.IMPORTANCE_HIGH);
        createNotificationChannel("NEWS_CHANNEL", "News Channel",
                "News notification channel", NotificationManager.IMPORTANCE_LOW);

        buttonMissedCallNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateNotification("MISSED_CALL", "Missed Call");
            }
        });

        buttonNewsNotification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateNotification("NEWS_CHANNEL", "Breaking News");
            }
        });

    }

    private void generateNotification(String channelId, String notificationTitle) {
        if (!hasPostNotificationPermission) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkAndRequestPermission();
                return;
            }
        }
        final NotificationManager notificationManager =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder notificationBuilder;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            notificationBuilder = new Notification.Builder(this);
        } else {
            notificationBuilder = new Notification.Builder(this, channelId);
        }
        notificationBuilder.setContentTitle(notificationTitle);
        String notificationContent = editTextNotificationContent.getText().toString();
        notificationBuilder.setContentText(notificationContent);
        Log.d(TAG, "channelId:" + channelId);
        switch (channelId) {
            case "MISSED_CALL":
                notificationBuilder.setSmallIcon(R.drawable.ic_notification_missed_call);
                break;
            case "NEWS_CHANNEL":
                notificationBuilder.setSmallIcon(R.drawable.ic_notification_news);
                break;
            default:
                notificationBuilder.setSmallIcon(R.drawable.ic_notification_news);
        }
//        notificationBuilder.setSmallIcon(R.drawable.ic_notification_missed_call);
        Intent intentNotification1 = new Intent(this, MainActivity.class);
        intentNotification1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intentNotification1.putExtra("notification_content", notificationContent);
        notificationBuilder.setContentIntent(PendingIntent.getActivity(
                this,
                requestCode++,
                intentNotification1,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        ));
        notificationBuilder.setAutoCancel(true);
        Notification notification = notificationBuilder.build();
// notificationId is an integer id unique for this type of notifications
        int notificationId = Integer.parseInt(editTextNotificationId.getText().toString());
        notificationManager.notify(notificationId, notification);
    }

    private void createNotificationChannel(String channelId, String channelName,
                                           String channelDescription, int channelImportance) {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelName, channelImportance);
            channel.setDescription(channelDescription);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    void checkAndRequestPermission() {
        Context context = getApplicationContext();
        if (context.checkSelfPermission(
                Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            // You can use the API that requires the permission.
            hasPostNotificationPermission = true;
//            NOT REQUIRED ANY MORE?
//        } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
            // In an educational UI, explain to the user why your app requires this
            // permission for a specific feature to behave as expected. In this UI,
            // include a "cancel" or "no thanks" button that allows the user to
            // continue using your app without granting the permission.
//            DO THIS IN onRequestPermissionsResult()
//            showInContextUI(...);
        } else {
            // You can directly ask for the permission.
            // The registered ActivityResultCallback gets the result of this request.
            requestPermissionLauncher.launch(
                    Manifest.permission.POST_NOTIFICATIONS);
        }

    }

    // Register the permissions callback, which handles the user's response to the
    // system permissions dialog. Save the return value, an instance of
    // ActivityResultLauncher, as an instance variable.
    private ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    // Permission is granted. Continue the action or workflow in your
                    // app.
                    hasPostNotificationPermission = true;
                } else {
                    // Explain to the user that the feature is unavailable because the
                    // features requires a permission that the user has denied. At the
                    // same time, respect the user's decision. Don't link to system
                    // settings in an effort to convince the user to change their
                    // decision.
                    if (ActivityCompat.shouldShowRequestPermissionRationale(
                            this, Manifest.permission.POST_NOTIFICATIONS)) {
                        //Show permission explanation dialog...
                        AlertDialog.Builder builder = new AlertDialog.Builder(this);
                        builder.setTitle("POST_NOTIFICATION permiss5on needed");
                        builder.setMessage("The app needs the POST_NOTIFICATION permission to be able to generate notifications");
                        builder.setIcon(R.mipmap.ic_launcher);
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Log.d(TAG, "OK selected by the user in permission explanation dialog");
                            }
                        });
                        builder.setCancelable(false);
                        AlertDialog alertDialog = builder.create();
                        alertDialog.show();
                    }else {
                        //Never ask again selected, or device policy prohibits the app from having that permission.
                        //So, disable that feature, or fall back to another situation...
                        Toast.makeText(this,
                                "Notification functionality is disabled because POST_NOTIFICATION permission not granted",
                                Toast.LENGTH_LONG).show();
                    }
                }
            });

}
