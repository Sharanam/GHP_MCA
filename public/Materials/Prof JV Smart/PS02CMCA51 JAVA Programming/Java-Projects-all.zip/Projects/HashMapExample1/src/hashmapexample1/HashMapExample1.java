/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmapexample1;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

class Student
{
    public String name;
    public String Programme;
    public int semester;

    public Student(String name, String Programme, int semester)
    {
        this.name = name;
        this.Programme = Programme;
        this.semester = semester;
    }

    @Override
    public String toString()
    {
        return "Student{" + "name=" + name + ", Programme=" + Programme + ", semester=" + semester + '}';
    }

/*
    @Override
    public int hashCode()
    {
        int hash = 7;
        hash = 29 * hash + Objects.hashCode(this.name);
        hash = 29 * hash + Objects.hashCode(this.Programme);
        hash = 29 * hash + this.semester;
        return hash;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (getClass() != obj.getClass())
        {
            return false;
        }
        final Student other = (Student) obj;
        if (this.semester != other.semester)
        {
            return false;
        }
        if (!Objects.equals(this.name, other.name))
        {
            return false;
        }
        if (!Objects.equals(this.Programme, other.Programme))
        {
            return false;
        }
        return true;
    }
*/
    
}

/**
 *
 * @author jignesh
 */
public class HashMapExample1
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        HashMap<Integer, Student> studentsMap = new HashMap<>();
        studentsMap.put(1, new Student("aaa", "MCA", 3));
        studentsMap.put(2, new Student("bbb", "MCA", 5));
        studentsMap.put(3, new Student("ccc", "MSc(IT)", 3));
        studentsMap.put(4, new Student("ddd", "PGDCA", 1));
        System.out.println(studentsMap.size());
        
        for (Integer key : studentsMap.keySet())
        {
            System.out.println("key=" + key);
        }
        System.out.println("----------------------");
        
        for (Student value : studentsMap.values())
        {
            System.out.println("value=" + value);
        }
        System.out.println("----------------------");
        
        for (Integer key : studentsMap.keySet())
        {
            System.out.println("key=" + key + " value=" + studentsMap.get(key));
        }
        System.out.println("----------------------");
        
        for (Map.Entry<Integer, Student> entry : studentsMap.entrySet())
        {
            System.out.println("entry.getKey()=" + entry.getKey() +
                    " entry.getValue()=" + entry.getValue());
        }
        System.out.println("----------------------");
        
        System.out.println("studentsMap.containsKey(3)=" +
                studentsMap.containsKey(3));
        System.out.println("studentsMap.containsKey(5)=" +
                studentsMap.containsKey(5));
        
        Student student = new Student("bbb", "MCA", 5);
        System.out.println("studentsMap.containsValue(student)=" +
                studentsMap.containsValue(student));
             
        System.out.println("--- before change ---");
        for (Map.Entry<Integer, Student> entry : studentsMap.entrySet())
        {
            System.out.println("entry.getKey()=" + entry.getKey() +
                    " entry.getValue()=" + entry.getValue());
        }
        
        studentsMap.put(3, new Student("qqq", "MPhil(Computer Science)", 1));
        System.out.println("--- after change ---");
        for (Map.Entry<Integer, Student> entry : studentsMap.entrySet())
        {
            System.out.println("entry.getKey()=" + entry.getKey() +
                    " entry.getValue()=" + entry.getValue());
        }
        System.out.println("----------------------");
     
        Set<Integer> listOfKeys = studentsMap.keySet();
//        java.lang.UnsupportedOperationException
//        listOfKeys.add(5);
        listOfKeys.remove(1);
        for (Map.Entry<Integer, Student> entry : studentsMap.entrySet())
        {
            System.out.println("entry.getKey()=" + entry.getKey() + " entry.getValue()=" + entry.getValue());
        }

        
        studentsMap.clear();
        System.out.println("--- after clear ---");
        System.out.println("size()=" + studentsMap.size());
    }
    
}
