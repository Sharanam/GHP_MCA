/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fileinputstreamfileoutputstreamExample1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author system
 */
public class FileInputStreamFileOutputStream
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        byte[] data = {12, -34, 127, -128, 0, 15};
        try
        {
            FileOutputStream fos = new FileOutputStream("data");
            for (byte byt : data)
                fos.write(byt);
            fos.close();
        } catch (FileNotFoundException ex)
        {
            ex.printStackTrace();
        }
        catch (IOException ioex)
        {
            ioex.printStackTrace();
        }
        try
        {
            FileInputStream fis = new FileInputStream("data");
            while (true)
            {
                int b = fis.read();
                if (b == -1)
                    break;
                else
                    System.out.print("b="+(byte)b+" ");
            }
            System.out.println();
            fis.close();
        } catch (FileNotFoundException ex)
        {
            ex.printStackTrace();
        }
        catch (IOException ioex)
        {
            ioex.printStackTrace();
        }
    }
}
