/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enumerationexample1;

/**
 *
 * @author system
 */
public enum Programme
{
    MCA, PGDCA, MSC_IT, MPHIL_CS, PHD_CS
}
