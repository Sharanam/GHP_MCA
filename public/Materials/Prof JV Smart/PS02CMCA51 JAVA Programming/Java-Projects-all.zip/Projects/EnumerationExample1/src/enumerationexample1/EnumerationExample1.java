/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enumerationexample1;

/**
 *
 * @author class
 */
public class EnumerationExample1
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Programme p;
        p = Programme.MCA;
        System.out.println("p1=" + p);
        p = Programme.MSC_IT;
        System.out.println("p2=" + p);
        BookType b;
        b = BookType.JOURNAL;
        System.out.println("b=" + b);
//        p = BookType.BOOK; //Compiler error
//        p = (Programme)BookType.BOOK; //Compiler error
        for (int i = 0;
                i < Programme.values().length;
                i++)
        {
            System.out.println("Programme=" +
                    Programme.values()[i]);
        }
        for (BookType bt : BookType.values())
        {
            System.out.println("BookType=" + bt);
        }
    }
}
