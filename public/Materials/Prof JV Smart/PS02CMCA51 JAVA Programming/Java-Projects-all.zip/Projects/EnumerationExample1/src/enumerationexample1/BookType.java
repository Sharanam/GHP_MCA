/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package enumerationexample1;

/**
 *
 * @author system
 */
public enum BookType
{
    BOOK, MAGAZINE, JOURNAL
}
