/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package androidcontrollertestclient;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author system
 */
public class AndroidControllerTestClient
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        byte[] inetAddressBinary =
        {
            127, 0, 0, 1
        };
        InputStream inputStream = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader bufferedReader = null;
        OutputStream outputStream = null;
        OutputStreamWriter outputStreamWriter = null;
        BufferedWriter bufferedWriter = null;
        try
        {
            InetAddress serverAddress = Inet4Address.getByAddress(
                    inetAddressBinary);
            System.out.
                    println("serverAddress=" + serverAddress.getHostAddress());
            Socket socket = new Socket(serverAddress, 54321);
            inputStream = socket.getInputStream();
            inputStreamReader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(inputStreamReader);
            String line = bufferedReader.readLine();
            if (line == null)
            {
                System.err.println("Error reading from BufferedReader");
                System.exit(1);
            }
            System.out.println("line=xxx" + line + "yyy");
            if (!line.equalsIgnoreCase("Connected"))
            {
                System.err.println("Error Connecting to server");
                System.exit(2);
            }
            outputStream = socket.getOutputStream();
            outputStreamWriter = new OutputStreamWriter(outputStream);
            bufferedWriter = new BufferedWriter(outputStreamWriter);
            Thread.sleep(5000);
            bufferedWriter.append("VK_UP\n");
            bufferedWriter.flush();
            Thread.sleep(5000);
            bufferedWriter.append("VK_LEFT\n");
            bufferedWriter.flush();
            Thread.sleep(5000);
            bufferedWriter.append("VK_RIGHT\n");
            bufferedWriter.flush();
            Thread.sleep(5000);
            bufferedWriter.append("VK_DOWN\n");
            bufferedWriter.flush();
            Thread.sleep(5000);
            bufferedWriter.append("bye\n");
            bufferedWriter.flush();
        }
        catch (IOException | InterruptedException ex)
        {
            Logger.getLogger(AndroidControllerTestClient.class.getName()).
                    log(Level.SEVERE, null, ex);
        }
    }
}
