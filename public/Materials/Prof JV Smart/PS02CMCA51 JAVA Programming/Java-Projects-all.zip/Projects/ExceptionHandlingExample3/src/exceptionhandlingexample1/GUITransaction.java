/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample1;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author class
 */
public class GUITransaction
{
    public static void calltransaction(int accountNumber,
            char transactionType, double amount) throws
            NoSuchAccountException, InsufficientBalanceException
    {
        System.out.println("Calling Transaction.performTransaction()...");
        try
        {
            System.out.println("Trying Transaction.performTransaction()");
            Transaction.performTransaction(accountNumber, transactionType, amount);
            System.out.println("Successfully tried Transaction.performTransaction()");
        }
        catch (TransactionException ex)
        {
//            System.err.println(ex);
            ex.printStackTrace();
        }
        System.out.println("Everything is allright");
    }
}
