/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample1;

/**
 *
 * @author class
 */
public class Transaction
{
  public static void performTransaction(int accountNumber,
            char transactionType, double amount) throws
          TransactionException
  {
      System.out.println("calling BusinessLogic.checkAllowedTransaction()...");
      try
      {
        BusinessLogic.checkAllowedTransaction(accountNumber, transactionType, amount);
      } catch (TransactionException ex)
      {
          System.out.println("TransactionException in performTransaction() " +
                  ex);
          throw ex;
      }
      System.out.println("Transaction succeeded");
  }
}
