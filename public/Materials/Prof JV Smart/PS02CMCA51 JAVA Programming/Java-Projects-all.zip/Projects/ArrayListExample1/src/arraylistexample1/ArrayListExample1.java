/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylistexample1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author jignesh
 */
public class ArrayListExample1
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
//        ArrayList<String> strings = new ArrayList<String>();
//        Diamond inference
        ArrayList<String> strings = new ArrayList<>();
//        ArrayList<int> a = new ArrayList<>();
//        ArrayList<Integer> a = new ArrayList<>();
        strings.add("aaa");
        strings.add("bbb");
        strings.add("ccc");
        System.out.println("strings.size()=" + strings.size());

        System.out.println("strings.get(1)=" + strings.get(1));
//        System.out.println("strings.get(3)=" + strings.get(3));
        
        System.out.println("--------------");
        strings.add(1, "zzz");
        System.out.println("strings.get(1)=" + strings.get(1));

        for (String s : strings)
        {
            System.out.println(s);
        }
        System.out.println("--------------");

        strings.remove(2);
        for (String s : strings)
        {
            System.out.println(s);
        }
        System.out.println("--------------");

        for (String s : strings)
        {
            if (s.equalsIgnoreCase("zzz"))
            {
                System.out.println("removing zzz");
                strings.remove(s);
            }
        }
        for (String s : strings)
        {
            System.out.println(s);
        }
        System.out.println("--------------");

        
        strings.set(1, "yyy");
        for (String s : strings)
        {
            System.out.println(s);
        }
        System.out.println("--------------");
        
        strings.clear();
        
        strings.add("aaa");
        strings.add("BBB");
        strings.add("eee");
        strings.add(null);
        strings.add("DDD");
        
//        Collections.sort(strings);
//        Collections.sort(strings, Collections.reverseOrder());
        strings.sort(new StringComparator());
        for (String s : strings)
        {
            System.out.println(s);
        }
        System.out.println("--------------");
        
        Collections.reverse(strings);
        for (String s : strings)
        {
            System.out.println(s);
        }
        System.out.println("--------------");
        
//        Convert ArrayList<> to array of objects
        Object[] objectArray = new String[1];
        objectArray = strings.toArray();
        
//        Convert ArrayList<> to array of String
        String[] stringArray = new String[1];
        stringArray = (String[])strings.toArray(stringArray);
        System.out.println("stringArray.length=" + stringArray.length);
        
//        Convert array to ArrayList
        strings = new ArrayList<>(Arrays.asList(stringArray));
    }
    
}

class StringComparator implements Comparator<String>
{

    @Override
    public int compare(String o1, String o2)
    {
        if (o1 == null && o2 == null)
            return 0;
        if (o1 == null)
            return -1;
        if (o2 == null)
            return 1;
        if (o1.equalsIgnoreCase(o2))
            return 0;
        return o1.compareToIgnoreCase(o2);
    }
    
}
