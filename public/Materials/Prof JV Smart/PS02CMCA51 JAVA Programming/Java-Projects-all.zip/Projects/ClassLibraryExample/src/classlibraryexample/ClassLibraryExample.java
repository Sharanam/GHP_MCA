/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package classlibraryexample;

import inheritanceexample3.Employee;
import inheritanceexample3.Manager;
import inheritanceexample3.Person;

/**
 *
 * @author class
 */
public class ClassLibraryExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Person p1 = new Person("aaaq bbb");
        System.out.println(p1.firstName());
        Employee e1 = new Employee(1232, "ddd eee", "Programmer");
        System.out.println("e1="+e1);
        System.out.println("isProgrammer="+e1.isProgrammer());
        Manager m1 = new Manager(222, "ddd", "rrr", "Sales");
        System.out.println("m1="+m1);
        System.out.println("departmentName="+m1.getDepartmentName());
    }
}
