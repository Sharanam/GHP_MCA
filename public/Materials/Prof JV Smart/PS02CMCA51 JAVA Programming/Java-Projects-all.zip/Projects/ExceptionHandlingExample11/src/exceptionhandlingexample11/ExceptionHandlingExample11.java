/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample11;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jignesh
 */
public class ExceptionHandlingExample11
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception
    {
        String inputFilename = null, line;

        if (args.length != 1)
        {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        }
        else
        {
            inputFilename = args[0];
        }

        File inputFile = new File(inputFilename);
        try (FileReader fr = new FileReader(inputFile);
                BufferedReader br = new BufferedReader(fr);)
        {

            while (true)
            {
                try
                {
                    line = br.readLine();
                    if (line == null)
                    {
                        break;
                    }
                    System.out.println(line);
                }
                catch (IOException ex)
                {
                    System.err.println("IOException: " + ex.
                            getLocalizedMessage());
                    throw ex;
                }
            }
            System.out.println("File copied successfully");
        }
        catch (FileNotFoundException ex)
        {
            System.err.println("FileNotFoundException: " + ex.
                    getLocalizedMessage());
        }
        catch (IOException ex)
        {
            throw ex;
        }

    }

}
