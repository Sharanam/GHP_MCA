/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylistexample2;

import java.util.ArrayList;
import java.util.Comparator;

enum Medal
{
    GOLD, SILVER, BRONZE
};

class BadmintonPlayer
{

    private String name;
    private Medal highestOlympicsMedalWon;
    private int highestWorldRank;

    public BadmintonPlayer()
    {
        name = null;
        highestOlympicsMedalWon = null;
        highestWorldRank = -1;
    }

    BadmintonPlayer(String name, Medal highestOlympicsMedalWon,
            int highestWorldRank)
    {
        this.name = name;
        this.highestOlympicsMedalWon = highestOlympicsMedalWon;
        this.highestWorldRank = highestWorldRank;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public Medal getHighestOlympicsMedalWon()
    {
        return highestOlympicsMedalWon;
    }

    public void setHighestOlympicsMedalWon(
            Medal highestOlympicsMedalWon)
    {
        this.highestOlympicsMedalWon = highestOlympicsMedalWon;
    }

    public int getHighestWorldRank()
    {
        return highestWorldRank;
    }

    public void setHighestWorldRank(int highestWorldRank)
    {
        this.highestWorldRank = highestWorldRank;
    }

    @Override
    public boolean equals(Object o2)
    {
        if (o2 == null)
        {
            return false;
        }
        if (this == o2)
        {
            return true;
        }
        if (this.getClass() != o2.getClass())
        {
            return false;
        }
        final BadmintonPlayer p2 = (BadmintonPlayer) o2;
        if (this.name == null)
        {
            if (p2.name == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else if (p2.name == null)
        {
            return false;
        }
        else if (this.name.equals(p2.name))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    @Override
    public String toString()
    {
        return "BadmintonPlayer{" + "name=" + name +
                ", highestOlympicsMedalWon=" + highestOlympicsMedalWon +
                ", highestWorldRank=" + highestWorldRank + '}';
    }

}

/**
 *
 * @author jignesh
 */
public class ArrayListExample2
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        ArrayList<BadmintonPlayer> players = new ArrayList<>();
        players.add(new BadmintonPlayer("Sindhu", Medal.SILVER, 2));
        players.add(new BadmintonPlayer("Kashyap", null, 6));
        players.add(new BadmintonPlayer("Saina", Medal.BRONZE, 1));

        System.out.println("Original List");
        for (BadmintonPlayer p : players)
        {
            System.out.println(p);
        }
        System.out.println("--------------");

        players.sort(new PlayerNameComparator());
        System.out.println("List Sorted on Names");
        for (BadmintonPlayer p : players)
        {
            System.out.println(p);
        }
        System.out.println("--------------");

        players.sort(new PlayerRankComparator());
        System.out.println("List Sorted on HighestWorldRank");
        for (BadmintonPlayer p : players)
        {
            System.out.println(p);
        }
        System.out.println("--------------");

        players.sort(new PlayerMedalComparator());
        System.out.println("List Sorted on HighestOlympicMedalWon");
        for (BadmintonPlayer p : players)
        {
            System.out.println(p);
        }
        System.out.println("--------------");

    }

}

class PlayerNameComparator implements Comparator<BadmintonPlayer>
{

    @Override
    public int compare(BadmintonPlayer o1, BadmintonPlayer o2)
    {
        if (o1 == null && o2 == null)
        {
            return 0;
        }
        if (o1 == null)
        {
            return -1;
        }
        if (o2 == null)
        {
            return 1;
        }
        if (o1.equals(o2))
        {
            return 0;
        }
        return o1.getName().compareToIgnoreCase(o2.getName());
    }

}

class PlayerRankComparator implements Comparator<BadmintonPlayer>
{

    @Override
    public int compare(BadmintonPlayer o1, BadmintonPlayer o2)
    {
        if (o1 == null && o2 == null)
        {
            return 0;
        }
        if (o1 == null)
        {
            return -1;
        }
        if (o2 == null)
        {
            return 1;
        }
        if (o1.equals(o2))
        {
            return 0;
        }
        if (o1.getHighestWorldRank() < o2.getHighestWorldRank())
        {
            return -1;
        }
        else if (o1.getHighestWorldRank() == o2.getHighestWorldRank())
        {
            return 0;
        }
        else
        {
            return 1;
        }

    }

}

class PlayerMedalComparator implements Comparator<BadmintonPlayer>
{

    @Override
    public int compare(BadmintonPlayer o1, BadmintonPlayer o2)
    {
        if (o1 == null && o2 == null)
        {
            return 0;
        }
        if (o1 == null)
        {
            return -1;
        }
        if (o2 == null)
        {
            return 1;
        }
        if (o1.equals(o2))
        {
            return 0;
        }
        if (o1.getHighestOlympicsMedalWon() == Medal.GOLD)
        {
            if (o2.getHighestOlympicsMedalWon() == Medal.GOLD)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
        else if (o1.getHighestOlympicsMedalWon() == Medal.SILVER)
        {
            if (o2.getHighestOlympicsMedalWon() == Medal.GOLD)
            {
                return 1;
            }
            else if (o2.getHighestOlympicsMedalWon() == Medal.SILVER)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
        else if (o1.getHighestOlympicsMedalWon() == Medal.BRONZE)
        {
            if (o2.getHighestOlympicsMedalWon() == Medal.GOLD || o2.
                    getHighestOlympicsMedalWon() == Medal.SILVER)
            {
                return 1;
            }
            else if (o2.getHighestOlympicsMedalWon() == Medal.BRONZE)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
        else if (o2.getHighestOlympicsMedalWon() != null)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

}
