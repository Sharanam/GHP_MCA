/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package deserialization;

import deptemplibrary.Department;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author class
 */
public class Deserialization
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Department dept;
        File data = new File("data");
        try
        {
            InputStream is = new FileInputStream(data);
            ObjectInputStream ois = new ObjectInputStream(is);
            dept = (Department)ois.readObject();
            System.out.println(dept);
        }
        catch (FileNotFoundException ex)
        {
            Logger.getLogger(Deserialization.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (IOException ex)
        {
            Logger.getLogger(Deserialization.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (ClassNotFoundException ex)
        {
            Logger.getLogger(Deserialization.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
