/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package boxingunboxingexample1;

/**
 *
 * @author class
 */
public class BoxingUnboxingExample1
{

    static int addTenPrimitive(int no)
    {
        return no + 10;
    }
    static Integer addTenReference(Integer no)
    {
        Integer retval;
        // Convert Integer object
        // into primitive type int
        int no2 = no.intValue();
        no2 += 10;
        // Convert the primitive int
        // into Integer Objeect
        retval = new Integer(no2);
        return retval;
    }
    /**
     * @param args the command lin
     * e arguments
     */
    public static void main(String[] args)
    {
        Integer no1 = new Integer(20);
        Integer no2 = addTenReference(no1);
        System.out.println("no2="+no2);
        // Convert Integer object
        // into primitive type int
        // and pass to the method
        int no3 = addTenPrimitive(no2.intValue());
        // Convert the primitive int
        // into Integer Objeect
        Integer no4 = new Integer(no3);
        System.out.println("no4=" + no4);
        // When we use a primitive int
        // where an Integer object is expected
        // the compiler automatically boxes it
        // as is the case with the method argument
        // of addTenReference()

        // When we use a an Integer object
        // where a primitive int is expected
        // the compiler automatically unboxes it
        // as is the case with the return value
        // of addTenReference() being assigned
        // to an int
        
        int no5 = 50;
        no5 = addTenReference(no5);
        System.out.println("no5="+no5);
    }
}
