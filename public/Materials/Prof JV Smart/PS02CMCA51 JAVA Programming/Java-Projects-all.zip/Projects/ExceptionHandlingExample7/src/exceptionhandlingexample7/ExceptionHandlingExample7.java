/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample7;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author jignesh
 */
public class ExceptionHandlingExample7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                String inputFilename=null, line;

        if (args.length != 1)
        {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        }
        else
            inputFilename = args[0];

        File inputFile = new File(inputFilename);
        FileReader fr;
        try
        {
            fr = new FileReader(inputFile);
            BufferedReader br = new BufferedReader(fr);
            while (true)
            {
                line = br.readLine();
                if (line == null)
                    break;
                System.out.println(line);
        }
            br.close();
            fr.close();
        }
//        catch(Exception e)
//        {
//            System.err.println("Exception: " + e.getLocalizedMessage());
//        }
//        catch(IOException e)
//        {
//            System.err.println("Exception: " + e.getLocalizedMessage());
//        }
        catch(FileNotFoundException e)
        {
            System.err.println("Exception: " + e.getLocalizedMessage());
        }
        catch(IOException e)
        {
            System.err.println("Exception: " + e.getLocalizedMessage());
        }

    }
    
}
