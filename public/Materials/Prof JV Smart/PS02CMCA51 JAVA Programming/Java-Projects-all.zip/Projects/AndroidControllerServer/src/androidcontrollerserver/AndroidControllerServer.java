/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package androidcontrollerserver;

import com.sun.corba.se.impl.protocol.giopmsgheaders.Message;
import java.awt.AWTException;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

/**
 *
 * @author Jignesh Smart
 */
class AndroidControllerUI extends JFrame
{

    public JLabel caption;
    public JTextArea ipAddresses;
    public JTextArea messages;

    public AndroidControllerUI()
    {
        super(AndroidControllerServer.APPNAME);
        setSize(700, 550);
        GridLayout gridLayout = new GridLayout(3, 1);
        setLayout(gridLayout);
        setTitle(AndroidControllerServer.APPNAME);
        caption = new JLabel(AndroidControllerServer.APPNAME
                + " ver. 0.1 Jignesh Smart");
        caption.setHorizontalAlignment(SwingConstants.CENTER);
        caption.setToolTipText(AndroidControllerServer.APPNAME);
        add(caption, SwingConstants.CENTER);
        ArrayList<String> ipAddressesArray;
        try
        {
            ipAddressesArray = getIpAddresses();
        }
        catch (SocketException ex)
        {
            Logger.getLogger(AndroidControllerUI.class.getName()).
                    log(Level.SEVERE, null, ex);
            messages.append("\t" + ex);
            ipAddressesArray = new ArrayList<>();
        }

        StringBuilder sb = new StringBuilder();
        sb.append("IP Addresses of this computer:\n");
        for (String ipAddress : ipAddressesArray)
            sb.append("\t").append(ipAddress).append("\n");
        ipAddresses = new JTextArea(sb.toString());
        ipAddresses.setEditable(false);
        ipAddresses.setToolTipText("IP Addresses of this computer");
        add(ipAddresses);
        messages = new JTextArea("Messages:\n");
        messages.setEditable(false);
        messages.setToolTipText("Messages");
        add(messages);
    }

    public static ArrayList<String> getIpAddresses() throws SocketException
    {
        ArrayList<String> ipAddresses = new ArrayList<>();
        Enumeration<NetworkInterface> e = NetworkInterface.
                getNetworkInterfaces();
        while (e.hasMoreElements())
        {
            NetworkInterface n = e.nextElement();
            System.out.println("Interface name=" + n.getName());
            Enumeration<InetAddress> ee = n.getInetAddresses();
            while (ee.hasMoreElements())
            {
                InetAddress i = ee.nextElement();
                if (!i.isLoopbackAddress())
                {
                    String IPVersion;
                    if (i instanceof Inet4Address)
                        IPVersion = "IPv4";
                    else
                        IPVersion = "IPv6";
                    String ipAddressString = n.getDisplayName() + ":"
                            + IPVersion + ":" + i.
                            getHostAddress();
                    System.out.println("IP Address:\t" + ipAddressString);
                    ipAddresses.add(ipAddressString);
                }
            }
        }
        return ipAddresses;
    }
}

/**
 *
 * @author Jignesh Smart
 */
public class AndroidControllerServer
{

    public static final String APPNAME = "AndroidControllerServer";
    public static int SERVER_PORT = 54321;
    public static ArrayList<String> keyList;
    public static Map<String, Integer> keyMap;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        AndroidControllerUI androidControllerUI = new AndroidControllerUI();
        androidControllerUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        androidControllerUI.setVisible(true);
        loadJavaKeyList();
        InputStream inputStream = null;
        InputStreamReader inputStreamReader = null;
        BufferedReader bufferedReader = null;
        ServerSocket serverSocket = null;
        Socket socket = null;
        OutputStream outputStream = null;
        OutputStreamWriter outputStreamWriter = null;
        BufferedWriter bufferedWriter = null;
        Robot robot = null;
        try
        {
            serverSocket = new ServerSocket(SERVER_PORT);
            socket = serverSocket.accept();
            System.out.println("socket local ip=" + socket.getLocalAddress()
                    + ", port=" + socket.getLocalPort());
            System.out.println("socket remote ip=" + socket.
                    getRemoteSocketAddress());
            InetAddress rmoteIpAddress = socket.getInetAddress();
            outputStream = socket.getOutputStream();
            outputStreamWriter = new OutputStreamWriter(
                    outputStream);
            bufferedWriter = new BufferedWriter(outputStreamWriter);
            bufferedWriter.append("Connected\n");
            bufferedWriter.flush();
            inputStream = socket.getInputStream();
            inputStreamReader = new InputStreamReader(inputStream);
            bufferedReader = new BufferedReader(inputStreamReader);
            robot = new Robot();
            while (true)
            {
                String line = bufferedReader.readLine();
                if (line == null)
                    break;
                if (line.equalsIgnoreCase("bye"))
                    break;
                System.out.println("line=" + line);
                if (!keyList.contains(line))
                {
                    System.err.println("Invalid Key Code:" + line);
                    androidControllerUI.messages.append("\t"
                            + "Invalid Key Code:" + line);
                }
                else
                {
                    robot.keyPress(keyMap.get(line));
                    robot.keyRelease(keyMap.get(line));
                }

            }
        }
        catch (IOException | AWTException ex)
        {
            Logger.getLogger(AndroidControllerServer.class.getName()).
                    log(Level.SEVERE, null, ex);
            androidControllerUI.messages.append("\t" + ex);
        }
        finally
        {
            try
            {
                if (serverSocket != null)
                    if (!serverSocket.isClosed())
                        serverSocket.close();
                if (socket != null)
                    if (!socket.isClosed())
                        socket.close();
                if (bufferedReader != null)
                    bufferedReader.close();
                if (inputStreamReader != null)
                    inputStreamReader.close();
                if (bufferedWriter != null)
                    bufferedWriter.close();
                if (outputStreamWriter != null)
                    outputStreamWriter.close();
            }
            catch (IOException ex)
            {
            }
        }
        androidControllerUI.dispose();
    }

    public static void loadJavaKeyList()
    {
        keyList = new ArrayList<>();
        keyMap = new HashMap<String, Integer>();

        for (Field f : KeyEvent.class.getDeclaredFields())
        {
            try
            {
                if (java.lang.reflect.Modifier.isStatic(f.getModifiers()))
                {
                    f.setAccessible(true);
                    String name = f.getName();
                    Object value = f.get(null);
                    if (value instanceof Integer)
                    {
                        keyList.add(name);
                        keyMap.put(name, (Integer) value);
                    }
                }
            }
            catch (IllegalArgumentException | IllegalAccessException ex)
            {
            }
        }
    }
}
