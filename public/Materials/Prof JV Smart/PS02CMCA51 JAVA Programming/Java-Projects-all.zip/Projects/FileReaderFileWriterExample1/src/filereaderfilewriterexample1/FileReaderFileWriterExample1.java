/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package filereaderfilewriterexample1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author class
 */
public class FileReaderFileWriterExample1
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException
    {
        FileReader fr = null;
        FileWriter fw = null;
        try
        {
            if (args.length != 2)
            {
                System.err.println("Usage: java -jar FileReaderFileWriterExample1 inputTextFile outputTextFile");
                System.exit(1);
            }
            fr = new FileReader(args[0]);
            fw = new FileWriter(args[1]);
            while (true)
            {
                int ch = fr.read();
                if (ch == -1)
                    break;
                fw.write(ch);
            }
        }
        catch (FileNotFoundException ex)
        {
            Logger.getLogger(FileReaderFileWriterExample1.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
            fr.close();
            fw.close();
        }
        
    }
}
