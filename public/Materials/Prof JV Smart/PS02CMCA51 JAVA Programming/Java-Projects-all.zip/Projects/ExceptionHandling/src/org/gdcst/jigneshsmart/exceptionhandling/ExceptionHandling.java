package org.gdcst.jigneshsmart.exceptionhandling;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class TestException extends Exception
{

    public TestException(String message)
    {
        super(message);
    }
}

public class ExceptionHandling
{

    int inputInteger(String prompt) throws IOException
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        String line = null;
        int retVal = -1;

//       boolean validInteger = false;
//       while (!validInteger)
//       {
//        try
//        {
//            System.out.print(prompt + ": ");
//            line = br.readLine();
//            try
//            {
//                retVal = Integer.parseInt(line);
//                validInteger = true;
//            }
//            catch (NumberFormatException nfe)
//            {
//                System.err.println("You entered an invalid number.");
//            }
//        }
//        catch (IOException ex)
//        {
//            System.err.println("Exception: " + ex.getMessage());
//        }
//       }
//       return retVal;
        try
        {
            System.out.print(prompt + ": ");
            line = br.readLine();
            try
            {
                retVal = Integer.parseInt(line);
                return retVal;
            }
            catch (NumberFormatException nfe)
            {
//                System.err.println("You entered an invalid number.");
//                throw nfe;
                throw new NumberFormatException("You entered an invalid number.");
            }
        }
        catch (IOException ioe)
        {
            System.err.println("Exception: " + ioe.getMessage());
            throw ioe;
        }
    }

    void throwException() throws TestException
    {
        throw new TestException("Exception for testing...");
    }

    void exceptionPropagationDemo() throws TestException
    {
        System.out.println("1111");
        try
        {
            {
                System.out.println("2222");
                {
                    System.out.println("3333");
                    System.out.println("4444");
                    throwException();
                    System.out.println("5555");
                }
                System.out.println("6666");
            }
            System.out.println("7777");
        }
        catch (TestException ex)
        {
            System.err.println("Exception: " + ex.getMessage());
        }
        System.out.println("8888");
    }

    void fn4() throws TestException
    {
        System.out.println("dddd");
        throwException();
        System.out.println("eeee");
    }

    void fn3() throws TestException
    {
        System.out.println("cccc");
        fn4();
        System.out.println("ffff");
    }

    void fn2() throws TestException
    {
        System.out.println("bbbb");
        fn3();
        System.out.println("gggg");
    }

    void fn1() throws TestException
    {
        System.out.println("aaaa");
        fn2();
        System.out.println("hhhh");
    }

//    public static void main(String[] args)
//            throws IOException, NullPointerException, TestException
    public static void main(String[] args)
    {
        ExceptionHandling exceptionHandling
                = new ExceptionHandling();
        int principal;
        int rate;
        int numberOfTerms;
        try
        {
            principal = exceptionHandling.inputInteger("Input the Principal amount");
            rate = exceptionHandling.inputInteger("Input the Rate");
            numberOfTerms = exceptionHandling.inputInteger("Input the Number of Terms");
            int amount = principal * rate * numberOfTerms / 100;
            exceptionHandling.exceptionPropagationDemo();
            exceptionHandling.fn1();
            System.out.println("Amount=" + amount);
        }
//        catch (IOException ioe)
//        {
//        }
//        catch (NumberFormatException nfe)
//        {
//        }
//        catch (TestException nfe)
//        {
//        }
//        catch (IOException | NumberFormatException | TestException ex)
//        {
//        }
        catch (Exception ex)
        {
            System.err.println("Exception: ");
            ex.printStackTrace();
        }
        System.out.println("Program terminated.");
    }
}
