/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample5;

import java.io.IOException;

/**
 *
 * @author class
 */
public class ExceptionHandlingExample5
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        int x = 10;
        System.out.println("Starting...");
        try
        {
            System.out.println("Opening the file...");
            System.out.println("File opened successfully...");
            for (int i = 0; i < 10; i++)
            {
                //Write the ith line to file
                System.out.println("Writing line "+(i+1));
                if (x == 5)
                    throw new IOException("Error writing to file");
            }
        } catch (IOException ioe)
    {
        //try
        //{
        // Some code
        //} catch (Exception ex)
        //{
        // ...
        //}
        ioe.printStackTrace();
    }
    finally
        {
            System.out.println("if (the file is open)");
            System.out.println("\tClose the file...");
        }
        System.out.println("Finished.");
    }
}
