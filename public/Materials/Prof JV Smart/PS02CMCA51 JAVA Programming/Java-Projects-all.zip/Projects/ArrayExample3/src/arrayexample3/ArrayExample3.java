/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayexample3;

/**
 *
 * @author system
 */
public class ArrayExample3
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        int[][] a;
        a = new int[5][];
        a[0] = new int[2];
        a[1] = new int[4];
        a[2] = new int[3];
        a[3] = new int[6];
        a[4] = new int[1];
        for (int i = 0; i < a.length; i++)
            System.out.println("a["+i+"].length="+a[i].length);
        System.out.println("-----------------");
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < a[i].length; j++)
                a[i][j] = (i+1)*10+j+1;
        for (int[] row : a)
        {
            for (int ele : row)
                System.out.print("["+ele+"] ");
            System.out.println();
        }
    }
}
