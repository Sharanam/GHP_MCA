/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylistexample3;

import java.util.ArrayList;
import java.util.Collections;

class Person implements Comparable<Person>
{
    private int id;
    private String name;

    Person()
    {
        id = -1;
        name = null;
    }

    Person(int id, String name)
    {
        this.id = id;
        this.name = name;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    @Override
    public boolean equals(Object o2)
    {
        if (o2 == null)
            return false;
        if (this == o2)
            return true;
        if (this.getClass() != o2.getClass())
            return false;
        final Person p2 = (Person)o2;
        if (this.id == p2.id)
            if (this.name == null)
                if (p2.name == null)
                    return true;
                else
                    return false;
            else
                if (p2.name == null)
                    return false;
                else
                    if (this.name.equals(p2.name)) 
                        return true;
                    else
                        return false;
        else
            return false;
    }

    @Override
    public String toString()
    {
        return "Person(" + id + ", " + name + ")";
    }

    @Override
    public int compareTo(Person o)
    {
        if (o == null)
            return 1;
        if (this.equals(o))
            return 0;
        return this.getName().compareTo(o.getName());
    }

}

/**
 *
 * @author jignesh
 */
public class ArrayListExample3
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        ArrayList<Person> persons = new ArrayList<>();
        persons.add(new Person(1, "Sindhu"));
        persons.add(new Person(2, "Saina"));
        persons.add(new Person(3, "Kashyap"));
//        Results in Exception
//        persons.add(null);

        for (Person p : persons)
        {
            System.out.println(p);
        }
        System.out.println("--------------");

        Collections.sort(persons);
        for (Person p : persons)
        {
            System.out.println(p);
        }
        System.out.println("--------------");
        
        Collections.reverse(persons);
        for (Person p : persons)
        {
            System.out.println(p);
        }
        System.out.println("--------------");
    }
    
}
