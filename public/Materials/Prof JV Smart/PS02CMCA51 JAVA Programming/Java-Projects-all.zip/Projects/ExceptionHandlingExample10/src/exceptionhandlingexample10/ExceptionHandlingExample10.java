/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample10;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author jignesh
 */
public class ExceptionHandlingExample10
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception
    {
        String inputFilename = null, line;

        if (args.length != 1)
        {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        }
        else
        {
            inputFilename = args[0];
        }

        File inputFile = new File(inputFilename);
        FileReader fr = null;
        BufferedReader br = null;
        try
        {
            fr = new FileReader(inputFile);
            br = new BufferedReader(fr);
            while (true)
            {
                try
                {
                    line = br.readLine();
                    if (line == null)
                    {
                        break;
                    }
                    System.out.println(line);
//                    throw new IOException("Simulated I/O error");
                }
                catch (IOException ex)
                {
                    System.err.println("IOException: " + ex.
                            getLocalizedMessage());
                    throw ex;
                }
            }
            System.out.println("File copied successfully");
        }
        catch (FileNotFoundException ex)
        {
            System.err.println("FileNotFoundException: " + ex.
                    getLocalizedMessage());
        }
        finally
        {
            System.out.println("In finally block...");
            try
            {
                if (br != null)
                {
                    br.close();
                }
                if (fr != null)
                {
                    fr.close();
                }
            }
            catch (IOException ex)
            {
                System.err.println("IOException: " + ex.getLocalizedMessage());
            }

        }
    }

}
