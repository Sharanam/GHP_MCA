/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package deptemplibrary;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author system
 */
public class Department implements Serializable
{
    static final long serialVersionUID = 42234L;  
    int deptno;
    String name;
    ArrayList<Employee> employees;
    
    public Department(int pdeptno, String pname)
    {
        deptno = pdeptno;
        name = pname;
        employees = new ArrayList<>();
    }
    
    public void addEmployee(Employee pemployee)
    {
        employees.add(pemployee);
    }
    
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("Department\n{\n\tdeptno=").append(
                deptno).append(",\n\tname=").append(name).append(",\n\temployees=\n\t[\n");
        for (Employee emp : employees)
        {
            sb.append("\t\t").append(emp).append("\n");
        }
        sb.append("\t]\n}");
        return sb.toString();
    }
}
