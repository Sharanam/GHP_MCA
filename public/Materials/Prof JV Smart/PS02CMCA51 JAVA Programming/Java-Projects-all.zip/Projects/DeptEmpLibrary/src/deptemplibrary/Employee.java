/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package deptemplibrary;

import java.io.Serializable;

/**
 *
 * @author system
 */
public class Employee implements Serializable
{
    static final long serialVersionUID = 42234L;  
    int empno;
    String name;
    boolean gender;
    double salary;
    
    public Employee(int pempno, String pname, boolean pgender, double psalary)
    {
        empno = pempno;
        name = pname;
        gender = pgender;
        salary = psalary;
    }
    
    public String toString()
    {
        return "Employee{"+empno+", "+name+", "+gender+", "+salary+"}";
    }
}
