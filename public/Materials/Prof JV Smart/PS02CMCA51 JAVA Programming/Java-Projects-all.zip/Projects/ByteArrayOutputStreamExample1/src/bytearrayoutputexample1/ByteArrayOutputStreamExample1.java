/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bytearrayoutputexample1;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author system
 */
public class ByteArrayOutputStreamExample1
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        String str = "abABબાઇટઆઉપુટસ્ટ્રિમનો આઉટપુટ";
        StringReader sr = new StringReader(str);
        byte[] byteArray;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        OutputStreamWriter osw = new OutputStreamWriter(baos);
        while (true)
        {
            int ch = -1;
            try
            {
                ch = sr.read();
            }
            catch (IOException ex)
            {
                ex.printStackTrace();
            }
            if (ch == -1)
                break;
            try
            {
                osw.write(ch);
            }
            catch (IOException ex)
            {
                ex.printStackTrace();
            }
        }
        try
        {
            osw.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
        sr.close();
        byteArray = baos.toByteArray();
        int cnt = 0;
        for (byte byt : byteArray)
        {
            System.out.print("b=" + Integer.toHexString(byt) + " ");
            cnt++;
            if (cnt >= 12)
            {
                System.out.println();
                cnt = 0;
            }
        }
        System.out.println();
    }
}
