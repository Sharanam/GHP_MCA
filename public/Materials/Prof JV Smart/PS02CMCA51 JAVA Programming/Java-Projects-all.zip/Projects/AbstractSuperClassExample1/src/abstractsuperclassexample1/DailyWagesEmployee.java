/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractsuperclassexample1;

/**
 *
 * @author class
 */
public class DailyWagesEmployee extends Employee
{
    private double dailyWages;
    private int noOfDaysOfWork;

    public DailyWagesEmployee(int pempNo,
            String pname, String pdepartment,
            String pdesignation, 
            double pdailyWages,
            int pnoOfDaysOfWork)
    {
        super(pempNo, pname, pdesignation, pdepartment);
        dailyWages = pdailyWages;
        noOfDaysOfWork = pnoOfDaysOfWork;
    }
    
    @Override
    public double getSalary()
    {
        return noOfDaysOfWork * dailyWages;
    }

    @Override
    public double getBonus()
    {
       return 2000;
    }
    
    @Override
 public String toString()
 {
     return "DailyWagesEmployee{"+getEmpNo()+","+
             getName()+"}";
 }
    
}
