/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractsuperclassexample1;

/**
 *
 * @author class
 */
public class ContractedEmployee extends Employee
{
    private double fixedMonthlySalary;
    private int contractDuration;

    public ContractedEmployee(int pempNo,
            String pname, String pdepartment,
            String pdesignation, 
            double pfixedMonthlySalary,
            int pcontractDuration)
    {
        super(pempNo, pname, pdesignation, pdepartment);
        fixedMonthlySalary = pfixedMonthlySalary;
        contractDuration = pcontractDuration;
    }
    
    @Override
    public double getSalary()
    {
        return fixedMonthlySalary;
    }

    @Override
    public double getBonus()
    {
        if (contractDuration >= 6)
            return getSalary();
        else
            return 0;
    }
    
    @Override
 public String toString()
 {
     return "ContractedEmployee{"+getEmpNo()+","+
             getName()+"}";
 }
    
}
