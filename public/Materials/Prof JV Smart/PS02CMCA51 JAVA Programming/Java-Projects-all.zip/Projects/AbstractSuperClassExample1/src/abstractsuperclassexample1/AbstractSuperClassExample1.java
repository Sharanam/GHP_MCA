/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractsuperclassexample1;

/**
 *
 * @author class
 */
public class AbstractSuperClassExample1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PermanentEmployee p1 =
                new PermanentEmployee(101, "aaa", "Sales", "Sales Officer", 15000, 50);
        System.out.println("p1:"+p1);
        System.out.println("p1's salary="+p1.getSalary());
        System.out.println("p1's bonus="+p1.getBonus());
        ContractedEmployee c1 =
                new ContractedEmployee(101, "aaa", "Sales", "Sales Officer", 15000, 6);
        System.out.println("c1:"+c1);
        System.out.println("c1's salary="+c1.getSalary());
        System.out.println("c1's bonus="+c1.getBonus());
        DailyWagesEmployee d1 =
                new DailyWagesEmployee(101, "aaa", "Sales", "Sales Officer", 150, 20);
        System.out.println("d1:"+d1);
        System.out.println("d1's salary="+d1.getSalary());
        System.out.println("d1's bonus="+d1.getBonus());
        Employee e1;
        e1 = d1;
        System.out.println("e1:"+e1);
        System.out.println("e1's salary="+e1.getSalary());
        System.out.println("e1's bonus="+e1.getBonus());
    }
}
