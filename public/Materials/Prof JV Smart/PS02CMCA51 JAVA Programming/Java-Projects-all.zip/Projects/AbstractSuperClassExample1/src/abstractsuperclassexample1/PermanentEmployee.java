/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractsuperclassexample1;

/**
 *
 * @author class
 */
public class PermanentEmployee extends Employee
{
    private double basicPay;
    private float dearnessAllowancePercentage;

    public PermanentEmployee(int pempNo,
            String pname, String pdepartment,
            String pdesignation, double pbasicPay,
            float pdearnessAllowancePercentage)
    {
        super(pempNo, pname, pdesignation, pdepartment);
        basicPay = pbasicPay;
        dearnessAllowancePercentage = pdearnessAllowancePercentage;
    }
    
    @Override
    public double getSalary()
    {
        return basicPay +
                basicPay * dearnessAllowancePercentage / 100;
    }

    @Override
    public double getBonus()
    {
        return basicPay +
                basicPay * dearnessAllowancePercentage / 100;
    }
    
    @Override
 public String toString()
 {
     return "PermanentEmployee{"+getEmpNo()+","+
             getName()+"}";
 }
    
}
