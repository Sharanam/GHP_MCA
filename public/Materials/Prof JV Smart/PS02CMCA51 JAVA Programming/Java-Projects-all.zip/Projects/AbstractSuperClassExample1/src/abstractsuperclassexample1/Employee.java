/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractsuperclassexample1;

/**
 *
 * @author class
 */
 abstract public class Employee {
 private int empNo;
 private String name;
 private String designation;
 private String department;

    public Employee(int empNo, String name, String designation, String department) {
        this.empNo = empNo;
        this.name = name;
        this.designation = designation;
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public String getDesignation() {
        return designation;
    }

    public int getEmpNo() {
        return empNo;
    }

    public String getName() {
        return name;
    }

    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    public void setName(String name) {
        this.name = name;
    }

 
 abstract public double getSalary();
 abstract public double getBonus();

 public void transfer(String newDepartment)
 {
     department = newDepartment;
 }

 public void changeDesignation(String newDesignation)
 {
     designation = newDesignation;
 }
 
    @Override
 public String toString()
 {
     return "Employee{"+empNo+","+
             name+"}";
 }
}
