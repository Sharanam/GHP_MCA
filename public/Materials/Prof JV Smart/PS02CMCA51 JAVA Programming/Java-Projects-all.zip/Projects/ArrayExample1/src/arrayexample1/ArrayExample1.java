/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayexample1;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author system
 */
public class ArrayExample1
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
//        C Style: int a[5];
//        int a[] = new int[3];
//        int[] a = new int[3];
        int a[] =
        {
            1, 2, 3, 4, 5
        };
        System.out.println("a.length=" + a.length);
        for (int i = 0; i < a.length; i++)
        {
            System.out.println("a[" + i + "]=" + a[i]);
        }
        System.out.println("-------------------");
//        Enhanced for loop / foreach loop
        for (int ele : a)
        {
            System.out.println("ele=" + ele);
        }
        System.out.println("-------------------");
//        System.out.println("a[6]="+a[6]);

        int b[] = new int[3];
        b[0] = 6;
        b[1] = 7;
        b[2] = 8;
        System.out.println("b:");
        for (int ele : b)
        {
            System.out.println("ele=" + ele);
        }
        System.out.println("-------------------");
        int c[] = b;
        System.out.println("c:");
        for (int ele : c)
        {
            System.out.println("ele=" + ele);
        }
        System.out.println("-------------------");
        b[1] = 12345;
        System.out.println("b:");
        for (int ele : b)
        {
            System.out.println("ele=" + ele);
        }
        System.out.println("-------------------");
        System.out.println("c:");
        for (int ele : c)
        {
            System.out.println("ele=" + ele);
        }
        System.out.println("-------------------");
        b[1] = 7;

        c = new int[3];
        for (int i = 0; i < b.length; i++)
        {
            c[i] = b[i];
        }
//        System.arraycopy(b, 0, c, 0, 3);
        b[1] = 12345;
        System.out.println("b:");
        for (int ele : b)
        {
            System.out.println("ele=" + ele);
        }
        System.out.println("-------------------");
        System.out.println("c:");
        for (int ele : c)
        {
            System.out.println("ele=" + ele);
        }
        System.out.println("-------------------");

        c[0] = 30;
        c[1] = 20;
        c[2] = 10;
        Arrays.sort(c);
//        Arrays.sort(b, new IntComparator());
        for (int ele : c)
        {
            System.out.println("ele=" + ele);
        }
        System.out.println("-------------------");

        Integer[] d =
        {
            8, 7, 6, 7
        };
        Arrays.sort(d, new IntComparator());
        for (int ele : d)
        {
            System.out.println("ele=" + ele);
        }
        System.out.println("-------------------");
    }

}

class IntComparator implements Comparator<Integer>
{

    @Override
    public int compare(Integer o1, Integer o2)
    {
        if (o1 < o2)
        {
            return -1;
        }
        else if (o1 == o2)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }

}
