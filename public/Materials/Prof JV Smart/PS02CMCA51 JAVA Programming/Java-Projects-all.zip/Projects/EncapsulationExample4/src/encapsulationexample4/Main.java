/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encapsulationexample4;


class Item
{
    
    private int id;
    private String name;
    private float rate;
    private float gST;
    
    public Item()
    {
        id = -1;
        name = null;
        rate = -1;
        gST = -1;
    }

    public Item(int id, String name, float rate)
    {
        this.id = id;
        this.name = name;
        this.rate = rate / 1.18f;
        this.gST = 0.18f;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate / 1.18f;
    }

    public float getgST() {
        return gST;
    }

    public void setgST(float gST) {
        this.gST = gST;
    }
    
}

class ListItem
{
    private Item item;
    private float quantity;
    
    public ListItem()
    {
        item = null;
        quantity = -1;
    }

    public ListItem(Item item, float quantity)
    {
        this.item = item;
        this.quantity = quantity;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(float quantity) {
        this.quantity = quantity;
    }
    
    public static String getHeaderLine()
    {
        String line;
        StringBuilder sb = new StringBuilder();
        sb.append("                      *** INVOICE ***\n");
        sb.append("|---------------------------------------------------------|\n");
        sb.append("|    ITEM    |   QTY  |  RATE  | AMOUNT |   GST  |  TOTAL |\n");
        sb.append("|---------------------------------------------------------|");
        return sb.toString();
    }
    
    public String getPrintLine()
    {
        String line;
        line = String.format("| %-10s | %6.2f | %6.2f | %6.2f | %6.2f | %6.2f |",
                item.getName(),
                getQuantity(),
                item.getRate(),
                item.getRate() * getQuantity(),
                item.getRate() * getQuantity() *
                        item.getgST(),
                item.getRate() * getQuantity() +
                item.getRate() * getQuantity() *
                        item.getgST());
        return line;
    }
    
    public static String getFooterLine()
    {
        String line;
        line = "|---------------------------------------------------------|";
        return line;
    }

}

/**
 *
 * @author jignesh
 */
public class Main
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Item item1 = new Item(1, "Toothpaste", (float)70.0);
        Item item2 = new Item(1, "Toothbrush", 40.0f);
        Item item3 = new Item(1, "Toothpick", 50);
        item3.setRate(30);
        
        ListItem listItem1  = new ListItem(item1, 2);
        ListItem listItem2  = new ListItem(item2, 3);
        ListItem listItem3  = new ListItem(item3, 1);

        String line;
        line = ListItem.getHeaderLine();
        System.out.println(line);
        line = listItem1.getPrintLine();
        System.out.println(line);
        line = listItem2.getPrintLine();
        System.out.println(line);
        line = listItem3.getPrintLine();
        System.out.println(line);
        line = ListItem.getFooterLine();
        System.out.println(line);
    }
    
}
