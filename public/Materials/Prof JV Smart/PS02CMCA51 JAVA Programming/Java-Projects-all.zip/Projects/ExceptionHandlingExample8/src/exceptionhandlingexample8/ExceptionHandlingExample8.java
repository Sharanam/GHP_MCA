/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jignesh
 */
public class ExceptionHandlingExample8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        String inputFilename = null, line;

        if (args.length != 1) {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        } else {
            inputFilename = args[0];
        }

        File inputFile = new File(inputFilename);
        FileReader fr;
        try {
            fr = new FileReader(inputFile);
        } catch (FileNotFoundException ex) {
            System.err.println("FileNotFoundException: " + ex.getLocalizedMessage());
            throw ex;
        }
        BufferedReader br = new BufferedReader(fr);
        while (true) {
            try {
                line = br.readLine();
            } catch (IOException ex) {
                System.err.println("IOException: " + ex.getLocalizedMessage());
                throw ex;
            }
            if (line == null) {
                break;
            }
            System.out.println(line);
        }
        try {
            br.close();
            fr.close();
        } catch (IOException ex) {
            System.err.println("IOException: " + ex.getLocalizedMessage());
            throw ex;
        }
    }
}

