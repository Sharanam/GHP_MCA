/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genericscustomgenericclass1;

class MyArrayList<T>
{
    final int MAXSIZE = 100;
    T[] elements = (T[])new Object[MAXSIZE];
    int size = 0;
    void append(T ele) throws ArrayIndexOutOfBoundsException
    {
        size++;
        if (size > MAXSIZE)
        {
            size--;
            throw new ArrayIndexOutOfBoundsException("Size of MyArrayList exceeded");
        }
        else
            elements[size-1] = ele;
    }

    @Override
    public String toString()
    {
        boolean flag = false;
        String str = "{";
//       for (T ele : elements) // ERROR! The for each loop for an array iterates over
                                // the entire declared size of the array (i.e. 100)!
                                // For a collection, it uses an iterator
                                // so this problem does not arise
        for (int i = 0; i < size; i++)
        {
            if (flag)
                str += ", ";
            else
                flag = true;
            str += elements[i].toString();
        }
        str += "}";
        return str;
    }
}

class Person
{
    int pid;
    String name;
    Person(int ppid, String pname)
    {
        pid = ppid;
        name = pname;
    }

    @Override
    public String toString()
    {
        String str = "Person("+pid+", "+name+")";
        return str;
    }
}

/**
 *
 * @author jignesh
 */
public class GenericsCustomGenericClass1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         MyArrayList<Integer> mali = new MyArrayList<Integer>();
        mali.append(1);
        mali.append(2);
        mali.append(3);
//      mali.append("aaa"); //COMPILATION ERROR!
        System.out.println("mali=" + mali.toString());
        MyArrayList<Person> malp = new MyArrayList<Person>();
        malp.append(new Person(1,"aaa"));
        malp.append(new Person(2,"bbb"));
        malp.append(new Person(3,"ccc"));
        malp.append(new Person(4,"ddd"));
        System.out.println("malp=" + malp.toString());
    }
    
}
