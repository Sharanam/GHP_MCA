/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bytearrayinputstreamexample1;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;

/**
 *
 * @author system
 */
public class ByteArrayInputStreamExample1
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        byte[] byteArray = {
            (byte)0x61,(byte)0x62,(byte)0x41,(byte)0x42,(byte)0xe0,(byte)0xaa,(byte)0xac,
            (byte)0xe0,(byte)0xaa,(byte)0xbe,(byte)0xe0,(byte)0xaa,(byte)0x87,(byte)0xe0,
            (byte)0xaa,(byte)0x9f,(byte)0xe0,(byte)0xaa,(byte)0x87,(byte)0xe0,(byte)0xaa,
            (byte)0xa8,(byte)0xe0,(byte)0xaa,(byte)0xaa,(byte)0xe0,(byte)0xab,(byte)0x81,
            (byte)0xe0,(byte)0xaa,(byte)0x9f,(byte)0xe0,(byte)0xaa,(byte)0xb8,(byte)0xe0,
            (byte)0xab,(byte)0x8d,(byte)0xe0,(byte)0xaa,(byte)0x9f,(byte)0xe0,(byte)0xab,
            (byte)0x8d,(byte)0xe0,(byte)0xaa,(byte)0xb0,(byte)0xe0,(byte)0xaa,(byte)0xbf,
            (byte)0xe0,(byte)0xaa,(byte)0xae,(byte)0xe0,(byte)0xaa,(byte)0xa8,(byte)0xe0,
            (byte)0xab,(byte)0x8b,(byte)0x20,(byte)0xe0,(byte)0xaa,(byte)0x86,(byte)0xe0,
            (byte)0xaa,(byte)0x89,(byte)0xe0,(byte)0xaa,(byte)0x9f,(byte)0xe0,(byte)0xaa,
            (byte)0xaa,(byte)0xe0,(byte)0xab,(byte)0x81,(byte)0xe0,(byte)0xaa,(byte)0x9f,
            (byte)0x0a
        };
        ByteArrayInputStream bais = new ByteArrayInputStream(byteArray);
        InputStreamReader isr = new InputStreamReader(bais);
        StringWriter sw = new StringWriter();
        while (true)
        {
            int ch=-1;
            try
            {
                ch = isr.read();
            } catch (IOException ex)
            {
                ex.printStackTrace();
            }
            if (ch == -1)
                break;
            sw.write(ch);
        }
        System.out.println("output="+sw.toString());
        System.out.println("Direct output=abABબાઇટઇનપુટસ્ટ્રિમનો આઉટપુટ");
    }
}
