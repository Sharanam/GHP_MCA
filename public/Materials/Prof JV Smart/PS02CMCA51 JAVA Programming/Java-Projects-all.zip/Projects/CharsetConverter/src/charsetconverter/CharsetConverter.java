/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package charsetconverter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.SortedMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author system
 */
public class CharsetConverter
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        String sourceCharset = null;
        String targetCharset = null;
        String inputFileName = null;
        String outputFileName = null;
        if (args.length != 1 && args.length != 3 && args.length != 4)
        {
            displayUsage();
            System.exit(1);
        }
        if (args.length == 1)
            if (args[0].equalsIgnoreCase("--list"))
            {
                SortedMap<String, Charset> charsetMap = Charset.availableCharsets();
                for (Map.Entry<String, Charset> entry : charsetMap.entrySet())
                System.out.println(entry.getKey() + ":" + entry.getValue());
                System.exit(0);
            }
        else
            {
                displayUsage();
                System.exit(1);
            }
        if (args.length == 3)
        {
            inputFileName = args[0];
            outputFileName = args[1];
            targetCharset = args[2];
        }
        else if (args.length == 4)
        {
            inputFileName = args[0];
            sourceCharset = args[1];
            outputFileName = args[2];
            targetCharset = args[3];
        }
        if (sourceCharset != null)
            if (!Charset.isSupported(sourceCharset))
            {
                System.err.println("The source_charset " + sourceCharset + " is not supported by the JRE");
                System.exit(2);
            }
        if (!Charset.isSupported(targetCharset))
        {
            System.err.println("The target_charset " + targetCharset + " is not supported by the JRE");
            System.exit(3);
        }
        System.out.println("JRE default charset=" + Charset.defaultCharset());
        FileReader fr  = null;
        FileOutputStream fos = null;
        BufferedWriter bw = null;
        InputStreamReader isr = null;
        try
        {
            File inputFile = new File(inputFileName);
            FileInputStream fis = new FileInputStream(inputFile);
            if (sourceCharset == null)
            {
                isr = new InputStreamReader(fis);
                System.out.println("Input encoding detected by Java is:" +
                        isr.getEncoding());
            }
            else
            {
                isr = new InputStreamReader(fis, sourceCharset);
            }
            File outputFile = new File(outputFileName);
            fos = new FileOutputStream(outputFile);
            bw = new BufferedWriter(new OutputStreamWriter(fos, targetCharset));
            while (true)
            {
                int ch = isr.read();
                if (ch == -1)
                    break;
                bw.write(ch);
            }
        } catch (FileNotFoundException ex)
        {
            Logger.getLogger(CharsetConverter.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (IOException ex)
        {
            Logger.getLogger(CharsetConverter.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
            try
            {
                if (bw != null)
                    bw.close();
                if (fos != null)
                    fos.close();
                if (fr != null)
                    fr.close();
                if (isr != null)
                    isr.close();
            } catch (IOException ex)
            {
                Logger.getLogger(CharsetConverter.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    private static void displayUsage()
    {
            System.err.println("Usage java -jar CharsetConverter.jar input_file output_file target_charset");
            System.err.println("OR");
            System.err.println("java -jar CharsetConverter.jar input_file source_charset output_file target_charset");
            System.err.println("OR");
            System.err.println("java -jar CharsetConverter.jar --list");
    }
}
