/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandling8;

import java.util.Scanner;

class InvalidOptionSelectedException extends Exception
{
    
}

/**
 *
 * @author jignesh
 */
public class ExceptionHandling8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
            throws InvalidOptionSelectedException
    {
        System.out.println("1) balance");
        System.out.println("2) scheme");
        System.out.println("3) quit");
        System.out.print("Select an option: ");
        Scanner scanner = new Scanner(System.in);
        String line = scanner.nextLine();
        try
        {
            int option = Integer.parseInt(line);
            switch (option)
            {
                case 1:
                    System.out.println("Rs. 35");
                    break;
                case 2:
                    System.out.println("Rs. 120: Full talktime");
                    break;
                case 3:
                    System.out.println("Have a nice day.");
                    break;
                default:
                    throw new InvalidOptionSelectedException();
//                    throw new InvalidOptionSelectedException(
//                                "You have selected an invalid option");
            }
        } catch (NumberFormatException e)
        {
            System.out.println("You did not enter an integer.");
        }
    }
    
}
