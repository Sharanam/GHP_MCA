/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package areaofcircle;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Administrator
 */
public class Main {

    /**
     * @param args the command line arguments
     */
public static void main(String[] args) {
     double radius;
     BufferedReader br = 
        new BufferedReader(
             new InputStreamReader(System.in));
     String line=null;
     System.out.print("Enter the radius: ");
        try
        {
            line = br.readLine();
        }
        catch (IOException ex)
        {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
     radius = Double.parseDouble(line);
     double area = java.lang.Math.PI * radius * radius;
     System.out.println("area=" + area);
//     System.out.println("area=" + ((Double)area).toString());
     
    }

}
