/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package guilongrunningoperationexample2;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author system
 */
public class GUILongRunningOperationExample2
{
    
    private static JFrame frame;

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI()
    {
        //Create and set up the window.
        frame = new JFrame("GUILongRunningOperationExample2");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        JPanel contentPane = new JPanel();
        frame.setContentPane(contentPane);
        
        JLabel sleepPeriodLabel = new JLabel("Sleep Period (seconds)");
        frame.add(sleepPeriodLabel);
        final JTextField sleepPeriodTextField = new JTextField(6);
        frame.add(sleepPeriodTextField);
        JButton sleepButton = new JButton("Sleep");
        frame.add(sleepButton);
        JTextArea textArea = new JTextArea(5, 40);
        frame.add(textArea);
        final JLabel threadStatusLabel = new JLabel("Thread active...");
        threadStatusLabel.setForeground(Color.red);
        frame.add(threadStatusLabel);
        sleepButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e)
            {
                String sleepPeriodString = sleepPeriodTextField.getText();
                int sleepPeriod = Integer.parseInt(sleepPeriodString);
                threadStatusLabel.setText("Long Running Operation Started...");
                longRunningOperation(sleepPeriod, threadStatusLabel,
                                            "Long Running Operation Started...",
                                            "Long Running Operation Finished");
            }
        });

        //Display the window.
        frame.setSize(500, 250);
//        frame.pack();
        frame.setVisible(true);
        sleepPeriodTextField.requestFocusInWindow();
    }
    
    public static void longRunningOperation(final int sleepPeriod,
                                            final JLabel label, final String runningText,
                                                final String finishedText)
    {
        Thread[] thrdary = new Thread[Thread.activeCount()];
        Thread.enumerate(thrdary);
        for (Thread thrd : thrdary)
        {
            System.out.print(thrd.getName()+" ");
        }
        System.out.println();
        new Thread(new Runnable() {

            @Override
            public void run()
            {
                for (int i = 0; i < sleepPeriod; i++)
                {
                    try
                    {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex)
                    {
                        System.err.println("Thread interrupted in sleep");
                    }
                    System.out.print((i+1) + " ");
                    label.setText(runningText+(i+1));
                }
                System.out.println();
                label.setText(finishedText);
            }
        }, "LongRunningOperationThread").start();
        thrdary = new Thread[Thread.activeCount()];
        Thread.enumerate(thrdary);
        for (Thread thrd : thrdary)
        {
            System.out.print(thrd.getName()+" ");
        }
        System.out.println();
        System.out.println("longRunningOperation() returned...");
    }

    public static void main(String[] args)
    {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                createAndShowGUI();
            }
        });
    }
}
