/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandling10;

import java.util.Scanner;

class ValidationException extends Exception
{
    public ValidationException(String message)
    {
        super(message);
    }
    
    public ValidationException()
    {
        super();
//        super("You selected an invalid option");
    }
}

class InvalidOptionSelectedException extends ValidationException
{
    public InvalidOptionSelectedException(String message)
    {
        super(message);
    }
    
    public InvalidOptionSelectedException()
    {
        super();
//        super("You selected an invalid option");
    }
}

class InvalidIntegerException extends ValidationException
{
    public InvalidIntegerException(String message)
    {
        super(message);
    }
    
    public InvalidIntegerException()
    {
        super();
//        super("You selected an invalid option");
    }
}

/**
 *
 * @author jignesh
 */
public class ExceptionHandling10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
//            throws InvalidOptionSelectedException, InvalidIntegerException
            throws ValidationException
    {
//        try
//        {
            System.out.println("1) balance");
            System.out.println("2) scheme");
            System.out.println("3) quit");
            System.out.print("Select an option: ");
            Scanner scanner = new Scanner(System.in);
            String line = scanner.nextLine();
            try
            {
                int option = Integer.parseInt(line);
                switch (option)
                {
                    case 1:
                        System.out.println("Rs. 35");
                        break;
                    case 2:
                        System.out.println("Rs. 120: Full talktime");
                        break;
                    case 3:
                        System.out.println("Have a nice day.");
                        break;
                    default:
    //                    throw new InvalidOptionSelectedException();
                        throw new InvalidOptionSelectedException(
                                    "You have selected an invalid option");
                }
            } catch (NumberFormatException e)
            {
                throw new InvalidIntegerException(
                        "You did not enter an integer.");
            }
//        }
//        catch(ValidationException e)
//        {
//            System.out.println(e.getLocalizedMessage());
//        }
//        catch(InvalidIntegerException e)
//        {
//            System.out.println(e.getLocalizedMessage());
//        }
//        catch(InvalidOptionSelectedException e)
//        {
//            System.out.println(e.getLocalizedMessage());
//        }
    }
    
}
