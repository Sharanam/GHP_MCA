/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package creatingthreadsusingrunnable;

/**
 *
 * @author system
 */
public class CreatingThreadsUsingRunnable implements Runnable
{

    char characterToBeDisplayed;
    int sleepPeriod;
    
    public CreatingThreadsUsingRunnable(char ch, int period)
    {
        characterToBeDisplayed = ch;
        sleepPeriod = period;
    }
    @Override
    public void run()
    {
        for (int i = 0; i < 10; i++)
        {
            System.out.print(characterToBeDisplayed);
            try
            {
                Thread.sleep(sleepPeriod);
            } catch (InterruptedException ex)
            {
                System.err.println("Thread Interrupted...");
            }
        }
        System.out.println("\n"+Thread.currentThread().getName()+" terminated...");
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Thread thread1 = new Thread(new CreatingThreadsUsingRunnable('@', 1000),
                "thread1");
        Thread thread2 = new Thread(new CreatingThreadsUsingRunnable('%', 2000),
                "thread2");
        thread1.start();
        thread2.start();
        System.out.println("main() returns...");
    }
}
