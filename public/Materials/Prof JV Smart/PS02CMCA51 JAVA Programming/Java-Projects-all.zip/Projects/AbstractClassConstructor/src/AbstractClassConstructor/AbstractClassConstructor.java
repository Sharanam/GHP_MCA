/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package AbstractClassConstructor;

/**
 *
 * @author class
 */
public class AbstractClassConstructor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Employee e1 = new Employee("103", "ccc", 333);
        System.out.println("e1="+e1);
        Employee e2 = new Employee("104", "ddd", 444);
        System.out.println("e2="+e2);
        System.out.println("Person.pcount="+Person.pcount+", Employee.pcount="+
                Employee.pcount);
    }
}
