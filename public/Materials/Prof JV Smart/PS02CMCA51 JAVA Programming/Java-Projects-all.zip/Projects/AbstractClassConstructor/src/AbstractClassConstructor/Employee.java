/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package AbstractClassConstructor;

/**
 *
 * @author system
 */
public class Employee extends Person
{
    public int empid;

    public Employee()
    {
        super();
        empid = -1;
    }
    public Employee(String ppid, String pname, int pempid)
    {
        super(ppid, pname);
        empid = pempid;
    }
    @Override
    public String toString()
    {
        return "Employee{(pcount="+pcount+" "+pid+", "+name+"}";
    }

}
