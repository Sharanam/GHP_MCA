/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package AbstractClassConstructor;

/**
 *
 * @author class
 */
public abstract class Person
{
   public String pid;
   public String name;
   public static int pcount=0;
   public Person()
   {
       pid = null;
       name = null;
       pcount++;
   }
   public Person(String ppid, String pname)
   {
       pid = ppid;
       name = pname;
       pcount++;
   }
    @Override
   public String toString()
   {
       return "Person{(pcount="+pcount+" "+pid+", "+name+"}";
   }
}
