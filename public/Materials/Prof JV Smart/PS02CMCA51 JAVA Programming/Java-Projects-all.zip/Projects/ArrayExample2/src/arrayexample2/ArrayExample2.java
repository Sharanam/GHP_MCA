/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayexample2;

/**
 *
 * @author system
 */
public class ArrayExample2
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        int a[][] =
        {
            {11, 12, 13},
            {21, 22, 23},
            {31, 32, 33},
            {41, 42, 43}
        };
        System.out.println("a.length="+a.length);
        System.out.println("a[0].length="+a[0].length);
        System.out.println("a[1].length="+a[1].length);
        System.out.println("a[2].length="+a[2].length);
        System.out.println("a[3].length="+a[3].length);
        for (int i = 0; i < a.length; i++)
        {
            for (int j = 0; j < a[i].length; j++)
                System.out.print("["+a[i][j]+"] ");
            System.out.println();
        }
        System.out.println("-----------------");
        for (int[] row : a)
        {
            for (int val : row)
                System.out.print("["+val+"] ");
            System.out.println();
        }
        System.out.println("-----------------");
        
        int b[][] = new int[4][3];
//        b[1][3] = 5;
        for (int i = 0; i < 4; i++)
            for (int j = 0; j < 3; j++)
                b[i][j] = (i+1)*10+j+1;
        for (int[] row : b)
        {
            for (int val : row)
                System.out.print("["+val+"] ");
            System.out.println();
        }
        System.out.println("-----------------");

//        Jagged array
        int c[][] =
        {
            {11, 12, 13},
            {21, 22},
            {31, 32, 33, 34},
            {}
        };
        System.out.println("c.length="+c.length);
        System.out.println("c[0].length="+c[0].length);
        System.out.println("c[1].length="+c[1].length);
        System.out.println("c[2].length="+c[2].length);
        System.out.println("c[3].length="+c[3].length);
        for (int i = 0; i < c.length; i++)
        {
            for (int j = 0; j < c[i].length; j++)
                System.out.print("["+c[i][j]+"] ");
            System.out.println();
        }
        System.out.println("-----------------");

        for (int[] row : c)
        {
            for (int val : row)
                System.out.print("["+val+"] ");
            System.out.println();
        }
        System.out.println("-----------------");

        int[][] d;
        d = new int[4][];
        d[0] = new int[3];
        d[1] = new int[2];
        d[2] = new int[4];
//        Zero length array
//        It is necessary to initialize d[3] to access d[3].length
        d[3] = new int[0];
        System.out.println("d[3].length=" + d[3].length);

        d[0][0] = 11;
        d[0][1] = 12;
        d[0][2] = 13;
        d[1][0] = 21;
        d[1][1] = 22;
        d[2][0] = 31;
        d[2][1] = 32;
        d[2][2] = 33;
        d[2][3] = 34;
//        d[3] has no elements in it
//        d[3][0] = 41;
        
        System.out.println("d.length="+c.length);
        System.out.println("d[0].length="+d[0].length);
        System.out.println("d[1].length="+d[1].length);
        System.out.println("d[2].length="+d[2].length);
        System.out.println("d[3].length="+d[3].length);
        for (int i = 0; i < d.length; i++)
        {
            for (int j = 0; j < d[i].length; j++)
                System.out.print("["+d[i][j]+"] ");
            System.out.println();
        }
        System.out.println("-----------------");
    }
}
