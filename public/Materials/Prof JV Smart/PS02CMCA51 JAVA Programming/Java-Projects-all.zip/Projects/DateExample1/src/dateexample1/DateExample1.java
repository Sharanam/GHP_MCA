/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dateexample1;

import java.text.DateFormatSymbols;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jignesh
 */
public class DateExample1
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
//        java -Duser.country=IN -Duser.language=hi -jar dist/DateExample1.jar
//        LC_ALL=hi_IN java -jar dist/DateExample1.jar
        
//        Locale.setDefault(new Locale("en", "US"));
//        Locale.setDefault(new Locale("en", "GB"));
//        Locale.setDefault(new Locale("fr", "FR"));
//        Locale.setDefault(new Locale("de", "DE"));
//        Locale.setDefault(new Locale("ja", "JP"));
//        Locale.setDefault(new Locale("hi", "IN"));
        
        Date currentDate = new Date();
        System.out.println("currentDate=" + currentDate);
//        Year is full year-1999
//        Month number begins with 0
        Date independeceDate = new Date(47, 7, 15, 0, 0, 0);
        System.out.println("independenceDate=" + independeceDate);
        Date date3 = new Date();
//        Year: 1995
        date3.setYear(95);
//        Month: may
        date3.setMonth(4);
        date3.setDate(10);
//        Hour: 3pm
        date3.setHours(15);
        date3.setMinutes(23);
        date3.setSeconds(45);
        System.out.println("date3=" + date3);
        int year = date3.getYear();
        int month = date3.getMonth();
        int date = date3.getDate();
        int hours = date3.getHours();
        int minutes = date3.getMinutes();
        int seconds = date3.getSeconds();
//        0 = Sunday, 1 = Monday, ...
        int dayOfWeek = date3.getDay();
        System.out.println("date:" + date + " month:" + month + " year:" + year +
                " hours:" + hours + " minutes:" + minutes + " seconds:" + seconds +
                " day of the week:" + dayOfWeek);
        
        
        
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.set(1995, 5, 10, 15, 23, 45);
        java.text.DateFormatSymbols dateFormatSymbols =
                new java.text.DateFormatSymbols();
        System.out.println("YEAR: " + gregorianCalendar.get(Calendar.YEAR));
        System.out.println("MONTH: " + gregorianCalendar.get(Calendar.MONTH));
        String[] monthNames = dateFormatSymbols.getMonths();
//        for (int i = 0; i < 13; i++)
//            System.out.println("i=" + i + monthNames[i]);
        System.out.println("MONTH in words: " +
                monthNames[gregorianCalendar.get(Calendar.MONTH)-1]);
        System.out.println("DATE: " + gregorianCalendar.get(Calendar.DATE));
        System.out.println("DAY_OF_WEEK: " + 
                gregorianCalendar.get(Calendar.DAY_OF_WEEK));
        String[] weekDayNames = dateFormatSymbols.getWeekdays();
//        for (int i = 0; i < 8; i++)
//            System.out.println("i=" + i + weekDayNames[i]);
        System.out.println("DAY_OF_WEEK in words: " +
                weekDayNames[gregorianCalendar.get(Calendar.DAY_OF_WEEK)]);
        System.out.println("HOUR_OF_DAY: " +
                gregorianCalendar.get(Calendar.HOUR_OF_DAY));
        System.out.println("HOUR: " +
                gregorianCalendar.get(Calendar.HOUR));
        System.out.println("AM_PM: " +
                gregorianCalendar.get(Calendar.AM_PM));
        String[] amPmStrings = dateFormatSymbols.getAmPmStrings();
        System.out.println("AM_PM in words: " +
                amPmStrings[gregorianCalendar.get(Calendar.AM_PM)]);
        System.out.println("MINUTE: " + gregorianCalendar.get(Calendar.MINUTE));
        System.out.println("SECOND: " + gregorianCalendar.get(Calendar.SECOND));
        System.out.println("MILLISECOND: " + gregorianCalendar.get(Calendar.MILLISECOND));




        
        java.text.SimpleDateFormat simpleDateFormatLocaleDefault =
                new java.text.SimpleDateFormat();
        java.text.SimpleDateFormat simpleDateFormat24Hours =
                new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        java.text.SimpleDateFormat simpleDateFormat12Hours =
                new java.text.SimpleDateFormat("dd-MM-yyyy hh:mm:ss a");
        java.text.SimpleDateFormat simpleDateFormatLong1 =
                new java.text.SimpleDateFormat("EEEE dd MMMM, yyyy hh:mm:ss a");
        java.text.SimpleDateFormat simpleDateFormatLong2 =
                new java.text.SimpleDateFormat("EEE dd MMM, yyyy hh:mm:ss a");
        
//        String date4String = "--10/8/1995 15:23:45";
//        String date4String = "20/8/1995 10:23:45";
        String date4String = "20/8/1995 15:23:45";
        try
        {
            Date date4 = simpleDateFormat24Hours.parse(date4String);
            System.out.println("Formatted date locale default=" + simpleDateFormatLocaleDefault.format(date4));
            System.out.println("Formatted date 24 hours=" + simpleDateFormat24Hours.format(date4));
            System.out.println("Formatted date 12 hours=" + simpleDateFormat12Hours.format(date4));
            System.out.println("Formatted date long1=" + simpleDateFormatLong1.format(date4));
            System.out.println("Formatted date long2=" + simpleDateFormatLong2.format(date4));
        }
        catch (ParseException ex)
        {
            System.err.println("Error parsing date " + date4String);
            System.err.println(ex.getMessage());
        }




        currentDate = new Date();
        long currentDateMilli = currentDate.getTime();
        long independecDateMilli = independeceDate.getTime();
        long timeDifferenceMilli = currentDateMilli - independecDateMilli;
        System.out.println("Number of milliseconds we have been independent:" + timeDifferenceMilli);
        java.text.DecimalFormat decimalFormat = new java.text.DecimalFormat("###,###,###,###,###,###");
        System.out.println("Number of milliseconds we have been independent:" +
                decimalFormat.format(timeDifferenceMilli));
        
        double doubleValue = 123456789.1234;
        NumberFormat numberFormat = NumberFormat.getInstance();
        System.out.println("Formatted long=" + numberFormat.format(currentDateMilli));
        System.out.println("Formatted double=" + numberFormat.format(doubleValue));
    }
    
}
