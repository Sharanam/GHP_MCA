/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encapsulationexample1;

class Item
{
    
    public int id;
    public String name;
    public float rate;
    
    public Item()
    {
        id = -1;
        name = null;
        rate = -1;
    }

    public Item(int id, String name, float rate)
    {
        this.id = id;
        this.name = name;
        this.rate = rate;
    }
    
}

class ListItem
{
    public Item item;
    public float quantity;
    
    public ListItem()
    {
        item = null;
        quantity = -1;
    }

    public ListItem(Item item, float quantity)
    {
        this.item = item;
        this.quantity = quantity;
    }
    
}

/**
 *
 * @author jignesh
 */
public class Main
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Item item1 = new Item(1, "Toothpaste", (float)70.0);
        Item item2 = new Item(2, "Toothbrush", 40.0f);
        Item item3 = new Item(3, "Toothpick", 50);
        item3.rate = 30;

        ListItem listItem1  = new ListItem(item1, 2);
        ListItem listItem2  = new ListItem(item2, 3);
        ListItem listItem3  = new ListItem(item3, 1);
        
        String line;
        System.out.println("             *** INVOICE ***");
        System.out.println("|---------------------------------------|");
        System.out.println("|    ITEM    |   QTY  |  RATE  | AMOUNT |");
        System.out.println("|---------------------------------------|");
        line = String.format("| %-10s | %6.2f | %6.2f | %6.2f |",
                listItem1.item.name,
                listItem1.quantity,
                listItem1.item.rate,
                listItem1.item.rate * listItem1.quantity);
        System.out.println(line);
        line = String.format("| %-10s | %6.2f | %6.2f | %6.2f |",
                listItem2.item.name,
                listItem2.quantity,
                listItem2.item.rate,
                listItem2.item.rate * listItem2.quantity);
        System.out.println(line);
        line = String.format("| %-10s | %6.2f | %6.2f | %6.2f |",
                listItem3.item.name,
                listItem3.quantity,
                listItem3.item.rate,
                listItem3.item.rate * listItem3.quantity);
        System.out.println(line);
        System.out.println("|---------------------------------------|");
    }
    
}
