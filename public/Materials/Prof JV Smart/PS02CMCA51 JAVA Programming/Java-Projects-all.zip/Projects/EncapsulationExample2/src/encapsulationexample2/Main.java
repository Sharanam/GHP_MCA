/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encapsulationexample2;

class Item
{
    
    public int id;
    public String name;
    public float rate;
    public float gST;
    
    public Item()
    {
        id = -1;
        name = null;
        rate = -1;
        gST = 0.18f;
    }

    public Item(int id, String name, float rate)
    {
        this.id = id;
        this.name = name;
        this.rate = rate;
        gST = 0.18f;
    }
    
}

class ListItem
{
    public Item item;
    public float quantity;
    
    public ListItem()
    {
        item = null;
        quantity = -1;
    }

    public ListItem(Item item, float quantity)
    {
        this.item = item;
        this.quantity = quantity;
    }
    
}

/**
 *
 * @author jignesh
 */
public class Main
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Item item1 = new Item(1, "Toothpaste", 70 / 1.18f);
        ListItem listItem1 = new ListItem(item1, 2);
        Item item2 = new Item(2, "Toothbrush", 40 / 1.18f);
        ListItem listItem2 = new ListItem(item2, 3);
        Item item3 = new Item(3, "Toothpick", 50 / 1.18f);
        item3.rate = 30 / 1.18f;
        ListItem listItem3 = new ListItem(item3, 1);
        
        String line;
        System.out.println("                      *** INVOICE ***");
        System.out.println("|---------------------------------------------------------|");
        System.out.println("|    ITEM    |   QTY  |  RATE  | AMOUNT |   GST  |  TOTAL |");
        System.out.println("|---------------------------------------------------------|");
        line = String.format("| %-10s | %6.2f | %6.2f | %6.2f | %6.2f | %6.2f |",
                listItem1.item.name,
                listItem1.quantity,
                listItem1.item.rate,
                listItem1.item.rate * listItem1.quantity,
                listItem1.item.rate * listItem1.quantity *
                        listItem1.item.gST,
                listItem1.item.rate * listItem1.quantity +
                listItem1.item.rate * listItem1.quantity *
                        listItem1.item.gST);
        System.out.println(line);
        line = String.format("| %-10s | %6.2f | %6.2f | %6.2f | %6.2f | %6.2f |",
                listItem2.item.name,
                listItem2.quantity,
                listItem2.item.rate,
                listItem2.item.rate * listItem2.quantity,
                listItem2.item.rate * listItem2.quantity *
                        listItem1.item.gST,
                listItem2.item.rate * listItem2.quantity +
                listItem2.item.rate * listItem2.quantity *
                        listItem1.item.gST);
        System.out.println(line);
        line = String.format("| %-10s | %6.2f | %6.2f | %6.2f | %6.2f | %6.2f |",
                listItem3.item.name,
                listItem3.quantity,
                listItem3.item.rate,
                listItem3.item.rate * listItem3.quantity,
                listItem3.item.rate * listItem3.quantity *
                        listItem1.item.gST,
                listItem3.item.rate * listItem3.quantity +
                listItem3.item.rate * listItem3.quantity *
                        listItem1.item.gST);
        System.out.println(line);
        System.out.println("|---------------------------------------------------------|");
    }
    
}
