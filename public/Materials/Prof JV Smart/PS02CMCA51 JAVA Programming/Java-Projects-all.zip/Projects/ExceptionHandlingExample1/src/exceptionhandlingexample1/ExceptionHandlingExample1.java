/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample1;

/**
 *
 * @author class
 */
public class ExceptionHandlingExample1
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws
            NoSuchAccountException, InsufficientBalanceException
    {
        System.out.println("Starting operation...");
        GUITransaction.calltransaction(150, 'w', 15000);
        System.out.println("Operation completed.");
    }
}
