/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample1;

/**
 *
 * @author class
 */
public class BusinessLogic
{
    public static void checkAllowedTransaction(int accountNumber,
            char transactionType, double amount) throws
                NoSuchAccountException, InsufficientBalanceException
    {
        System.out.println("BusinessLogic.checkAllowedTransaction() called...");
        if (accountNumber < 1 || accountNumber > 100)
            throw new NoSuchAccountException();
        if (transactionType == 'w' && amount > 20000)
            throw new InsufficientBalanceException();
        System.out.println("Transaction allowed");
    }
}
