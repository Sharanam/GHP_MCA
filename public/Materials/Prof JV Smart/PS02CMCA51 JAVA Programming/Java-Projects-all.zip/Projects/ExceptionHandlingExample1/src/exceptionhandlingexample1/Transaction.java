/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample1;

/**
 *
 * @author class
 */
public class Transaction
{
  public static void performTransaction(int accountNumber,
            char transactionType, double amount) throws
          NoSuchAccountException, InsufficientBalanceException
  {
      System.out.println("calling BusinessLogic.checkAllowedTransaction()...");
      BusinessLogic.checkAllowedTransaction(accountNumber, transactionType, amount);
      System.out.println("Transaction succeeded");
  }
}
