/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample1;

/**
 *
 * @author class
 */
public class Transaction
{
  public static void performTransaction(int accountNumber,
            char transactionType, double amount) throws
          NoSuchAccountException, InsufficientBalanceException
  {
      System.out.println("calling BusinessLogic.checkAllowedTransaction()...");
      try
      {
        BusinessLogic.checkAllowedTransaction(accountNumber, transactionType, amount);
      } catch (NoSuchAccountException ex)
      {
          System.out.println("NoSuchAccountException caught in performTransaction()");
          throw ex;
      }
      catch (InsufficientBalanceException ex)
      {
          System.out.println("InsufficientBalanceException caught in performTransaction()");
          throw ex;
      }
      System.out.println("Transaction succeeded");
  }
}
