/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionhandlingexample5;

/**
 *
 * @author class
 */
public class ExceptionHandlingExample5
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception
    {
        System.out.println("Starting...");
        System.out.println("000 main start...");
//        try
        {
            System.out.println("\t111 start...");
//            try
            {
                System.out.println("\t\t222 start...");
//                try
                {
                    System.out.println("\t\t\t333 start...");
//                    try
//                    {
                        System.out.println("\t\t\t\tMain Logic...");
//                        throw new Exception("Exception in Main Logic");
                        int x = -1;
                        x = Integer.parseInt("aaa");
//                        System.out.println("After throw..." + x);
//                    } catch (RuntimeException ex)
//                    {
//                        System.out.println("****Caught and handled exception " +
//                                ex + " in inner block level 3");
//                    }
                    
//                    System.out.println("\t\t\t333 end...");
                }
//                catch (RuntimeException ex)
//                {
//                    System.out.println("****Caught and handled exception " +
//                            ex + " in inner block level 2");
//                }
//                System.out.println("\t\t222 end...");
            }
//            catch (RuntimeException ex)
//            {
//                System.out.println("****Caught and handled exception " +
//                        ex + " in inner block level 1");
//            }
//            System.out.println("\t111 end...");
        }
//        catch (RuntimeException ex)
//        {
//            System.out.println("****Caught and handled exception " +
//                    ex + " in man block");
//        }
//        System.out.println("000 main Finished.");
    }
}
