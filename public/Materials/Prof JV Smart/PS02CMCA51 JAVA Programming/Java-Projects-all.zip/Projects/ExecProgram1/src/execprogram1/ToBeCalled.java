/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package execprogram1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author jignesh
 */
public class ToBeCalled {

    public static void main(String[] args) {
        int p = 0, r = 0, n = 0, i;
        BufferedReader br;
        System.err.println("from toBeCalled...");
        for (String arg : args) {
            System.out.print(arg + " ");
        }
        System.out.println();
        br = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Enter the Principal amount: ");
            p = Integer.parseInt(br.readLine());
            System.out.println("The Principal amount is: " + p);
            System.out.print("Enter the Rate of interest: ");
            r = Integer.parseInt(br.readLine());
            System.out.println("The Rate of interest is: " + r);
            System.out.print("Enter the Period in years: ");
            n = Integer.parseInt(br.readLine());
            System.out.println("The Period in years is: " + n);
        } catch (IOException ioe) {
            System.err.println("Error reading input...");
            ioe.printStackTrace();
        }
        i = p * r * n / 100;
        System.out.println("i=" + i);
        File f = new File("test");
        try {
            f.createNewFile();
            System.err.println("File created successfully...");
        } catch (IOException exc) {
            System.err.println("Error creating file...");
            exc.printStackTrace();
        }
        try {
            FileWriter fw = new FileWriter(f);
            fw.write("The simple interest is: " + i + "\n");
            fw.flush();
        } catch (IOException ioe) {
            System.err.println("Error writing to the file...");
            ioe.printStackTrace();
        }
    }
}
