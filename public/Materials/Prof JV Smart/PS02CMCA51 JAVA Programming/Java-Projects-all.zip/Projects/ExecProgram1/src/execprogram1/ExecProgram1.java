/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package execprogram1;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 *
 * @author jignesh
 */
public class ExecProgram1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.err.println("before executing ToBeCalled...");
        Runtime rt = Runtime.getRuntime();
        Process p1;
        String cmdLine = "java execprogram1.ToBeCalled arg1 arg2 arg3";
        InputStream os, es;
        OutputStream is;
        BufferedWriter bis;
        StringBuffer stdOutput = new StringBuffer();
        StringBuffer stdError = new StringBuffer();
        try
        {
            p1 = rt.exec(cmdLine);
            if (p1 != null)
            {
                System.err.println("process created...");
                os = p1.getInputStream();
                es = p1.getErrorStream();
                is = p1.getOutputStream();
                bis = new BufferedWriter(new OutputStreamWriter(is));
                bis.write("20000\n");
                bis.write("9\n");
                bis.write("3\n");
                bis.flush();
                ReadAndDisplayStdout thrdInput = new ReadAndDisplayStdout(os, stdOutput);
                ReadAndDisplayStderr thrdError = new ReadAndDisplayStderr(es, stdError);
                thrdInput.start();
                thrdError.start();
                try
                {
                    p1.waitFor();
                } catch (InterruptedException iexcp)
                {
                    iexcp.printStackTrace();
                }
                int exitStatus;
                try
                {
                    exitStatus = p1.exitValue();
                    try
                    {
                        Thread.sleep(1000);
                    } catch (InterruptedException iexcp)
                    {
                        iexcp.printStackTrace();
                    }
                    System.out.println("standard output:");
                    System.out.println(stdOutput);
                    System.out.println("standard error:");
                    System.out.println(stdError);
                    System.err.println("\nProcess exited with exit value "+exitStatus+".");
                    System.exit(0);
                }
                catch (IllegalThreadStateException iltstexc)
                {
                    iltstexc.printStackTrace();
                }
            }
            else
                System.err.println("Error running exec()...");
        } catch(java.io.IOException exc)
        {
            exc.printStackTrace();  
        }
        }
    
}

class ReadAndDisplayStdout extends Thread
{
    InputStream os;
    StringBuffer standardInput;
    ReadAndDisplayStdout(InputStream pis, StringBuffer stdInput)
    {
        os = pis;
        standardInput = stdInput;
    }
    @Override
    public void run()
    {
        int inp;
        while (true)
        {
            try
            {
                inp = os.read();
                if (inp == -1)
                    break;
//                System.out.print(Character.toChars(inp));
                standardInput.append(Character.toChars(inp));
            } catch (IOException ioexcp)
            {
                ioexcp.printStackTrace();
            }
        }
    }
}

class ReadAndDisplayStderr extends Thread
{
    InputStream es;
    StringBuffer standardOutput;
    ReadAndDisplayStderr(InputStream pes, StringBuffer stdOutput)
    {
        es = pes;
        standardOutput = stdOutput;
    }
    @Override
    public void run()
    {
        int inp;
        while (true)
        {
            try
            {
                inp = es.read();
                if (inp == -1)
                    break;
//                System.out.print(Character.toChars(inp));
                standardOutput.append(Character.toChars(inp));
            } catch (IOException ioexcp)
            {
                ioexcp.printStackTrace();
            }
        }
    }
}
