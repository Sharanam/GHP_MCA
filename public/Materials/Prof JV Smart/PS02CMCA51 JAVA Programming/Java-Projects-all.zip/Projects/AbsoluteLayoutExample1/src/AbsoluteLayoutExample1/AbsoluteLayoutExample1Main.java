package AbsoluteLayoutExample1;

// Fig. 14.26: MultipleSelectionTest.java
// Testing MultipleSelectionFrame.
import javax.swing.JFrame;

public class AbsoluteLayoutExample1Main
{
   public static void main( String[] args )
   { 
      AbsoluteLayoutExample1 multipleSelectionFrame =
         new AbsoluteLayoutExample1(); 
      multipleSelectionFrame.setDefaultCloseOperation( 
         JFrame.EXIT_ON_CLOSE );
      multipleSelectionFrame.setSize( 880, 200 ); // set frame size
//      multipleSelectionFrame.pack();
      multipleSelectionFrame.setVisible( true ); // display frame
      multipleSelectionFrame.selectText();
   } // end main
} // end class MultipleSelectionTest
