package AbsoluteLayoutExample1;

// Fig. 14.25: MultipleSelectionFrame.java
// Copying items from one List to another.
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;

public class AbsoluteLayoutExample1 extends JFrame 
{
   private JList colorJList; // list to hold color names
   private JTextArea copyJTextArea; // list to copy color names into
   private JButton copyJButton; // button to copy selected names
   private JButton removeJButton;
   private JButton doActionJButton;
   private static final String[] colorNames = { "Black", "Blue", "Cyan",
      "Dark Gray", "Gray", "Green", "Light Gray", "Magenta", "Orange", 
      "Pink", "Red", "White", "Yellow" };

   // MultipleSelectionFrame constructor
   public AbsoluteLayoutExample1()
   {
      super( "JTextAreaExample1" );
      setLayout(null);
      Insets insets = getInsets();

      colorJList = new JList( colorNames ); // holds names of all colors
      colorJList.setVisibleRowCount( 5 ); // show five rows
      colorJList.setSelectionMode( 
         ListSelectionModel.MULTIPLE_INTERVAL_SELECTION );
//      colorJList.setBounds(insets.left+5, insets.top+5, 100, 100);
//      add( new JScrollPane( colorJList ) ); // add list with scrollpane
      JScrollPane scrollPane = new JScrollPane( colorJList );
      scrollPane.setBounds(insets.left+5, insets.top+5, 100, 100);
      add(scrollPane);
      
      copyJButton = new JButton( "Copy >>>" ); // create copy button
      copyJButton.addActionListener(

         new ActionListener() // anonymous inner class 
         {  
            // handle button event
            public void actionPerformed( ActionEvent event )
            {
               // place selected values in copyJList
//               copyJList.setListData( colorJList.getSelectedValuesList().toArray());
               for (Object selectedItem : colorJList.getSelectedValuesList())
               {
                   System.out.println("selected color="+selectedItem);
                   copyJTextArea.append(selectedItem.toString());
                   copyJTextArea.append("\n");
               }
            } // end method actionPerformed
         } // end anonymous inner class
      ); // end call to addActionListener
      copyJButton.setBounds(insets.left+155, insets.top+5, 150, 50);

      add( copyJButton ); // add copy button to JFrame

      removeJButton = new JButton( "Remove..." );
      removeJButton.addActionListener(

         new ActionListener() // anonymous inner class 
         {  
            // handle button event
            public void actionPerformed( ActionEvent event )
            {
               // place selected values in copyJList
//               copyJList.setListData( colorJList.getSelectedValuesList().toArray());
               if (copyJTextArea.getText().length() == 0)
                    System.out.println("No items");
               else
               {
                   copyJTextArea.setText("");
               }
           }
             // end method actionPerformed
         } // end anonymous inner class
      ); // end call to addActionListener
      removeJButton.setBounds(insets.left+325, insets.top+5, 150, 50);
      add(removeJButton) ;

      doActionJButton = new JButton( "Act!" ); // create action button
      doActionJButton.addActionListener(

         new ActionListener() // anonymous inner class 
         {  
            // handle button event
            public void actionPerformed( ActionEvent event )
            {
                selectText();
            } // end method actionPerformed
         } // end anonymous inner class
      ); // end call to addActionListener

      doActionJButton.setBounds(insets.left+495, insets.top+5, 150, 50);
      add( doActionJButton ); // add copy button to JFrame

      
//      copyJTextArea = new JTextArea("0123456789\n01234567890", 5, 15);
      copyJTextArea = new JTextArea("Type here...", 5, 15);
//      copyJTextArea.insert("new text", 15);
      copyJTextArea.setLineWrap(true);
      copyJTextArea.setWrapStyleWord(true);
      copyJTextArea.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e)
            {
                String text = copyJTextArea.getText();
                if ("Type here...".equals(text))
                {
                    copyJTextArea.setText("");
                }
            }

            @Override
            public void keyPressed(KeyEvent e)
            {

            }

            @Override
            public void keyReleased(KeyEvent e)
            {
                
            }
        });
      copyJTextArea.addFocusListener(new FocusListener() {

            @Override
            public void focusGained(FocusEvent e)
            {
                String text = copyJTextArea.getText();
                if ("Type here...".equals(text))
                {
                    copyJTextArea.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e)
            {
                if (copyJTextArea.getText().length() == 0)
                {
                    copyJTextArea.setText("Type here...");
                }
            }
        });
      copyJTextArea.setBounds(insets.left+686, insets.top+5, 150, 150);
      add(copyJTextArea);
//      add( new JScrollPane( copyJTextArea ) );
//      JScrollPane scrollPane2 = new JScrollPane( copyJTextArea );
//      scrollPane2.setBounds(insets.left+686, insets.top+5, 150, 150);
//      add(scrollPane2);
   } // end MultipleSelectionFrame constructor
   
   public void selectText()
   {
       System.out.println("Text="+copyJTextArea.getText()+" length="+copyJTextArea.getText().length());
//       copyJTextArea.setCaretPosition(copyJTextArea.getText().length()-1);
       copyJTextArea.setSelectionColor(Color.red);
//       copyJTextArea.setSelectionStart(0);
//       copyJTextArea.setSelectionEnd(copyJTextArea.getText().length());
       copyJTextArea.setCaretPosition(0);
       copyJTextArea.moveCaretPosition(copyJTextArea.getText().length());
//       copyJTextArea.setSelectionEnd(4);
       System.out.println("getSelectionStart()=" + copyJTextArea.getSelectionStart() +
                " getSelectionEnd()=" + copyJTextArea.getSelectionEnd());
       copyJTextArea.revalidate();
       copyJTextArea.repaint();
       
   }
} // end class MultipleSelectionFrame
