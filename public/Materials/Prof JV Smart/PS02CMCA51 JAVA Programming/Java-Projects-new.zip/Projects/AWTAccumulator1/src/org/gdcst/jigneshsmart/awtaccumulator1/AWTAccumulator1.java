/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gdcst.jigneshsmart.awtaccumulator1;

import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author jignesh
 */
public class AWTAccumulator1 extends Frame implements ActionListener {
   private Label lblInput;
   private Label lblOutput;
   private TextField tfInput;
   private TextField tfOutput;
   private int sum = 0;
 
   public AWTAccumulator1()
   {
      setLayout(new FlowLayout());
 
      lblInput = new Label("Enter an Integer: ");
      add(lblInput);
 
      tfInput = new TextField(10);
      add(tfInput);
 
      tfInput.addActionListener(this);
 
      lblOutput = new Label("The Accumulated Sum is: ");
      add(lblOutput);
 
      tfOutput = new TextField(10);
      tfOutput.setEditable(false);
      add(tfOutput);
 
      setTitle("AWT Accumulator");
      setSize(350, 120);
      setVisible(true);

      MyWindowAdapter myWindowAdapter =
                new MyWindowAdapter();
      this.addWindowListener(myWindowAdapter);

      /*
      this.addWindowListener(
              new WindowAdapter()
              {
                  public void windowClosing(WindowEvent we)
                  {
                        dispose();
                  }
              }
          );
      */

   }

   class MyWindowAdapter extends WindowAdapter
   {
        @Override
        public void windowClosing(WindowEvent we)
        {
            System.out.println("windowClosing()...");
            dispose();
        }

   }
 
   public static void main(String[] args)
   {
      AWTAccumulator1 frame = new AWTAccumulator1();
   }
 
   @Override
   public void actionPerformed(ActionEvent evt)
   {
      int numberIn = Integer.parseInt(tfInput.getText());
      sum += numberIn;
//      tfOutput.setText(sum + "");
      tfOutput.setText(String.valueOf(sum));
      tfInput.setText("");
   }

}
