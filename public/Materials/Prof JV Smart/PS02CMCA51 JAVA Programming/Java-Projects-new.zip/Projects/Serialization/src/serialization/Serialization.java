/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package serialization;

import deptemplibrary.Department;
import deptemplibrary.Employee;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author system
 */
public class Serialization
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Department d1 = new Department(1, "Purchase");
        d1.addEmployee(new Employee(101, "aaa", true, 111234.56));
        d1.addEmployee(new Employee(102, "bbb", false, 122234.56));
        d1.addEmployee(new Employee(103, "ccc", false, 13334.56));
        System.out.println(d1);
        File data = new File("data");
        try
        {
            OutputStream os = new FileOutputStream(data);
            ObjectOutputStream oos = new ObjectOutputStream(os);
            oos.writeObject(d1);
            oos.close();
            os.close();
        }
        catch (FileNotFoundException ex)
        {
            Logger.getLogger(Serialization.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (IOException ex)
        {
            Logger.getLogger(Serialization.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
