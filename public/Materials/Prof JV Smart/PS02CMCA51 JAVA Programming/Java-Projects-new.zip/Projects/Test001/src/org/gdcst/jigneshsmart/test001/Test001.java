/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gdcst.jigneshsmart.test001;

/**
 *
 * @author jignesh
 */
public class Test001 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        AWTAccumulaor2 aWTAccumulaor2 = new AWTAccumulaor2();
        aWTAccumulaor2.show();
    }
    
}
