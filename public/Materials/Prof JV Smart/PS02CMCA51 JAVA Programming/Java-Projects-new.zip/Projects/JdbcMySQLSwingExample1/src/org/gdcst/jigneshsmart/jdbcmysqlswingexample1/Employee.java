/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gdcst.jigneshsmart.jdbcmysqlswingexample1;

/**
 *
 * @author jignesh
 */
public class Employee {
    
    public int empNo;
    public String name;
    public String department;
    public String designation;
    public double salary;

    public Employee(int empNo, String name, String department, String designation, double salary) {
        this.empNo = empNo;
        this.name = name;
        this.department = department;
        this.designation = designation;
        this.salary = salary;
    }    
    
}
