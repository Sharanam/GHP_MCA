/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gdcst.jigneshsmart.jdbcswingexample1;

import java.awt.Container;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

class DataAccessException extends Exception
{

    public DataAccessException(String msg)
    {
        super(msg);
    }
}

class Employee
{

    public int empNo;
    public String empName;
    public String department;
    public String designation;
    public double salary;

    public Employee()
    {
        empNo = -1;
        empName = null;
        department = null;
        designation = null;
        salary = -1;
    }

    public Employee(int empNo, String empName, String department, String designation, double salary)
    {
        this.empNo = empNo;
        this.empName = empName;
        this.department = department;
        this.designation = designation;
        this.salary = salary;
    }

}

/**
 *
 * @author jignesh
 */
public class JdbcSwingExample1 extends javax.swing.JFrame
{

    static String schema = "testemployees";
    static String userName = "root";
    static String password = "gdcst";
    static String url = "jdbc:mysql://localhost:3306/"
            + schema + "?autoReconnect=true&useSSL=false";
    static String driver = "com.mysql.cj.jdbc.Driver";
    static Connection connection = null;
    static String action;

    static ArrayList<Employee> employees = new ArrayList<>();
    static int currentRow = -1;

    /**
     * Creates new form JdbcSwingExample1
     */
    public JdbcSwingExample1()
    {
        initComponents();
        try
        {
//            Class.forName(driver);
            Class.forName(driver).newInstance();
        }
//        catch (ClassNotFoundException ex)
        catch (ClassNotFoundException | InstantiationException |
                IllegalAccessException ex)
        {
            jLabelMessage.setText(ex.getLocalizedMessage());
            ex.printStackTrace();
        }
        try {
            connection = DriverManager.getConnection(url, userName, password);
        } catch (SQLException ex) {
            jLabelMessage.setText(ex.getLocalizedMessage());
            Logger.getLogger(JdbcSwingExample1.class.getName()).log(Level.SEVERE, null, ex);
        }

        try
        {
            loadData();
        }
        catch (DataAccessException ex)
        {
            jLabelMessage.setText(ex.getLocalizedMessage());
            Logger.getLogger(JdbcSwingExample1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void insertEmployee(int empNo, String name, String department,
            String designation, Double salary) throws DataAccessException
    {
        try
        {
            String query;
/*        
            query = "insert into employees values(" + empno
                    + ", '" + name + "', '" + department
                    + "', '" + designation + "', " + salary + ")";
            System.out.println("query=" + query);
*/        
            query = "insert into employees(empno, name, department, designation, salary) values(?, ?, ?, ?, ?)";
//            Statement statement = connection.createStatement();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, empNo);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, department);
            preparedStatement.setString(4, designation);
            preparedStatement.setDouble(5, salary);
//            int val = statement.executeUpdate(query);
            int val = preparedStatement.executeUpdate();
            if (val != 1)
            {
                throw new DataAccessException("Insert failed.");
            }
            else
            {
                System.out.println("Data inserted successfully");
            }
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            jLabelMessage.setText(s.getLocalizedMessage());            
            throw new DataAccessException("Insert failed.");
        }
    }

    void updateEmployee(int empNo, String name, String department,
            String designation, Double salary, int oldEmpNo) throws DataAccessException
    {
        try
        {
            String query;
//            query = "update employees set "
//                    + "empno=" + empNo
//                    + ",name='" + name
//                    + "', department='" + department
//                    + "', designation='" + designation
//                    + "', salary=" + salary
//                    + " where empno=" + oldEmpNo;
//            System.out.println("query=" + query);
            query = "update employees set empno=?, name=?, department=?, designation=?, salary=? where empno=?";
//            Statement statement = connection.createStatement();
//            int val = statement.executeUpdate(query);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, empNo);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, department);
            preparedStatement.setString(4, designation);
            preparedStatement.setDouble(5, salary);
            preparedStatement.setInt(6, oldEmpNo);
            int val = preparedStatement.executeUpdate();
            if (val != 1)
            {
                throw new DataAccessException("Unexpected operation: " + val + " rows updated");
            }
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            jLabelMessage.setText(s.getLocalizedMessage());            
            throw new DataAccessException("Update failed.");
        }
        catch (DataAccessException dae)
        {
            jLabelMessage.setText(dae.getLocalizedMessage());            
            throw new DataAccessException("Deletion failed.");
        }
    }

    void deleteEmployee(int empNo) throws DataAccessException
    {
        try
        {
            String query;
//            query = "delete from employees where empno=" + empNo;
//            System.out.println("query=" + query);
            query = "delete from employees where empno=?";
//            Statement statement = connection.createStatement();
//            int val = statement.executeUpdate(query);
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, empNo);
            int val = preparedStatement.executeUpdate();
            if (val != 1)
            {
                throw new DataAccessException("Unexpected operation: " + val + " rows deleted");
            }
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            jLabelMessage.setText(s.getLocalizedMessage());            
            throw new DataAccessException("Deletion failed.");
        }
        catch (DataAccessException dae)
        {
            jLabelMessage.setText(dae.getLocalizedMessage());            
            throw new DataAccessException("Deletion failed.");
        }
    }

    void loadData() throws DataAccessException
    {
        String query;
        query = "select empno, name, department, designation, salary from employees order by empno";
        employees.clear();
        try
        {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next())
            {
                int empno = rs.getInt(1);
                String name = rs.getString(2);
                String department = rs.getString(3);
                String designation = rs.getString(4);
                double salary = rs.getDouble(5);
                Employee employee = new Employee(empno, name, department, designation, salary);
                employees.add(employee);
            }
            if (employees.size() > 0)
            {
                currentRow = 0;
                Employee employee = employees.get(currentRow);
                jTextFieldEmpNo.setText(String.valueOf(employee.empNo));
                jTextFieldEmpName.setText(employee.empName);
                jTextFieldDepartment.setText(employee.department);
                jTextFieldDesignation.setText(employee.designation);
                jTextFieldSalary.setText(String.valueOf(employee.salary));
            }
            else
            {
                jTextFieldEmpNo.setText("");
                jTextFieldEmpName.setText("");
                jTextFieldDepartment.setText("");
                jTextFieldDesignation.setText("");
                jTextFieldSalary.setText("");
            }
            enableDisableButtons(true);
            jButtonSave.setVisible(false);
            jButtoncancel.setVisible(false);
            jLabelMessage.setText("");
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            jLabelMessage.setText(s.getLocalizedMessage());
            throw new DataAccessException("select failed.");
        }
    }

    void enableDisableButtons(boolean clearMessage)
    {
        if (employees.isEmpty())
        {
            jButtonFirst.setEnabled(false);
            jButtonPrevious.setEnabled(false);
            jButtonNext.setEnabled(false);
            jButtonLast.setEnabled(false);
        }
        else
        {
            if (currentRow == 0)
            {
                jButtonFirst.setEnabled(false);
                jButtonPrevious.setEnabled(false);
            }
            else
            {
                jButtonFirst.setEnabled(true);
                jButtonPrevious.setEnabled(true);
            }
            if (currentRow == employees.size() - 1)
            {
                jButtonNext.setEnabled(false);
                jButtonLast.setEnabled(false);
            }
            else
            {
                jButtonNext.setEnabled(true);
                jButtonLast.setEnabled(true);
            }
        }
        if (clearMessage)
            jLabelMessage.setText("");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextFieldEmpNo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldEmpName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldDepartment = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextFieldDesignation = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextFieldSalary = new javax.swing.JTextField();
        jButtonFirst = new javax.swing.JButton();
        jButtonPrevious = new javax.swing.JButton();
        jButtonNext = new javax.swing.JButton();
        jButtonLast = new javax.swing.JButton();
        jButtonAdd = new javax.swing.JButton();
        jButtonEdit = new javax.swing.JButton();
        jButtonDelete = new javax.swing.JButton();
        jButtonSave = new javax.swing.JButton();
        jButtoncancel = new javax.swing.JButton();
        jLabelMessage = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Employee Number");

        jTextFieldEmpNo.setToolTipText("Employee Number");
        jTextFieldEmpNo.setEnabled(false);
        jTextFieldEmpNo.setPreferredSize(new java.awt.Dimension(80, 27));

        jLabel2.setText("Employee Nane");

        jTextFieldEmpName.setToolTipText("Employee Name");
        jTextFieldEmpName.setEnabled(false);
        jTextFieldEmpName.setPreferredSize(new java.awt.Dimension(200, 27));

        jLabel3.setText("Department Name");

        jTextFieldDepartment.setToolTipText("Department Name");
        jTextFieldDepartment.setEnabled(false);
        jTextFieldDepartment.setPreferredSize(new java.awt.Dimension(200, 27));

        jLabel4.setText("Designation");

        jTextFieldDesignation.setToolTipText("Designation");
        jTextFieldDesignation.setEnabled(false);
        jTextFieldDesignation.setPreferredSize(new java.awt.Dimension(200, 27));

        jLabel5.setText("Salary");

        jTextFieldSalary.setToolTipText("Salary");
        jTextFieldSalary.setEnabled(false);
        jTextFieldSalary.setPreferredSize(new java.awt.Dimension(200, 27));

        jButtonFirst.setText("First");
        jButtonFirst.setToolTipText("First Row");
        jButtonFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFirstActionPerformed(evt);
            }
        });

        jButtonPrevious.setText("Previous");
        jButtonPrevious.setToolTipText("Previous Row");
        jButtonPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPreviousActionPerformed(evt);
            }
        });

        jButtonNext.setText("Next");
        jButtonNext.setToolTipText("Next Row");
        jButtonNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNextActionPerformed(evt);
            }
        });

        jButtonLast.setText("Last");
        jButtonLast.setToolTipText("Last Row");
        jButtonLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLastActionPerformed(evt);
            }
        });

        jButtonAdd.setText("Add");
        jButtonAdd.setToolTipText("Insert new employee");
        jButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddActionPerformed(evt);
            }
        });

        jButtonEdit.setText("Edit");
        jButtonEdit.setToolTipText("Modify");
        jButtonEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditActionPerformed(evt);
            }
        });

        jButtonDelete.setText("Delete");
        jButtonDelete.setToolTipText("Delete");
        jButtonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteActionPerformed(evt);
            }
        });

        jButtonSave.setText("Save");
        jButtonSave.setToolTipText("Save");
        jButtonSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaveActionPerformed(evt);
            }
        });

        jButtoncancel.setText("Cancel");
        jButtoncancel.setToolTipText("Cancel");
        jButtoncancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtoncancelActionPerformed(evt);
            }
        });

        jLabelMessage.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jButtonFirst)
                .addGap(44, 44, 44)
                .addComponent(jButtonPrevious)
                .addGap(38, 38, 38)
                .addComponent(jButtonNext)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addComponent(jButtonLast)
                .addGap(36, 36, 36))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(jButtonAdd)
                        .addGap(55, 55, 55)
                        .addComponent(jButtonEdit)
                        .addGap(54, 54, 54)
                        .addComponent(jButtonDelete))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(151, 151, 151)
                        .addComponent(jButtonSave)
                        .addGap(58, 58, 58)
                        .addComponent(jButtoncancel))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelMessage)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1))
                                .addGap(47, 47, 47)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldEmpName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldDesignation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextFieldSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextFieldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextFieldEmpName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextFieldDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextFieldDesignation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(jTextFieldSalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonFirst)
                    .addComponent(jButtonPrevious)
                    .addComponent(jButtonNext)
                    .addComponent(jButtonLast))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonAdd)
                    .addComponent(jButtonEdit)
                    .addComponent(jButtonDelete))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonSave)
                    .addComponent(jButtoncancel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelMessage)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonFirstActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonFirstActionPerformed
    {//GEN-HEADEREND:event_jButtonFirstActionPerformed
        if (employees.size() > 0)
        {
            currentRow = 0;
            Employee employee = employees.get(currentRow);
            jTextFieldEmpNo.setText(String.valueOf(employee.empNo));
            jTextFieldEmpName.setText(employee.empName);
            jTextFieldDepartment.setText(employee.department);
            jTextFieldDesignation.setText(employee.designation);
            jTextFieldSalary.setText(String.valueOf(employee.salary));
        }
        else
        {
            jTextFieldEmpNo.setText("");
            jTextFieldEmpName.setText("");
            jTextFieldDepartment.setText("");
            jTextFieldDesignation.setText("");
            jTextFieldSalary.setText("");
        }
        enableDisableButtons(true);
    }//GEN-LAST:event_jButtonFirstActionPerformed

    private void jButtonPreviousActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonPreviousActionPerformed
    {//GEN-HEADEREND:event_jButtonPreviousActionPerformed
        if (currentRow > 0)
        {
            currentRow--;
            Employee employee = employees.get(currentRow);
            jTextFieldEmpNo.setText(String.valueOf(employee.empNo));
            jTextFieldEmpName.setText(employee.empName);
            jTextFieldDepartment.setText(employee.department);
            jTextFieldDesignation.setText(employee.designation);
            jTextFieldSalary.setText(String.valueOf(employee.salary));
        }
        else if (employees.size() == 0)
        {
            jTextFieldEmpNo.setText("");
            jTextFieldEmpName.setText("");
            jTextFieldDepartment.setText("");
            jTextFieldDesignation.setText("");
            jTextFieldSalary.setText("");
        }
        enableDisableButtons(true);
    }//GEN-LAST:event_jButtonPreviousActionPerformed

    private void jButtonNextActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonNextActionPerformed
    {//GEN-HEADEREND:event_jButtonNextActionPerformed
        if (currentRow < employees.size() - 1)
        {
            currentRow++;
            Employee employee = employees.get(currentRow);
            jTextFieldEmpNo.setText(String.valueOf(employee.empNo));
            jTextFieldEmpName.setText(employee.empName);
            jTextFieldDepartment.setText(employee.department);
            jTextFieldDesignation.setText(employee.designation);
            jTextFieldSalary.setText(String.valueOf(employee.salary));
        }
        else if (employees.size() == 0)
        {
            jTextFieldEmpNo.setText("");
            jTextFieldEmpName.setText("");
            jTextFieldDepartment.setText("");
            jTextFieldDesignation.setText("");
            jTextFieldSalary.setText("");
        }
        enableDisableButtons(true);
    }//GEN-LAST:event_jButtonNextActionPerformed

    private void jButtonLastActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonLastActionPerformed
    {//GEN-HEADEREND:event_jButtonLastActionPerformed
        if (employees.size() > 0)
        {
            currentRow = employees.size() - 1;
            Employee employee = employees.get(currentRow);
            jTextFieldEmpNo.setText(String.valueOf(employee.empNo));
            jTextFieldEmpName.setText(employee.empName);
            jTextFieldDepartment.setText(employee.department);
            jTextFieldDesignation.setText(employee.designation);
            jTextFieldSalary.setText(String.valueOf(employee.salary));
        }
        else
        {
            jTextFieldEmpNo.setText("");
            jTextFieldEmpName.setText("");
            jTextFieldDepartment.setText("");
            jTextFieldDesignation.setText("");
            jTextFieldSalary.setText("");
        }
        enableDisableButtons(true);
    }//GEN-LAST:event_jButtonLastActionPerformed

    private void jButtonAddActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonAddActionPerformed
    {//GEN-HEADEREND:event_jButtonAddActionPerformed
        System.out.println("jButtonAddActionPerformed");
        action = "Add";
        jTextFieldEmpNo.setText("");
        jTextFieldEmpName.setText("");
        jTextFieldDepartment.setText("");
        jTextFieldDesignation.setText("");
        jTextFieldSalary.setText("");
        jTextFieldEmpNo.setEnabled(true);
        jTextFieldEmpName.setEnabled(true);
        jTextFieldDepartment.setEnabled(true);
        jTextFieldDesignation.setEnabled(true);
        jTextFieldSalary.setEnabled(true);
        jButtonFirst.setVisible(false);
        jButtonPrevious.setVisible(false);
        jButtonNext.setVisible(false);
        jButtonLast.setVisible(false);
        jButtonAdd.setVisible(false);
        jButtonEdit.setVisible(false);
        jButtonDelete.setVisible(false);
        jButtonSave.setVisible(true);
        jButtoncancel.setVisible(true);
        jLabelMessage.setText("");
    }//GEN-LAST:event_jButtonAddActionPerformed

    private void jButtonEditActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonEditActionPerformed
    {//GEN-HEADEREND:event_jButtonEditActionPerformed
        action = "Edit";
        jTextFieldEmpNo.setEnabled(true);
        jTextFieldEmpName.setEnabled(true);
        jTextFieldDepartment.setEnabled(true);
        jTextFieldDesignation.setEnabled(true);
        jTextFieldSalary.setEnabled(true);
        jButtonFirst.setVisible(false);
        jButtonPrevious.setVisible(false);
        jButtonNext.setVisible(false);
        jButtonLast.setVisible(false);
        jButtonAdd.setVisible(false);
        jButtonEdit.setVisible(false);
        jButtonDelete.setVisible(false);
        jButtonSave.setVisible(true);
        jButtoncancel.setVisible(true);
        jLabelMessage.setText("");
    }//GEN-LAST:event_jButtonEditActionPerformed

    private void jButtonDeleteActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonDeleteActionPerformed
    {//GEN-HEADEREND:event_jButtonDeleteActionPerformed
        int empNo = Integer.parseInt(jTextFieldEmpNo.getText());
        try
        {
            Container contentPane = getContentPane();
            System.out.println("actionPerformed...");
            int retval = JOptionPane.showConfirmDialog(contentPane,
                    "Are you sure yu want to delete the employee record?",
                    "Confirmation",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
            if (retval == JOptionPane.YES_OPTION)
            {
                deleteEmployee(empNo);
                loadData();
            }
        }
        catch (DataAccessException ex)
        {
            jLabelMessage.setText(ex.getMessage());
        }
    }//GEN-LAST:event_jButtonDeleteActionPerformed

    private void jButtonSaveActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtonSaveActionPerformed
    {//GEN-HEADEREND:event_jButtonSaveActionPerformed
        int empNo;
        String empName;
        String department;
        String designation;
        double salary;

        switch (action)
        {
            case "Add":
                empNo = Integer.parseInt(jTextFieldEmpNo.getText());
                empName = jTextFieldEmpName.getText();
                department = jTextFieldDepartment.getText();
                designation = jTextFieldDesignation.getText();
                salary = Double.parseDouble(jTextFieldSalary.getText());
                {
                    try
                    {
                        insertEmployee(empNo, empName, department, designation, salary);
                        Employee employee = new Employee(empNo, empName, department, designation, salary);
                        employees.add(employee);
                        currentRow = employees.size() - 1;
                    }
                    catch (DataAccessException ex)
                    {
                        jLabelMessage.setText(ex.getMessage());
                        Employee employee = employees.get(currentRow);
                        jTextFieldEmpNo.setText(String.valueOf(employee.empNo));
                        jTextFieldEmpName.setText(employee.empName);
                        jTextFieldDepartment.setText(employee.department);
                        jTextFieldDesignation.setText(employee.designation);
                        jTextFieldSalary.setText(String.valueOf(employee.salary));
                    }
                }
                break;
            case "Edit":
                if (employees.size() > 0)
                {
                    Employee employee = employees.get(currentRow);
                    int oldEmpNo = employee.empNo;
                    empNo = Integer.parseInt(jTextFieldEmpNo.getText());
                    empName = jTextFieldEmpName.getText();
                    department = jTextFieldDepartment.getText();
                    designation = jTextFieldDesignation.getText();
                    salary = Double.parseDouble(jTextFieldSalary.getText());
                    try
                    {
                        updateEmployee(empNo, empName, department, designation, salary, oldEmpNo);
                        employee.empNo = empNo;
                        employee.empName = empName;
                        employee.department = department;
                        employee.designation = designation;
                        employee.salary = salary;
                    }
                    catch (DataAccessException ex)
                    {
                        jLabelMessage.setText(ex.getMessage());
                        employee = employees.get(currentRow);
                        jTextFieldEmpNo.setText(String.valueOf(employee.empNo));
                        jTextFieldEmpName.setText(employee.empName);
                        jTextFieldDepartment.setText(employee.department);
                        jTextFieldDesignation.setText(employee.designation);
                        jTextFieldSalary.setText(String.valueOf(employee.salary));
                    }
                }
                break;
        }
        jTextFieldEmpNo.setEnabled(false);
        jTextFieldEmpName.setEnabled(false);
        jTextFieldDepartment.setEnabled(false);
        jTextFieldDesignation.setEnabled(false);
        jTextFieldSalary.setEnabled(false);
        jButtonFirst.setVisible(true);
        jButtonPrevious.setVisible(true);
        jButtonNext.setVisible(true);
        jButtonLast.setVisible(true);
        jButtonAdd.setVisible(true);
        jButtonEdit.setVisible(true);
        jButtonDelete.setVisible(true);
        jButtonSave.setVisible(false);
        jButtoncancel.setVisible(false);
        enableDisableButtons(false);
    }//GEN-LAST:event_jButtonSaveActionPerformed

    private void jButtoncancelActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButtoncancelActionPerformed
    {//GEN-HEADEREND:event_jButtoncancelActionPerformed
        if (employees.size() > 0)
        {
            Employee employee = employees.get(currentRow);
            jTextFieldEmpNo.setText(String.valueOf(employee.empNo));
            jTextFieldEmpName.setText(employee.empName);
            jTextFieldDepartment.setText(employee.department);
            jTextFieldDesignation.setText(employee.designation);
            jTextFieldSalary.setText(String.valueOf(employee.salary));
        }
        else
        {
            jTextFieldEmpNo.setText("");
            jTextFieldEmpName.setText("");
            jTextFieldDepartment.setText("");
            jTextFieldDesignation.setText("");
            jTextFieldSalary.setText("");
        }
        jTextFieldEmpNo.setEnabled(false);
        jTextFieldEmpName.setEnabled(false);
        jTextFieldDepartment.setEnabled(false);
        jTextFieldDesignation.setEnabled(false);
        jTextFieldSalary.setEnabled(false);
        jButtonFirst.setVisible(true);
        jButtonPrevious.setVisible(true);
        jButtonNext.setVisible(true);
        jButtonLast.setVisible(true);
        jButtonAdd.setVisible(true);
        jButtonEdit.setVisible(true);
        jButtonDelete.setVisible(true);
        jButtonSave.setVisible(false);
        jButtoncancel.setVisible(false);
    }//GEN-LAST:event_jButtoncancelActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Nimbus".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(JdbcSwingExample1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(JdbcSwingExample1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(JdbcSwingExample1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(JdbcSwingExample1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new JdbcSwingExample1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAdd;
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonEdit;
    private javax.swing.JButton jButtonFirst;
    private javax.swing.JButton jButtonLast;
    private javax.swing.JButton jButtonNext;
    private javax.swing.JButton jButtonPrevious;
    private javax.swing.JButton jButtonSave;
    private javax.swing.JButton jButtoncancel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabelMessage;
    private javax.swing.JTextField jTextFieldDepartment;
    private javax.swing.JTextField jTextFieldDesignation;
    private javax.swing.JTextField jTextFieldEmpName;
    private javax.swing.JTextField jTextFieldEmpNo;
    private javax.swing.JTextField jTextFieldSalary;
    // End of variables declaration//GEN-END:variables
}
