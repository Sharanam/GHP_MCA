/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gdcst.jigneshsmart.exceptionhandlingnew3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author jignesh
 */
public class ExceptionHandlingNew3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String input;
        System.out.print("Enter an integer: ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            input = br.readLine();
            int no1;
            no1 = Integer.parseInt(input);
            System.out.println("no1=" + no1);
        } catch (IOException ioe) {
            System.err.println("IOException: " + ioe);
        } catch (NumberFormatException nfe) {
            System.err.println("Invalid integer entered");
//        } catch (Exception ex) {
//            System.err.println("Some error occured" + ex);
        }
    }
}
