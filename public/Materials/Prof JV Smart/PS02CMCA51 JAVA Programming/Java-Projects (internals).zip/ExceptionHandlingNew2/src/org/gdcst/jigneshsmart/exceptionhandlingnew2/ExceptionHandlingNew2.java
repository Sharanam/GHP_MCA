/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.gdcst.jigneshsmart.exceptionhandlingnew2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author jignesh
 */
public class ExceptionHandlingNew2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        String input = null;
        String input;
        System.out.print("Enter an integer: ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        try {
            input = br.readLine();
            int no1;
            try {
                no1 = Integer.parseInt(input);
                System.out.println("no1=" + no1);
            } catch (NumberFormatException nfe) {
                System.err.println("Enter a valid integer");
            }
        } catch (IOException ioe) {
            System.err.println("IOException: " + ioe);
//            input = "";
        }
    }

}
