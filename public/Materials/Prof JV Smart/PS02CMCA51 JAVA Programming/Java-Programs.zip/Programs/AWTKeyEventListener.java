import java.awt.*;
import java.awt.event.*;
 
public class AWTKeyEventListener extends Frame
{
   private Label lblInput;
   private Label lblOutput;
   private TextField tfMessage;
   private TextField tfInput;
   private TextField tfOutput;
   private int sum = 0;
 
   public AWTKeyEventListener()
   {
      setLayout(new FlowLayout());
 
      lblInput = new Label("Enter an Integer: ");
      add(lblInput);
 
      tfInput = new TextField(10);
      add(tfInput);
 
      tfInput.addKeyListener(new MyKeyListener());
 
      lblOutput = new Label("The Accumulated Sum is: ");
      add(lblOutput);
 
      tfOutput = new TextField(30);
      tfOutput.setEditable(false);
      add(tfOutput);
 
      tfMessage = new TextField("                              ");
      tfMessage.setEnabled(false);
      add(tfMessage);
 
      setTitle("AWT Accumulator");
      setSize(400, 120);
      setVisible(true);
      this.addWindowListener(
              new WindowAdapter()
              {
                  public void windowClosing(WindowEvent we)
                  {
                        dispose();
                  }
              }
                            );
   }
 
   public static void main(String[] args)
   {
      AWTKeyEventListener frame = new AWTKeyEventListener();
   }
 
    class MyKeyListener implements KeyListener
    {
       @Override
       public void keyPressed(KeyEvent evt)
       {
           int keyCode = evt.getKeyCode();
           char keyChar = evt.getKeyChar();
           System.out.println("Key Pressed: Code=" + keyCode + " Char=" + keyChar);
           String labelText = tfMessage.getText();
           labelText = labelText + "\n" + "Key Pressed: Code=" + keyCode + " Char=" + keyChar;
           tfMessage.setText(labelText);
       }

       @Override
       public void keyTyped(KeyEvent evt)
       {
           int keyCode = evt.getKeyCode();
           char keyChar = evt.getKeyChar();
           System.out.println("Key Typed: Char=" + keyChar);
           String labelText = tfMessage.getText();
           labelText = labelText + "\n" + "Key Typed: Char=" + keyChar;
           tfMessage.setText(labelText);
       }

       @Override
       public void keyReleased(KeyEvent evt)
       {
           int keyCode = evt.getKeyCode();
           char keyChar = evt.getKeyChar();
           System.out.println("Key Released: Code=" + keyCode + " Char=" + keyChar);
           String labelText = tfMessage.getText();
           labelText = labelText + "\n" + "Key Released: Code=" + keyCode + " Char=" + keyChar;
           tfMessage.setText(labelText);
       }
    }

}


