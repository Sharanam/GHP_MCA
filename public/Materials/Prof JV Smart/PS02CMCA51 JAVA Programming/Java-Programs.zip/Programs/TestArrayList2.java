import java.io.*;
import java.util.ArrayList;

class Contact
{
 String name;
 public Contact(String name)
 {
  this.name = name;
 }
 @Override
 public String toString()
 {
  return name;
 }
}
public class TestArrayList2
{
 public static void main(String[] args)
 {
  ArrayList<Contact> contacts = new ArrayList<>();
  contacts.add(new Contact("aaa"));
  contacts.add(new Contact("bbb"));
  contacts.add(new Contact("ccc"));
  contacts.add(new Contact("ddd"));
  contacts.add(new Contact("eee"));
  System.out.println("Before...");
  for (Contact contact : contacts)
      System.out.print(contact + " ");
  System.out.println();
  System.out.print("Enter the name to be deleted: ");
  BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
  String toBeDeletedName = null;
  try
  {
   toBeDeletedName = br.readLine();
  } catch (IOException ioe) {
    ioe.printStackTrace();
  }
//  Contact toBeDeleted = new Contact(toBeDeletedName);
  Contact toBeDeleted = null;
  for (Contact contact : contacts) {
      if (contact.name.equalsIgnoreCase(toBeDeletedName))
          toBeDeleted = contact;
  }
  contacts.remove(toBeDeleted);
  System.out.println("After...");
  for (Contact contact : contacts)
      System.out.print(contact + " ");
  System.out.println();
 }
}
