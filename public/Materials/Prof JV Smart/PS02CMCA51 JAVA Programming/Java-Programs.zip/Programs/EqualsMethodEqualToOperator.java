public class EqualsMethodEqualToOperator
{

    static void comparePersons(Person p1, Person p2)
    {
        if (p1 == p2)
            System.out.println(String.format("%-20s %s %-20s %s", p1, "     ==     ", p2, " : Equal"));
        else
            System.out.println(String.format("%-20s %s %-20s %s", p1, "     ==     ", p2, " : Not Equal"));
        if (p1.equals(p2))
            System.out.println(String.format("%-20s %s %-20s %s", p1, "  equals()  ", p2, " : Equal"));
        else
            System.out.println(String.format("%-20s %s %-20s %s", p1, "  equals()  ", p2, " : Not Equal"));
    }

    static void compareStrings(String s1, String s2)
    {
        if (s1 == s2)
            System.out.println(String.format("%-20s %s %-20s %s", s1, "     ==     ", s2, " : Equal"));
        else
            System.out.println(String.format("%-20s %s %-20s %s", s1, "     ==     ", s2, " : Not Equal"));
        if (s1.equals(s2))
            System.out.println(String.format("%-20s %s %-20s %s", s1, "  equals()  ", s2, " : Equal"));
        else
            System.out.println(String.format("%-20s %s %-20s %s", s1, "  equals()  ", s2, " : Not Equal"));
    }

     public static void main(String[] args)
    {
        Person p1 = new Person(1, "Saina");
        Person p2 = new Person(2, "Sindhu");
        comparePersons(p1, p2);

        System.out.println();
        Person p3 = new Person(1, "Saina");
        comparePersons(p1, p3);

        System.out.println();
        String s1 = "Programmer";
        String s2 = "Manager";
        compareStrings(s1, s2);

        System.out.println();
        String s3 = "Programmer";
        compareStrings(s1, s3);

        System.out.println();
        String s4 = "Prog" + "rammer";
        System.out.println("Prog + rammer");
        compareStrings(s1, s4);

        System.out.println();
        StringBuilder sb = new StringBuilder();
        sb.append("Prog").append("rammer");
        System.out.println("sb.append(\"Prog\").append(\"rammer\")");
        String s5 = sb.toString();
        compareStrings(s1, s5);
    }
}

class Person
{
    private int id;
    private String name;

    Person()
    {
        id = -1;
        name = null;
    }

    Person(int id, String name)
    {
        this.id = id;
        this.name = name;
    }

    @Override
    public boolean equals(Object o2)
    {
        if (o2 == null)
            return false;
        if (this == o2)
            return true;
        if (this.getClass() != o2.getClass())
            return false;
        final Person p2 = (Person)o2;
        if (this.id == p2.id)
            if (this.name == null)
                if (p2.name == null)
                    return true;
                else
                    return false;
            else
                if (p2.name == null)
                    return false;
                else
                    if (this.name.equals(p2.name)) 
                        return true;
                    else
                        return false;
        else
            return false;
    }

    @Override
    public String toString()
    {
        return "Person(" + id + ", " + name + ")";
    }

}

