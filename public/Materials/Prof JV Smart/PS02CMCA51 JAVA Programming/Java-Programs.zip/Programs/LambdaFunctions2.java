/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.function.BinaryOperator;

/**
 *
 * @author jignesh
 */
public class LambdaFunctions2
{

    static int operation(int a, int b, BinaryOperator<Integer> op)
    {
        return op.apply(a, b);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        int a = 45;
        int b = 15;
        int c;
        
        c = operation(a, b, (x,y)->x+y);
        System.out.println("a + b = " + c);
        
        c = operation(a, b, (x,y)->x-y);
        System.out.println("a - b = " + c);
        
        c = operation(a, b, (x,y)->x*y);
        System.out.println("a * b = " + c);
        
        c = operation(a, b, (x,y)->x/y);
        System.out.println("a / b = " + c);
        
    }
    
}
