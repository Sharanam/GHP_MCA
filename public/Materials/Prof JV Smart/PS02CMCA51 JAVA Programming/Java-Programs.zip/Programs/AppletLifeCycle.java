import java.awt.*; 
import java.applet.*;
import java.util.ArrayList;
/*
    <applet code="AppletLifeCycle" width="300" height="500">
    </applet>
*/
public class AppletLifeCycle extends Applet
{

    ArrayList<String> messages = new ArrayList<>();

    // Called first, called one time only.
    public void init()
    {
        // initialization
        messages.add("init()");
        System.out.println("init()");
        repaint();
    }

    /* Called  after init().  Also called whenever the applet is restarted. */
    public void start()
    {
        // start or resume execution
        messages.add("start()");
        System.out.println("start()");
        repaint();
    }

    // Called when the applet is stopped.
    public void stop()
    {
        // suspends execution
        messages.add("stop()");
        System.out.println("stop()");
        repaint();
    }

    /* Called when applet is terminated.  This is the last method executed. */
    public void destroy()
    {
        // perform shutdown activities
        messages.add("destroy()");
        System.out.println("destroy()");
        repaint();
    }

    // Called when an applet's window must be restored.
    public void paint(Graphics g)
    {
        // redisplay contents of window
        System.out.println("paint()");
        setBackground(Color.cyan);
        Font font = g.getFont().deriveFont(Font.BOLD).deriveFont(20.0f);
        g.setFont(font);
        int x = 20, y = 20;
        for (String message : messages)
        {
            g.drawString(message, x, y);
            y += 40;
        }
    }

}

