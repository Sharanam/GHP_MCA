import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

// Both IOException and FileNotFoundException are handled
// In case of an exception, the program displays
// e.getMessage() and e.printStackTrace()
// and then terminates successfully.

public class ExceptionHandlingDisplayFile04
{
    public static void main (String[] args)
    {
        String inputFilename=null, line;

        if (args.length != 1)
        {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        }
        else
            inputFilename = args[0];

        File inputFile = new File(inputFilename);
        FileReader fr;
        try
        {
            fr = new FileReader(inputFile);
            BufferedReader br = new BufferedReader(fr);
            while (true)
            {
                line = br.readLine();
                if (line == null)
                    break;
                System.out.println(line);
            }
            br.close();
            fr.close();
        }
        catch(FileNotFoundException e)
        {
            System.err.println("File " + inputFilename + " not found");
            System.err.println("e.getMessage():" +
                    e.getMessage());
            System.err.println("e.getLocalizedMessage():" +
                    e.getLocalizedMessage());
            e.printStackTrace();
        }
        catch(IOException e)
        {
            System.err.println("IOException " + e.getMessage());
            e.printStackTrace();
        }
    }
}
