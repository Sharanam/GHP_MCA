print('Enter an integer:', end=' ')
no = int(input())
for i in range(no):
    print(i)
print('*****')
for i in range(no):
    print(i)
    print('----------------')
print('===== The End =====')
