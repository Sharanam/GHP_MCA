public class InnerClassExample01
{

    // A class defined inside another class is called an inner class
    class MyInnerClass {
        int instanceNumber;

        public MyInnerClass(int instanceNumber) {
            this.instanceNumber = instanceNumber;
        }

        @Override
        public String toString() {
            return "MyInnerClass[" + instanceNumber + "]";
        }

    }

    public void demonstrate() {
        MyInnerClass myInnerClassObject1 = new MyInnerClass(1);
        System.out.println(myInnerClassObject1);
        MyInnerClass myInnerClassObject2 = new MyInnerClass(2);
        System.out.println(myInnerClassObject2);
    }

    public static void main (String[] args)
    {
        InnerClassExample01 innerClassExample01 = new InnerClassExample01();
        innerClassExample01.demonstrate();
    }

}
