/*
	Display Image in an Applet Example
	This Java example shows how to display an image using drawImage method
	of an Java Graphics class.
*/
 
 
import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Image;
 
/* 
	<applet code ="Applet2DisplayImage" width="500" height="350" >
		<param name="Image1" value="One.png">
		<param name="Image2" value="Two.png">
	</applet>
*/
 
public class Applet2DisplayImage extends Applet
{
	Image img1, img2;
	
	public void init(){
		
		img1 = getImage(getDocumentBase(), getParameter("Image1"));
		img2 = getImage(getDocumentBase(), getParameter("Image2"));
	}
	
	public void paint(Graphics g){
		
		//display an image using drwaImage method of Graphics class.
		g.drawImage(img1, 100,50,this);
		g.drawImage(img2, 100,200,this);
	}
	
}
