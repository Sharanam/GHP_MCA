import java.io.*;

public class Input1
{
  public static void main (String[] args)
  {
    double radius;
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    String line=null;
    System.out.print("Enter the radius: ");
    try
    {
      line = br.readLine();
    }
    catch (IOException ex)
    {
//    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
      System.err.println("Exception: " + ex.getMessage());
    }
    radius = Double.parseDouble(line);
    System.out.println("The diameter is " + radius*2);
  }
}
