import java.util.*;

public class LambdaExpressionForEach {
    public static void main(String args[]) {
        List<String> list = new ArrayList<String>();
        list.add("Aaa");
        list.add("Bbb");
        list.add("Ccc");
        list.add("Ddd");

        // Lambda Expression
        // Part of functional programming paradigm
        // -> is the Arrow operator
        // It defines an anonymous function
        // Useful for parallelism, taking advantage of
        // multi-core architecture
        list.forEach( (str) -> { System.out.println(str); } );

//        list.forEach(
//                function display(String str) {
//                    System.out.println(str);
//                }
//                );

    }
}
