import java.util.Map;
import java.util.HashMap;

enum PageType {
    ABOUT(1),
    CODING(2),
    DATABASES(3);

    private int value;
    private static Map<Integer, PageType> map = new HashMap<>();

    private PageType(int value) {
        this.value = value;
    }

    static {
        for (PageType pageType : PageType.values()) {
            map.put(pageType.value, pageType);
        }
    }

    public static PageType valueOf(int pageType) {
        return (PageType) map.get(pageType);
    }

    public int getValue() {
        return value;
    }
}

class EnumerationExample02
{
    public static void main (String[] args)
    {
        // Enum constant to int value
        PageType pageType = PageType.DATABASES;
        int pageTypeValue = pageType.getValue(); 
        System.out.println("Value of PageType.DATABASES: " + pageTypeValue);

        // int value to enum constant
        pageType = PageType.valueOf(2);
        System.out.println("enum constant having value 2: " + pageType);
    }

}
