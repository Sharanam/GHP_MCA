import java.io.File;
import java.util.Scanner;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;

public class TryWithResources
{
    public static void main (String[] args)
    {
        File outputFile = new File("output.txt");
        // Try with resources
        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputFile)))) {
            bw.append("aaa\n");
            bw.append("bbb\n");
            bw.append("ccc\n");
        } catch(IOException e) {
            e.printStackTrace();
        }
    }
}
