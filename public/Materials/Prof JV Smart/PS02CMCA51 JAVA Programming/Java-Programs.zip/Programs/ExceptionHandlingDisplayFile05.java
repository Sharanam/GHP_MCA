import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

// Both IOException and FileNotFoundException are handled
// In case of an exception, the program displays error
// message and then rethrows the exception, which is not caught.
// Hence the program cannot compile

public class ExceptionHandlingDisplayFile05
{
    public static void main (String[] args)
    {
        String inputFilename=null, line;

        if (args.length != 1)
        {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        }
        else
            inputFilename = args[0];

        File inputFile = new File(inputFilename);
        FileReader fr;
        try
        {
            fr = new FileReader(inputFile);
            BufferedReader br = new BufferedReader(fr);
            while (true)
            {
                try
                {
                    line = br.readLine();
                    if (line == null)
                        break;
                    System.out.println(line);
                }
                catch(IOException e)
                {
                    System.err.println("IOException while reading from file " +
                            inputFilename);
                    throw e;
                }
            }
            try
            {
                br.close();
                fr.close();
            }
            catch(IOException e)
            {
                System.err.println("Error closing file " + inputFilename);
                throw e;
            }
        }
        catch(FileNotFoundException e)
        {
            System.err.println("File " + inputFilename + " not found");
            throw e;
        }
    }
}
