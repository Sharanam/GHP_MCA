// SAM (Single Abstract Method) interface / class
interface OnEventHandler
{
	public void onEvent(String prefix, String str);
}
class EventRaiser
{
	private OnEventHandler onEventHandler;
	void setOnEventListener(OnEventHandler onEventHandler)
	{
		this.onEventHandler = onEventHandler;
	}
	void generateEvent(String message)
	{
		onEventHandler.onEvent("Event", message);
	}
}
public class TestLambdaEventHandler
{
	public static void main(String[] args)
	{
		EventRaiser eventRaiser = new EventRaiser();
/*
		eventRaiser.setOnEventListener(new OnEventHandler() {
			@Override
			public void onEvent(String prefix, String str)
			{
				System.out.println(prefix + ":" + str);
			}
			});
*/
/*
		eventRaiser.setOnEventListener((String prefix, String str) -> {
							System.out.println(prefix + ":" + str); });
*/
		eventRaiser.setOnEventListener((prefix, str) -> {
							System.out.println(prefix + ":" + str); });
		eventRaiser.generateEvent("Event-1");	
		eventRaiser.generateEvent("Event-2");	
	}
}
