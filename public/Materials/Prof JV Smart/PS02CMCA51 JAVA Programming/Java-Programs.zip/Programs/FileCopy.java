import java.io.File;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileCopy
{
    public static void main (String[] args)
    {
        if (args.length != 2)
        {
            System.err.println("Usage: java FileCopy source-file destinatiom-file");
            System.exit(1);
        }
        String sourceFileName = args[0];
//        The File object is an abstract representation of file/directory paths
//        Successful creation of File object does not mean the file exists
        File sourceFile = new File(sourceFileName);
        if (!sourceFile.exists() || !sourceFile.isFile())
            {
                System.err.println("The source file " + sourceFileName + " does not exist or is not a regular file");
                System.exit(2);
            }
        String destinationFileName = args[1];
        File destinationFile = new File(destinationFileName);
        if (destinationFile.exists())
            if (destinationFile.isDirectory())
                {
                    System.err.println("The destination file " + destinationFileName + " exists and is a directory");
                    System.exit(3);
                }
            if (!destinationFile.isFile())
                {
                    System.err.println("The destination file " + destinationFileName + " exists and is not a regular file");
                    System.exit(4);
                }
            else
            {
                System.err.print("The destination file exists. Do you want to overwrite (y/n)? ");
                Scanner scanner = new Scanner(System.in);
                String line = scanner.nextLine();
                if (!line.trim().equalsIgnoreCase("y"))
                {
                    System.out.println("File copy abandoned");
                    System.exit(0);
                }
            }
        byte[] buffer = new byte[1024];
        FileInputStream fis = null;
        FileOutputStream fos = null;
        try
        {
            fis = new FileInputStream(sourceFile);
            fos = new FileOutputStream(destinationFile);
//            To append instead of overwriting            
//            FileOutputStream(destinationFile, append);
//            fos = new FileOutputStream(destinationFile, true);
            int bytesRead, byteCount;
            while ((bytesRead = fis.read(buffer)) != -1)
            {
//                FileOutputStream.write(buffer, offset, length)
                fos.write(buffer, 0, bytesRead);
            }
        }
        catch (FileNotFoundException ex)
        {
            System.err.println(ex.getMessage());
        }
        catch (IOException ex)
        {
            System.err.println(ex.getMessage());
        }
        finally
        {
            try
            {
                if (fis != null)
                    fis.close();
            }
            catch (IOException ex)
            {
            }
            try
            {
                if (fos != null)
                    fos.close();
            }
            catch (IOException ex)
            {
            }
        }
    }
}
