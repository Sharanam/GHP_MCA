import java.io.Serializable;
import java.util.ArrayList;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Scanner;
import java.net.Socket;

class Department implements Serializable
{
    static final long serialVersionUID = 42234L;  
    int deptno;
    String name;
    ArrayList<Employee> employees;
    
    public Department(int deptno, String name)
    {
        this.deptno = deptno;
        this.name = name;
        employees = new ArrayList<>();
    }
    
    public void addEmployee(Employee employee)
    {
        employees.add(employee);
    }
    
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("Department\n{\n\tdeptno=").append(
                deptno).append(",\n\tname=").append(name).append(",\n\temployees=\n\t[\n");
        for (Employee emp : employees)
        {
            sb.append("\t\t").append(emp).append("\n");
        }
        sb.append("\t]\n}");
        return sb.toString();
    }

}

class Employee implements Serializable
{
    static final long serialVersionUID = 42234L;  
    int empno;
    String name;
    char gender;
    double salary;
    
    public Employee(int empno, String name, char gender, double salary)
    {
        this.empno = empno;
        this.name = name;
        this.gender = gender;
        this.salary = salary;
    }
    
    public String toString()
    {
        return "Employee{"+empno+", "+name+", "+gender+", "+salary+"}";
    }

}

public class SerializeAndSendToServer
{

    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        String line;
        System.out.print("Enter the department number: ");
        line = scanner.nextLine();
        int deptNo = Integer.parseInt(line);
        System.out.print("Enter the department name: ");
        line = scanner.nextLine();
        String deptName = line;
        Department d1 = new Department(deptNo, deptName);
        while (true)
        {
            System.out.print("Enter the employee number (q to quit): ");
            line = scanner.nextLine();
            if (line.trim().equalsIgnoreCase("q"))
                break;
            int empNo = Integer.parseInt(line);
            System.out.print("Enter the employee name: ");
            line = scanner.nextLine();
            String empName = line;
            System.out.print("Enter the employee's gender (m/f): ");
            line = scanner.nextLine();
            char gender = line.charAt(0);
            System.out.print("Enter the employee's salary: ");
            line = scanner.nextLine();
            double salary = Double.parseDouble(line);
            d1.addEmployee(new Employee(empNo, empName, gender, salary));
        }
        System.out.println(d1);
        try
        {
            Socket socket = new Socket("127.0.0.1", 4444);
            OutputStream os = socket.getOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(os);
            oos.writeObject(d1);
            oos.close();
            os.close();
            System.out.println("Sent to server...");
        }
        catch (IOException ex)
        {
            System.err.println(ex.getMessage());
        }
    }

}

