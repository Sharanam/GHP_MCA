import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedReader;

// Only FileNotFoundException is handled.
// IOException is not handled.
// The program cannot compile

public class ExceptionHandlingDisplayFile02
{
    public static void main (String[] args)
    {
        String inputFilename=null, line;

        if (args.length != 1)
        {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        }
        else
            inputFilename = args[0];

        File inputFile = new File(inputFilename);
        FileReader fr = null;
        try
        {
            fr = new FileReader(inputFile);
        } catch(FileNotFoundException e)
        {
        }
        BufferedReader br = new BufferedReader(fr);
        while (true)
        {
            line = br.readLine();
            if (line == null)
                break;
            System.out.println(line);
        }
        br.close();
        fr.close();
    }
}
