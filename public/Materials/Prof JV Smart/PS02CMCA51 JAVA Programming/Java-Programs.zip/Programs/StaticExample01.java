public class StaticExample01
{

    static int s1;
    static int s2;
    int ns1;
    int ns2;

    StaticExample01(int ns1, int ns2) {
        this.ns1 = ns1;
        this.ns2 = ns2;
    }

    static void getValueStatic() {
        System.out.println(s1);
        System.out.println(s2);
//        System.out.println(ns1); // ERROR!
//        System.out.println(ns2); // ERROR!
    }

    void getValueNonStatic() {      // void getValueNonStatic(StaticExample01 this) { ... }
        System.out.print(ns1 + " ");  // ns1 -> this.ns1
        System.out.println(ns2);  // ns2 -> this.ns2
    }

    public static void main (String[] args)
    {
        StaticExample01.s1 = 888;
        StaticExample01.s2 = 999;

        StaticExample01 o1 = new StaticExample01(10, 20);
        StaticExample01 o2 = new StaticExample01(30, 40);
        StaticExample01 o3 = new StaticExample01(50, 60);

        System.out.println(StaticExample01.s1);
        System.out.println(StaticExample01.s2);

        System.out.println(o1.s1);
        System.out.println(o2.s2);

        System.out.println(o2.s1);
        System.out.println(o2.s2);

        System.out.println(o1.ns1);
        System.out.println(o1.ns2);

        System.out.println(o2.ns1);
        System.out.println(o2.ns2);

        System.out.println(o3.ns1);
        System.out.println(o3.ns2);

//        System.out.println(StaticExample01.ns1);
//        System.out.println(StaticExample01.ns2);

        StaticExample01.getValueStatic();

        o1.getValueStatic();

        System.out.print("o1.getValueNonStatic():");
        o1.getValueNonStatic();   // StaticExample01.getValueNonStatic(o1);

        System.out.print("o2.getValueNonStatic():");
        o2.getValueNonStatic();   // StaticExample01.getValueNonStatic(o2);

        System.out.print("o3.getValueNonStatic():");
        o3.getValueNonStatic();   // StaticExample01.getValueNonStatic(o3);

//        StaticExample01.getValueNonStatic(); // ERROR!

    }
}
