public class Initialization
{
    public static void main (String[] args)
    {
        int i;
        System.out.println("Some message");
        i = 10;
        int j = 20;
        i = 400;

        final int MAX_COUNT = 10;
        System.out.println("MAX_COUNT=" + MAX_COUNT);

        final int MAX_COUNT2;
        System.out.println("Some message");
        // System.out.println("MAX_COUNT2=" + MAX_COUNT2); // ERROR variable might not have been initialized
        MAX_COUNT2 = 20;
        System.out.println("MAX_COUNT2=" + MAX_COUNT2);
        

        // MAX_COUNT = 30; // ERROR variable might already have been assigned
        // MAX_COUNT2 = 30; // ERROR variable might already have been assigned
    }
}
