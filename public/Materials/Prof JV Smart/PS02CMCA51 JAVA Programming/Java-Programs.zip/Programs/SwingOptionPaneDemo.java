import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import javax.swing.JOptionPane;

/**
 *
 * @author class
 */
public class SwingOptionPaneDemo
{

    JFrame frame;
    JPanel contentPane;

    /**
     * Create the GUI and show it. For thread safety, this method should be
     * invoked from the event-dispatching thread.
     */
    private void createAndShowGUI()
    {
        //Create and set up the window.

        frame = new JFrame("SwingOptionPaneDemo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        contentPane = new JPanel();
        frame.add(contentPane);

        JMenuBar menuBar = new JMenuBar();

        JMenu dialogsMenu = new JMenu("Dialogs");

        JMenuItem errorDialogMenuItem = new JMenuItem("Error Dialog");
        errorDialogMenuItem.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(frame, "Alert message",
                        "Alert", JOptionPane.ERROR_MESSAGE);
//                JOptionPane.showMessageDialog(frame, "Alert message",
//                        "Help", JOptionPane.QUESTION_MESSAGE);
            }
        });
        errorDialogMenuItem.setMnemonic('e');

        JMenuItem choiceDialogMenuItem = new JMenuItem("Choice Dialog");
        choiceDialogMenuItem.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int retval = JOptionPane.showConfirmDialog(frame,
                        "Please choose one", "Information",
                        JOptionPane.YES_NO_CANCEL_OPTION,
//                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE);
                System.out.println("Return Value=" + retval);
            }
        });
        choiceDialogMenuItem.setMnemonic('c');

        JMenuItem inputDialogMenuItem = new JMenuItem("Input Dialog");
        inputDialogMenuItem.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String inputValue = JOptionPane.showInputDialog(
                        "Please input a value");
                System.out.println("Input Value=" + inputValue);
            }
        });
        inputDialogMenuItem.setMnemonic('i');

        JMenuItem optionsDialogMenuItem = new JMenuItem("Options Dialog");
        optionsDialogMenuItem.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Object[] possibleValues =
                {
                    "First", "Second", "Third"
                };

//                Object selectedOption = JOptionPane.showInputDialog(null,
                Object selectedOption = JOptionPane.showInputDialog(frame,
                        "Choose an option", "Input",
                        JOptionPane.INFORMATION_MESSAGE, null,
                        possibleValues, possibleValues[1]);
                System.out.println("Selected Option:" + selectedOption);
            }
        });
        optionsDialogMenuItem.setMnemonic('o');

        JMenuItem exitMenuItem = new JMenuItem("eXit");
        exitMenuItem.setActionCommand("Exit");
        exitMenuItem.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                frame.dispose();
            }
        });
        exitMenuItem.setMnemonic('x');

        exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
                KeyEvent.ALT_DOWN_MASK));

        dialogsMenu.add(errorDialogMenuItem);
        dialogsMenu.add(choiceDialogMenuItem);
        dialogsMenu.add(inputDialogMenuItem);
        dialogsMenu.add(optionsDialogMenuItem);
        dialogsMenu.add(exitMenuItem);

        dialogsMenu.setMnemonic('d');

        menuBar.add(dialogsMenu);

        frame.setContentPane(contentPane);
        frame.setJMenuBar(menuBar);

        //Display the window.
        frame.setSize(600, 300);
//        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args)
    {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                SwingOptionPaneDemo SwingOptionPaneDemo =
                        new SwingOptionPaneDemo();
                SwingOptionPaneDemo.createAndShowGUI();
            }
        });
    }

}
