import java.awt.*;
import java.awt.event.*;

public class AWTGridLayout extends Frame
{

    private Button[] buttons;
    private MyActionListener myActionListener;

    public AWTGridLayout()
    {
        myActionListener = new MyActionListener();

        setLayout(new GridLayout(6, 2));

        buttons = new Button[12];

        for (int i = 0; i < 12; i++)
        {
            buttons[i] = new Button(i+1+"");
            buttons[i].setActionCommand(i+1+"");
            buttons[i].addActionListener(myActionListener);
            add(buttons[i]);
        }
        
        setTitle("AWTGridLayout");
        setSize(350, 600);
        setVisible(true);
        this.addWindowListener(
                new WindowAdapter()
        {
            public void windowClosing(WindowEvent we)
            {
                dispose();
            }
        }
        );
    }

    public static void main(String[] args)
    {
        AWTGridLayout frame = new AWTGridLayout();
    }

    class MyActionListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            System.out.println("button ActionListener ActionCommand=" +
                    e.getActionCommand());
        }

    }

}
