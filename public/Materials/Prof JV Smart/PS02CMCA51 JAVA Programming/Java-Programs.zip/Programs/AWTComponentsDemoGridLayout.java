import java.awt.*;
import java.awt.event.*;

public class AWTComponentsDemoGridLayout extends Frame
{

    private Label labelTextField;
    private TextField textFieldInteger;
    private Button buttonOK;
    private Checkbox checkbox;
    private Choice choice;
    private List list;
    private TextArea textArea;

    public AWTComponentsDemoGridLayout()
    {
        setLayout(new GridLayout(6, 2));

        labelTextField = new Label("Enter an Integer: ");
        add(labelTextField);

        textFieldInteger = new TextField(10);
        add(textFieldInteger);
        
        Label labelCheckbox = new Label("Checkbox Graduate");
        add(labelCheckbox);
        checkbox = new Checkbox("Graduate", true);
        add(checkbox);

        Label labelChoice = new Label("Choice of Planets");
        add(labelChoice);
        choice = new Choice();
        choice.add("Mercury");
        choice.add("Venus");
        choice.add("Earth");
        choice.add("Mars");
        choice.add("Jupitor");
        choice.add("Saturn");
        choice.add("Uranus");
        choice.add("Neptune");
        choice.select("Earth");
        add(choice);
        
        Label labelList = new Label("List of Planets");
        add(labelList);
        list = new List();
        list.add("Mercury");
        list.add("Venus");
        list.add("Earth");
        list.add("Mars");
        list.add("Jupitor");
        list.add("Saturn");
        list.add("Uranus");
        list.add("Neptune");
        Dimension preferredSize = new Dimension(550, 500);
        list.setPreferredSize(preferredSize);
        list.setMultipleMode(true);
        list.select(2);
        list.select(5);
        add(list);

        Label labelTextArea = new Label("TextArea");
        add(labelTextArea);
        textArea = new TextArea("Type here...", 5, 40);
        textArea.selectAll();
        add(textArea);
        
        Label labelEmpty = new Label("Button");
        add(labelEmpty);
        buttonOK = new Button("OK");
        buttonOK.setActionCommand("ActionCommandOK");
        
        buttonOK.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                System.out.println("buttonOK ActionListener ActionCommand=" + e.getActionCommand());
                String textFieldContents = textFieldInteger.getText();
                System.out.println("textFieldContents=" + textFieldContents);
                System.out.println("Checkbox Graduate=" + checkbox.getState());
                System.out.println("Choice Planet=" + choice.getSelectedItem());
                for (String selectedItem : list.getSelectedItems())
                    System.out.println("Selected Planet in the list: " + selectedItem);
                System.out.println("TextArea contents=" + textArea.getText());
            }
        });
        
        add(buttonOK);
        
        
        setTitle("AWTComponentsDemoGridLayout");
        setSize(350, 600);
        setVisible(true);
        textArea.requestFocusInWindow();
        this.addWindowListener(
                new WindowAdapter()
        {
            public void windowClosing(WindowEvent we)
            {
                dispose();
            }
        }
        );
    }

    public static void main(String[] args)
    {
        AWTComponentsDemoGridLayout frame = new AWTComponentsDemoGridLayout();
    }

}
