#!/bin/bash
fiu-run ./testIOException.sh&
pid=$!
echo $pid
ps -aef | grep $pid
fiu-ctrl -c "enable_random name=posix/io/rw/read,probability=1" $pid
