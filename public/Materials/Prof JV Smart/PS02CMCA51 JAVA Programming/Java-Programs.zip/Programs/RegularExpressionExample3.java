import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Scanner;

public class RegularExpressionExample3
{
    public static void main (String[] args)
    {
        String referer = "http://localhost:8080/AuthenticationJSPExample01/Login.jsp?error=Invalid%20username%20or%20password";
//        Does not work
//        String refererPageName = referer.replaceFirst("^.*/([^/?]*)[^/]*$", "\\$1");
        String refererPageName = referer.replaceFirst("^.*/([^/?]*)[^/]*$", "$1");
        System.out.println("refererPageName=" + refererPageName);

//        More examples

        System.out.println("left-right".replaceAll("(.*)-(.*)", "\\2-\\1") // WRONG!!!
            ); // prints "2-1"

        System.out.println(
            "left-right".replaceAll("(.*)-(.*)", "$2-$1")   // CORRECT!
            ); // prints "right-left"

        System.out.println(
            "You want million dollar?!?".replaceAll("(\\w*) dollar", "US\\$ $1")
            ); // prints "You want US$ million?!?"

        try {
            System.out.println(
                "You want million dollar?!?".replaceAll("(\\w*) dollar", "US$ \\1")
                ); // throws IllegalArgumentException: Illegal group reference
        } catch(IllegalArgumentException iae) {
            System.err.println(iae);
        }
    }
}
