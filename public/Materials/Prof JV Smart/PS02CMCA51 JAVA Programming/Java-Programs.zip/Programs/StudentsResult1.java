// Without object-orientation (procedural programming)
// Data and operations on the data are scattered throughout the project
public class StudentsResult1
{
    static String name;
    static int[] marks;

    static void calculatePercentage() {
        float total = 0;
        for (int i = 0; i < 6; i++) {
            total += marks[i];
        }
        float percentage = total / 6.0f;
        System.out.println("name=" + name + " percentage=" + percentage);
    }

    public static void main (String[] args)
    {
        name = "Abc";
        marks = new int[6];
        marks[0]=45; marks[1]=54; marks[2]=61; marks[3]=65; marks[4]=71;  marks[5]=81;
        calculatePercentage(); // Correct result

        name = "Xyz";
        marks = new int[7];
        marks[0]=45; marks[1]=54; marks[2]=61; marks[3]=65; marks[4]=71;  marks[5]=81; marks[6]=93;
        calculatePercentage(); // WRONG result
    }

}
