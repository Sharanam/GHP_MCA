class C1
{

    String greet(String name)
    {
        return "Welcome " + name;
    }

}

class C2 extends C1
{
    String place;

    C2(String place)
    {
        this.place = place;
    }

    @Override
    String greet(String name)
    {
        StringBuilder sb = new StringBuilder();
        sb.append("Welcome ").append(name).append(" to ").append(place);
        return sb.toString();
    }

}

public class Polymorphism1
{
    public static void main (String[] args)
    {
        C1 o1 = new C1();
        System.out.println(o1.greet("Sparsh"));
        C1 o2 = new C2("India");
        System.out.println(o2.greet("Sparsh"));
    }
}
