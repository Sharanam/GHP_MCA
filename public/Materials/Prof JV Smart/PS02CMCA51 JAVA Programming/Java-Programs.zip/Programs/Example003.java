public class Example003
{
    public static void main (String[] args)
    {
       String નામ = "જિજ્ઞેશ";
       System.out.println("સ્વાગત છે, " + નામ);
    }
}
