import java.util.HashMap;

public class GenericsExample02
{
    public static void main (String[] args)
    {
        // Map Integer roll numbers to String names
        HashMap<Integer, String> rollNoNameMapping = new HashMap<>();
        rollNoNameMapping.put(1, "Qwe");
        rollNoNameMapping.put(2, "Asd");
        rollNoNameMapping.put(3, "Zxc");
        System.out.println(rollNoNameMapping.get(2));

        // Map String names to Integer ages
        HashMap<String, Integer> nameAgeMapping = new HashMap<>();
        nameAgeMapping.put("Brother", 19);
        nameAgeMapping.put("Aunt", 40);
        nameAgeMapping.put("Grandmother", 72);
        System.out.println(nameAgeMapping.get("Brother"));
        System.out.println(nameAgeMapping.get("Aunt"));

    }
}
