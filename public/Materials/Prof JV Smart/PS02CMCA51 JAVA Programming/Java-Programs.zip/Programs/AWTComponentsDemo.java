import java.awt.*;
import java.awt.event.*;

public class AWTComponentsDemo extends Frame
{

    private Label labelTextField;
    private TextField textFieldInteger;
    private Checkbox checkboxGraduate;
    private Label labelRadioButtonGroup1;
    private CheckboxGroup radioButtonGroup1;
    private Checkbox radioButtonDesktop;
    private Checkbox radioButtonLaptop;
    private Label labelRadioButtonGroup2;
    private CheckboxGroup radioButtonGroup2;
    private Checkbox radioButtonTubelight;
    private Checkbox radioButtonCFL;
    private Checkbox radioButtonLEDBulb;
    private Choice choice;
    private List list;
    private TextArea textArea;
    private Button buttonOK;
    private Button buttonTest;

    public AWTComponentsDemo()
    {
        setLayout(new FlowLayout());

        labelTextField = new Label("Enter an integer: ");
        add(labelTextField);

        textFieldInteger = new TextField(10);

        textFieldInteger.addKeyListener(new KeyListener()
        {
            @Override
            public void keyTyped(KeyEvent e)
            {
                System.out.println("textFieldInteger keyTyped: KeyChar=" + e.
                        getKeyChar());
            }

            @Override
            public void keyPressed(KeyEvent e)
            {
                System.out.println("textFieldInteger keyPressed: KeyCode=" +
                        e.getKeyCode() + " KeyChar=" + e.getKeyChar());
            }

            @Override
            public void keyReleased(KeyEvent e)
            {
                System.out.println("textFieldInteger keyReleased: KeyCode=" +
                        e.getKeyCode() + " KeyChar=" + e.getKeyChar());
            }
        });

        add(textFieldInteger);
        
        checkboxGraduate = new Checkbox("Graduate", true);
        add(checkboxGraduate);

        labelRadioButtonGroup1 = new Label("System Type: ");
        add(labelRadioButtonGroup1);

        radioButtonGroup1 = new CheckboxGroup();

        radioButtonDesktop = new Checkbox("Desktop", radioButtonGroup1, true);
        radioButtonLaptop = new Checkbox("Laptop", radioButtonGroup1, false);

        add(radioButtonDesktop);
        add(radioButtonLaptop);

        labelRadioButtonGroup2 = new Label("Lighting Type: ");
        add(labelRadioButtonGroup2);

        radioButtonGroup2 = new CheckboxGroup();

        radioButtonTubelight = new Checkbox("Tubelight", radioButtonGroup2, true);
        radioButtonCFL = new Checkbox("CFL", radioButtonGroup2, false);
        radioButtonLEDBulb = new Checkbox("LED Bulb", radioButtonGroup2, false);

        add(radioButtonTubelight);
        add(radioButtonCFL);
        add(radioButtonLEDBulb);

        choice = new Choice();
        choice.add("Mercury");
        choice.add("Venus");
        choice.add("Earth");
        choice.add("Mars");
        choice.add("Jupitor");
        choice.add("Saturn");
        choice.add("Uranus");
        choice.add("Neptune");
//        choice.select(2);
        choice.select("Earth");
        add(choice);
        
        list = new List();
        list.add("Mercury");
        list.add("Venus");
        list.add("Earth");
        list.add("Mars");
        list.add("Jupitor");
        list.add("Saturn");
        list.add("Uranus");
        list.add("Neptune");
        Dimension preferredSize = new Dimension(550, 500);
        list.setPreferredSize(preferredSize);
        list.setMultipleMode(true);
        list.select(2);
        list.select(5);
        add(list);

        textArea = new TextArea("Type here...", 5, 40);
        textArea.selectAll();
        add(textArea);
        
        MyActionListener myActionListener = new MyActionListener();

        buttonOK = new Button("OK");
        buttonOK.setActionCommand("ActionCommandOK");
        buttonOK.addActionListener(myActionListener);
        add(buttonOK);
        
        buttonTest = new Button("Test");
        buttonTest.setActionCommand("ActionCommandTest");
        buttonTest.addActionListener(myActionListener);
        add(buttonTest);
        
        
        
        setTitle("AWTComponentsDemo");
        setSize(350, 350);
        setVisible(true);
        textArea.requestFocusInWindow();
        this.addWindowListener(
                new WindowAdapter()
        {
            public void windowClosing(WindowEvent we)
            {
                dispose();
            }
        }
        );
    }

    void displayContents(ActionEvent e)
    {
        System.out.println("buttonOK ActionListener ActionCommand=" + e.getActionCommand());
        String textFieldContents = textFieldInteger.getText();
        System.out.println("textFieldContents=" + textFieldContents);
        System.out.println("Checkbox Graduate=" + checkboxGraduate.getState());
        System.out.println("RadioButton Desktop:" + radioButtonDesktop.getState());
        System.out.println("RadioButton Laptop:" + radioButtonLaptop.getState());
        System.out.println("RadioButton Tubelight:" + radioButtonTubelight.getState());
        System.out.println("RadioButton CFL:" + radioButtonCFL.getState());
        System.out.println("RadioButton LED Bulb:" + radioButtonLEDBulb.getState());
        System.out.println("Choice Planet=" + choice.getSelectedItem());
        for (String selectedItem : list.getSelectedItems())
            System.out.println("Selected Planet in the list: " + selectedItem);
        System.out.println("TextArea contents=" + textArea.getText());
    }

    class MyActionListener implements ActionListener
    {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String actionCommand = e.getActionCommand();
                System.out.println("Button pressed... actionCommand=" + actionCommand);
                switch (actionCommand)
                {
                    case "ActionCommandOK":
                    case "OK":
                        displayContents(e);
                        break;
                    case "ActionCommandTest":
                    case "Test":
                        System.out.println("Test button pressed");
                        break;
                    default:
                        System.out.println("Unknown button pressed");
                        break;
                }
            }
    }

    public static void main(String[] args)
    {
        AWTComponentsDemo frame = new AWTComponentsDemo();
    }

}
