import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Scanner;

public class RegularExpressionExample2
{
    public static void main (String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the pattern: ");
        String patternString = scanner.nextLine();
        Pattern pattern = Pattern.compile(patternString);
        String line;
        while (true)
        {
            System.out.print("Enter the string to match, q to terminate: ");
            line = scanner.nextLine();
            if (line.trim().equalsIgnoreCase("q"))
                break;
            Matcher matcher = pattern.matcher(line);
            // Match the entire input
//            if (matcher.matches())
            // Match a subsequence of the input
            if (matcher.find())
                System.out.println("Found");
            else
                System.out.println("Not found");
        }
    }
}
