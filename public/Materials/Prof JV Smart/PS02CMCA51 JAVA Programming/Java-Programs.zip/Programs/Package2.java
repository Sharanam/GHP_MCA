package com.example.jvs;

public class Package2
{

    public static void main(String[] args)
    {
        System.out.println("Package2");
    }

}
