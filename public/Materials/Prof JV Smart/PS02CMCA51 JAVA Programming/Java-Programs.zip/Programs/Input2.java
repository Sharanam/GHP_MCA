import java.util.Scanner;

public class Input2
{
    public static void main (String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a line of text: ");
        String line = scanner.nextLine();
        System.out.println("You entered: " + line);
        System.out.print("Enter the radius of the circle: ");
        double radius = scanner.nextDouble();
        System.out.println("The diameter is " + radius*2); 
        System.out.print("Enter the length of the side of the square: ");
        int side = scanner.nextInt();
        System.out.println("The area of the square is " + side * side); 
    }
}
