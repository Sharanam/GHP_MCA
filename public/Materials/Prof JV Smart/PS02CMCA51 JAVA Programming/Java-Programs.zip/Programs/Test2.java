public class Test2
{
    public static void main (String[] args)
    {
        System.out.println("Enter no1");
        int no1 = Integer.parseInt(br.readLine());
        System.out.println("Enter no2");
        int no2 = Integer.parseInt(br.readLine());
        System.out.println("Enter no3");
        int no3 = Integer.parseInt(br.readLine());
        System.out.println(no1 + no2 + no3);
    }
}
