
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

class DataAccessException extends Exception
{

    public DataAccessException(String msg)
    {
        super(msg);
    }
}

/**
 *
 * @author jvs
 */
public class JdbcMysqlAutoincrement
{

    static String schema = "testemployees";
    static String userName = "root";
    static String password = "gdcst";
    static String url = "jdbc:mysql://localhost:3306/" +
                schema + "?autoReconnect=true&useSSL=false";
    static String driver = "com.mysql.jdbc.Driver";
    static Connection con = null;

    static void insertEmployee(String pname, String pdepartment, String pdesignation, Double psalary) throws DataAccessException
    {
        String query;
        query = "insert into employees2(name, department, designation, salary) values(" +
                "'" + pname + "', '" + pdepartment
                + "', '" + pdesignation + "', " + psalary + ")";
        System.out.println("query=" + query);
        try
        {
            Statement st = con.createStatement();
            int val = st.executeUpdate(query);
            if (val != 1)
            {
                throw new DataAccessException("Insert failed.");
            }
            else
            {
                System.out.println("Data inserted successfully");
            }
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            throw new DataAccessException("Insert failed.");
        }
    }

    static int showTable() throws DataAccessException
    {
        String query;
        query = "select empno, name, department, designation, salary from employees2";
        int count = 0;
        try
        {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            System.out.println("Table Employees2");
            System.out.println("----- ----------");
            while (rs.next())
            {
                int empno = rs.getInt(1);
                String name = rs.getString(2);
                String department = rs.getString(3);
                String designation = rs.getString(4);
                double salary = rs.getDouble(5);
                String msg = String.format(
                        "| %1$3d | %2$-10s | %3$-10s | %4$-10s | %5$-10s |",
                        empno, name, department, designation, salary);
                System.out.println(msg);
                count++;
            }
            System.out.println("**** " + count + " row(s) ****");
            return count;
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            throw new DataAccessException("select failed.");
        }
    }

    public static void main(String[] args) throws Exception
    {
        try
        {
            Class.forName(driver).newInstance();
        }
        catch (ClassNotFoundException | InstantiationException |
                IllegalAccessException ex)
        {
            ex.printStackTrace();
            throw ex;
        }
        try
        {
            con = DriverManager.getConnection(url, userName, password);
        }
        catch (SQLException se)
        {
            se.printStackTrace();
        }
        try
        {
            Scanner scanner = new Scanner(System.in);
            int rowCount;

            rowCount = showTable();
            System.out.print("Press the ENTER key to continue:");
            scanner.nextLine();
            System.out.println();

            insertEmployee("aaa", "Dept111", "Desig111", 12345.67);
            rowCount = showTable();
            System.out.print("Press the ENTER key to continue:");
            scanner.nextLine();
            System.out.println();

        }
        catch (DataAccessException exc)
        {
            exc.printStackTrace();
        }
    }
}
