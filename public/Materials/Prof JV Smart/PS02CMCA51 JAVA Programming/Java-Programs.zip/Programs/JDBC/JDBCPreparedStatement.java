import java.sql.*;

public class JDBCPreparedStatement
{

   static  void insert(int cid, String name, String email, int phone) {
         try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mca","root","gdcst");
            PreparedStatement ps=cn.prepareStatement("insert into cust_info values(?,?,?,?)");
            ps.setInt(1,cid);
            ps.setString(2,name);
            ps.setString(3,email);
            ps.setInt(4,phone);
            ps.executeUpdate();
            System.out.println("Insertion successful.");
        } catch (ClassNotFoundException ex) {
           ex.printStackTrace();
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
    }

   static void update(int cid, String name, String email, int phone) {
        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mca","root","gdcst");
            PreparedStatement ps=cn.prepareStatement("update cust_info set name=?,email=?,phone=? where cid=?");
            
            ps.setString(1,name);
            ps.setString(2,email);
            ps.setInt(3,phone);
            ps.setInt(4,cid);
            ps.executeUpdate();
            System.out.println("Update sucessful.");
        } catch (ClassNotFoundException ex) {
           ex.printStackTrace();
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
        
   }

   static void delete(int cid) {
                try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mca","root","gdcst");
            PreparedStatement ps=cn.prepareStatement("delete from cust_info where cid=?");
            ps.setInt(1,cid);
            ps.executeUpdate();
            System.out.println("Deletion successful.");
        } catch (ClassNotFoundException ex) {
           ex.printStackTrace();
        } catch (SQLException ex) {
           ex.printStackTrace();
        }
   }

    public static void main (String[] args)
    {
//        insert(105, "eeee", "eee@eee.com", 55555);
//        update(105, "ffff", "fff@fff.com", 66666);
        delete(105);
    }
}
