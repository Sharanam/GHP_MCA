create database employees;

use employees;

CREATE TABLE `employees` (
  `empid` int(10) unsigned NOT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`empid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- insert some sample data
INSERT INTO `employees` (`empid`, `name`)
VALUES
    (1, 'Pankaj'),
    (2, 'David');

commit;

