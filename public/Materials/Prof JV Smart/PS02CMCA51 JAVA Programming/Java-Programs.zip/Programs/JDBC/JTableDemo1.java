import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.Scanner;

public class JTableDemo1
{

    static String schema = "testemployees";
    static String userName = "root";
    static String password = "gdcst";
    static String url = "jdbc:mysql://localhost:3306/" +
                schema + "?autoReconnect=true&useSSL=false";
    static String driver = "com.mysql.jdbc.Driver";
    static Connection con = null;
    static JFrame frame;
    static JTable jTable;
    static DefaultTableModel model;
 
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private void createAndShowGUI()
    {
        //Create and set up the window.

        frame = new JFrame("JTableDemo");
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        jTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(jTable);
        frame.add(scrollPane);

        String[] columnNames = {"Emp No", "Name", "Department", "Designation", "Salary"};
        model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);

        jTable.setModel(model);
        jTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTable.setFillsViewportHeight(true);

        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        //Display the window.
        frame.setSize(350, 350);
//        frame.pack();
        frame.setVisible(true);
    }

    static int showTable() throws DataAccessException
    {
        String query;
        query = "select empno, name, department, designation, salary from employees";
        int count = 0;
        try
        {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            System.out.println("Table Employees");
            System.out.println("----- ---------");
            while (rs.next())
            {
                int empno = rs.getInt(1);
                String name = rs.getString(2);
                String department = rs.getString(3);
                String designation = rs.getString(4);
                double salary = rs.getDouble(5);
                String msg = String.format(
                        "| %1$3d | %2$-10s | %3$-10s | %4$-10s | %5$-10s |",
                        empno, name, department, designation, salary);
                System.out.println(msg);
                count++;
                model.addRow(new Object[]{empno, name, department, designation, salary});
            }
            System.out.println("**** " + count + " row(s) ****");
            return count;
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            throw new DataAccessException("select failed.");
        }
    }

    public static void main (String[] args) throws Exception
    {
        try
        {
            Class.forName(driver).newInstance();
        }
        catch (ClassNotFoundException | InstantiationException |
                IllegalAccessException ex)
        {
            ex.printStackTrace();
            throw ex;
        }
        try
        {
            con = DriverManager.getConnection(url, userName, password);
        }
        catch (SQLException se)
        {
            se.printStackTrace();
        }
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JTableDemo1 jTableDemo1 = new JTableDemo1();
                jTableDemo1.createAndShowGUI();
                try
                {
                    showTable();
                }
                catch (DataAccessException exc)
                {
                    exc.printStackTrace();
                }
            }
        });
        
    }
}

