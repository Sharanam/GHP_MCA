﻿CREATE TABLE employees
(
  empno NUMBER NOT NULL,
  name varchar(20) NOT NULL,
  deptno varchar(20),
  designation varchar(20),
  salary NUMBER(10,2)
)
/
INSERT INTO employees(empno, name, deptno, designation, salary) values(101, 'Ankit', 1, 'Programmer', 12345.56)
/
INSERT INTO employees(empno, name, deptno, designation, salary) values(102, 'Anita', 2, 'Executive', 5345.56)
/
INSERT INTO employees(empno, name, deptno, designation, salary) values(103, 'Ashesh', 3, 'Manager', 25345.56)
/
