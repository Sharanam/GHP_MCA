
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Console;

class DataAccessException extends Exception
{

    public DataAccessException(String msg)
    {
        super(msg);
    }
}

/**
 *
 * @author jvs
 */
public class JdbcMysqlExample2
{

    static String schema = "testemployees";
    static String userName = null;
    static String password = null;
    static String url = "jdbc:mysql://localhost:3306/" +
                schema + "?autoReconnect=true&useSSL=false";
    static String driver = "com.mysql.cj.jdbc.Driver";
    static Connection connection = null;

    static void insertEmployee(int empNo, String empName, String department, String designation, Double salary) throws DataAccessException
    {
        String query;
        query = "insert into employees values(?, ?, ?, ?, ?)";
        try
        {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, empNo);
            preparedStatement.setString(2, empName);
            preparedStatement.setString(3, department);
            preparedStatement.setString(4, designation);
            preparedStatement.setDouble(5, salary);
            
            int val = preparedStatement.executeUpdate();
            if (val != 1)
            {
                throw new DataAccessException("Insert failed.");
            }
            else
            {
                System.out.println();
                System.out.println(val + " row(s) inserted.");
            }
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
            throw new DataAccessException("Insert failed.");
        }
    }

    static void updateEmployee(int empNo, String empName, String department, String designation, Double salary) throws DataAccessException
    {
        String query;
        query = "update employees set name=?, department=?, designation=?, salary=? where empno=?";
        try
        {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, empName);
            preparedStatement.setString(2, department);
            preparedStatement.setString(3, designation);
            preparedStatement.setDouble(4, salary);
            preparedStatement.setInt(5, empNo);
            int val = preparedStatement.executeUpdate();
            System.out.println();
            System.out.println(val + " row(s) updated.");
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            throw new DataAccessException("Update failed.");
        }
    }

    static void deleteEmployee(int empNo) throws DataAccessException
    {
        String query;
        query = "delete from employees where empno=?";
        try
        {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, empNo);
            int val = preparedStatement.executeUpdate();
            System.out.println();
            System.out.println(val + " row(s) deleted.");
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            throw new DataAccessException("Deletion failed.");
        }
    }

    static void showTable() throws DataAccessException
    {
        String query;
        query = "select empno, name, department, designation, salary from employees order by empno";
        int count = 0;
        try
        {
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);
            System.out.println();
            System.out.println("Table Employees");
            System.out.println("----- ---------");
            while (rs.next())
            {
                int empno = rs.getInt(1);
                String name = rs.getString(2);
                String department = rs.getString(3);
                String designation = rs.getString(4);
                double salary = rs.getDouble(5);
                String msg = String.format(
                        "| %1$3d | %2$-10s | %3$-10s | %4$-10s | %5$-10s |",
                        empno, name, department, designation, salary);
                System.out.println(msg);
                count++;
            }
            System.out.println("**** " + count + " row(s) ****");
            System.out.println();
        }
        catch (SQLException s)
        {
            s.printStackTrace();
            throw new DataAccessException("select failed.");
        }
    }

    public static void main(String[] args) throws Exception
    {
        try
        {
            Class.forName(driver).newInstance();
        }
        catch (ClassNotFoundException | InstantiationException |
                IllegalAccessException ex)
        {
            ex.printStackTrace();
            throw ex;
        }
        try
        {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter the database username: ");
            userName = br.readLine();
            Console console = System.console();
            password = new String(console.readPassword("Enter the password: "));
        } catch(IOException ioe)
        {
            ioe.printStackTrace();
        }

        try
        {
            connection = DriverManager.getConnection(url, userName, password);
        }
        catch (SQLException se)
        {
            se.printStackTrace();
        }
        try
        {
            Scanner scanner = new Scanner(System.in);

            showTable();
            System.out.print("Press the ENTER key to continue:");
            scanner.nextLine();
            System.out.println();

            insertEmployee(501, "aaa", "Dept111", "Desig111", 12345.67);
            showTable();
            System.out.print("Press the ENTER key to continue:");
            scanner.nextLine();
            System.out.println();

            updateEmployee(501, "zzz", "Deptzzz", "Desigzzz", 99999.99);
            showTable();
            System.out.print("Press the ENTER key to continue:");
            scanner.nextLine();
            System.out.println();

            deleteEmployee(501);
            showTable();
            System.out.print("Press the ENTER key to continue:");
            scanner.nextLine();
            System.out.println();

        }
        catch (DataAccessException exc)
        {
            exc.printStackTrace();
        }
    }
}
