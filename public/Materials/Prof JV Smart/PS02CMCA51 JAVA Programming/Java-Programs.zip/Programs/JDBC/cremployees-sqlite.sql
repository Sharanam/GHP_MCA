CREATE TABLE employees
(
  empno INTEGER  NOT NULL PRIMARY KEY,
  name varchar(20)  NOT NULL,
  department varchar(20) ,
  designation varchar(20) ,
  salary DOUBLE 
);
INSERT INTO employees(empno, name, department, designation, salary) values(101, 'Ankit', 'Software', 'Programmer', 12345.56);
INSERT INTO employees(empno, name, department, designation, salary) values(102, 'Anita', 'Marketing', 'Executive', 5345.56);
INSERT INTO employees(empno, name, department, designation, salary) values(103, 'Ashesh', 'Marketing', 'Manager', 25345.56);
