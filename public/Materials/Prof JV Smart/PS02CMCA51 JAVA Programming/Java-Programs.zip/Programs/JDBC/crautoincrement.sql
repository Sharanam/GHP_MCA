﻿CREATE DATABASE if not exists testemployees;
DROP TABLE if exists `testemployees`.`employees2`;
CREATE TABLE if not exists `testemployees`.`employees2`
(
  `empno` INTEGER  NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `name` varchar(20)  NOT NULL,
  `department` varchar(20) ,
  `designation` varchar(20) ,
  `salary` DOUBLE 
)
ENGINE = MyISAM;
INSERT INTO `testemployees`.`employees2`(`name`, `department`, `designation`, `salary`) values('Ankit', 'Software', 'Programmer', 12345.56);
INSERT INTO `testemployees`.`employees2`(`name`, `department`, `designation`, `salary`) values('Anita', 'Marketing', 'Executive', 5345.56);
INSERT INTO `testemployees`.`employees2`(`name`, `department`, `designation`, `salary`) values('Ashesh', 'Marketing', 'Manager', 25345.56);
