#!/bin/bash
mysql -uroot -pgdcst <cremployees.sql
