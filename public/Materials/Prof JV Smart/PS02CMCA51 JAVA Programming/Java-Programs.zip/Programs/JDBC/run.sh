#!/bin/bash
#Use MySQL Connector/J, a JDBC Type 4 driver provided by MySQL
java -classpath ".:mysql-connector-java-5.1.44-bin.jar" JdbcMysqlExample1
