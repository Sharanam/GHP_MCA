/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package loadxml;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.Stack;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

/**
 *
 * @author jvs
 */
class XMLParseException extends Exception
{
    public XMLParseException(String msg)
    {
        super(msg);
    }
}

/**
 *
 * @author jvs
 */
class DataAccessException extends Exception
{
    public DataAccessException(String msg)
    {
        super(msg);
    }
}

/**
 *
 * @author jvs
 */
public class LoadXML
{
    public static final String configFileName = "config.xml";
    boolean debug = true;
    boolean prompt = true;
    String existingDataAction = "error";
    String schema = null;
    String userName = null;
    String password = null;
    
    public void loadConfiguration() throws XMLParseException, DataAccessException
    {
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
        XMLStreamReader xMLStreamReader;
        String str, attributeName, attributeValue;
        Stack<String> elementStack = new Stack<>();
        String elename=null;
        String characters=null;
	   try
           {
               File file = new File(configFileName);
               if (!file.exists())
               {
                   System.err.println("Configuration file " + configFileName + " not found.");
                   return;
               }
               FileInputStream inputStream = new FileInputStream(file);
                xMLStreamReader = xmlInputFactory.createXMLStreamReader(inputStream);
                while (xMLStreamReader.hasNext())
                {
                    int parseEvent = xMLStreamReader.next();
                    if (parseEvent == XMLStreamReader.START_ELEMENT)
                    {
                        str = xMLStreamReader.getLocalName();
                        if (debug)
                            System.out.println("Start Element="+str);
                        elename=str;
                        elementStack.add(str);
                        int count = xMLStreamReader.getAttributeCount();
                        for (int index = 0; index < count; index++)
                        {
                            attributeName = xMLStreamReader.getAttributeLocalName(index);
                            attributeValue = xMLStreamReader.getAttributeValue(index);
                            if (debug)
                                System.out.println("attribute name=" + attributeName +
                                                                    " value="+attributeValue);
                            if (attributeName.equals("value"))
                            {
                                switch (elename)
                                {
                                    case "prompt":
                                        if (attributeValue.equalsIgnoreCase("yes"))
                                            prompt = true;
                                        else if (attributeValue.equalsIgnoreCase("no"))
                                            prompt = false;
                                        else
                                            throw new XMLParseException("Invalid attribute value " +
                                                    attributeValue + " for the element " + elename);
                                        break;
                                    case "existingdataaction":
                                        if (attributeValue.equalsIgnoreCase("keep"))
                                            existingDataAction = "keep";
                                        else if (attributeValue.equalsIgnoreCase("delete"))
                                            existingDataAction = "delete";
                                        else if (attributeValue.equalsIgnoreCase("error"))
                                            existingDataAction = "error";
                                        else
                                            throw new XMLParseException("Invalid attribute value " +
                                                    attributeValue + " for the element " + elename);
                                        break;
                                    case "debug":
                                        if (attributeValue.equalsIgnoreCase("true"))
                                            debug = true;
                                        else if (attributeValue.equalsIgnoreCase("false"))
                                            debug = false;
                                        else
                                            throw new XMLParseException("Invalid attribute value " +
                                                    attributeValue + " for the element " + elename);
                                        break;
                                    case "schemaname":
                                        schema = attributeValue;
                                        break;
                                    case "username":
                                        userName = attributeValue;
                                        break;
                                    case "password":
                                        password = attributeValue;
                                        break;
                                }
                            }
                        }
                    }
                    else if (parseEvent == XMLStreamReader.END_ELEMENT)
                    {
                        str = xMLStreamReader.getLocalName();
                        if (debug)
                            System.out.println("End Element="+str);
                        String str2 = elementStack.pop();
                        if (!str.equals(str2))
                        {
                            throw new XMLParseException("Nesting Error: Expected " + str2 + " Found " + str);
                        }
                    }
                }
                if (debug)
                {
                    System.out.println("debug=" + debug);
                    System.out.println("prompt=" + prompt);
                    System.out.println("existingDataAction=" + existingDataAction);
                    System.out.println("schema=" + schema);
                    System.out.println("userName=" + userName);
                    System.out.println("password=" + password);
                }
           }
           catch( XMLStreamException | IOException exc)
                {
                    exc.printStackTrace();
                }
    }
    
    public void loadFromXML(String pfilename) throws XMLParseException, DataAccessException
    {
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
        XMLStreamReader xMLStreamReader;
        String str, attributeName, attributeValue;
        Stack<String> elementStack = new Stack<>();
        int empno=0;
        String name=null, designation=null, department=null;
        double salary=0.0;
        String elename=null;
        String characters=null;
	   try
           {
               File file = new File(pfilename);
               FileInputStream inputStream = new FileInputStream(file);
                xMLStreamReader = xmlInputFactory.createXMLStreamReader(inputStream);
                while (xMLStreamReader.hasNext())
                {
                    int parseEvent = xMLStreamReader.next();
                    if (parseEvent == XMLStreamReader.START_ELEMENT)
                    {
                        str = xMLStreamReader.getLocalName();
                        if (debug)
                            System.out.println("Start Element="+str);
                        elename=str;
                        elementStack.add(str);
                        int count = xMLStreamReader.getAttributeCount();
                        for (int index = 0; index < count; index++)
                        {
                            attributeName = xMLStreamReader.getAttributeLocalName(index);
                            attributeValue = xMLStreamReader.getAttributeValue(index);
                            if (debug)
                                System.out.println("attribute name=" + attributeName +
                                                                    " value="+attributeValue);
                            if (attributeName.equals("empno"))
                                empno = Integer.parseInt(attributeValue);
                            Enumeration<String> enumStack = elementStack.elements();
                            str="";
                            if (enumStack.hasMoreElements())
                                str += enumStack.nextElement();
                            while (enumStack.hasMoreElements())
                                str += "." + enumStack.nextElement();
                            str += "." + attributeName;
                            if (debug)
                                System.out.println("FQN of attribute="+str);
//                            Logger.getLogger("LoadXML").info("FQN="+str);

                        }
                    }
                    else if (parseEvent == XMLStreamReader.CHARACTERS)
                    {
                        str = xMLStreamReader.getText().trim();
                        if (str.length() > 0)
                        {
//                            Logger.getLogger("LoadXML").info("CHARACTERS="+str);
                            characters = str;
                        }
                    }
                    else if (parseEvent == XMLStreamReader.END_ELEMENT)
                    {
                        str = xMLStreamReader.getLocalName();
                        if (debug)
                            System.out.println("End Element="+str);
                        String str2 = elementStack.pop();
                        if (!str.equals(str2))
                        {
                            throw new XMLParseException("Nesting Error: Expected " + str2 + " Found " + str);
                        }
                        switch(str)
                        {
                            case "name":
                                name = characters;
                                break;
                            case "department":
                                department = characters;
                                break;
                            case "designation":
                                designation = characters;
                                break;
                            case "salary":
                                salary = Double.parseDouble(characters);
                                break;
                            case "employee":
                                action(empno, name, department, designation, salary);
                                break;
                            case "employees":
                                break;
                            default:
                                throw new XMLParseException("Unknown element found: " + elename);
                        }
                    }
                }
           } catch(XMLStreamException exc)
                {
                    exc.printStackTrace();
                }
             catch(IOException ioe)
		{
                    ioe.printStackTrace();
		}
    }
    
    void action(int pempno, String pname, String pdepartment, String pdesignation, Double psalary) throws DataAccessException
    {
        String query;
        boolean choice;
        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/";
        String driver = "com.mysql.jdbc.Driver";
        query = "insert into employees values(" + pempno +
                                        ", '" + pname + "', '" + pdepartment +
                                        "', '" + pdesignation + "', " + psalary + ")";
        if (debug)
            System.out.println("query="+query);
        if (prompt)
        {
            choice = doChoice("Execute insert query?");
            if (!choice)
                return;
        }
        try
        {
                Class.forName(driver).newInstance();
                con = DriverManager.getConnection(url+schema, userName, password);
                try
                {
                        Statement st = con.createStatement();
                        int val = st.executeUpdate(query);
                        if (val != 1)
                            throw new DataAccessException("Insert failed.");
                        else
                            System.out.println("Data iseerted successfully");
                }
                catch (SQLException s){
                        if (debug)
                            s.printStackTrace();
                        throw new DataAccessException("Insert failed.");
                }
        }
        catch (Exception e){
                    if (debug)
                        e.printStackTrace();
                throw new DataAccessException("Database access failed.");
        }
    }
    
    int showTable() throws DataAccessException
    {
        String url = "jdbc:mysql://localhost:3306/";
        String driver = "com.mysql.jdbc.Driver";
        Connection con=null;
        int count = 0;
        try
        {
                Class.forName(driver).newInstance();
                con = DriverManager.getConnection(url+schema, userName, password);
                    try
                    {
                            Statement st = con.createStatement();
                            ResultSet rs = st.executeQuery("select empno, name, department, designation, salary from employees");
                            System.out.println("Table Employees");
                            System.out.println("----- ---------");
                            while (rs.next())
                            {
                                int empno = rs.getInt(1);
                                String name = rs.getString(2);
                                String department = rs.getString(3);
                                String designation = rs.getString(4);
                                double salary = rs.getDouble(5);
                                String msg = MessageFormat.format("{0}\t{1}\t{2}\t{3}\t{4}",
                                                    empno, name, department, designation, salary);
                                System.out.println(msg);
                                count++;
                            }
                            System.out.println("**** " + count + " row(s) ****");
                            return count;
                    }
                    catch (SQLException s){
                            if (debug)
                                s.printStackTrace();
                            throw new DataAccessException("select failed.");
                    }
		}
		catch (Exception e){
                            if (debug)
                                e.printStackTrace();
			throw new DataAccessException("Database access failed.");
		}
    }
 
    static boolean doChoice(String prompt)
    {
        boolean choice=false;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line = null;
        try
        {
          do
          {
              System.out.print(prompt + "(y/n): ");
              line = br.readLine().trim();
          } while (!line.equalsIgnoreCase("y") && !line.equalsIgnoreCase("n"));
        } catch (IOException ioe)
        {
            ioe.printStackTrace();
        }
        if (line.equalsIgnoreCase("y"))
            choice = true;
        return choice;
    }
    
    int checkDelete()
    {
        boolean choice;
        try
        {
            if (existingDataAction.equals("error"))
            {
                System.out.println("Cannot insert rows, table already has data");
                return 1;
            }
            else if (existingDataAction.equals("delete"))
            {
                if (debug)
                    System.out.println("query=delete from employees");
                if (prompt)
                {
                    choice = doChoice("Table already has data - execute delete query?");
                    if (!choice)
                        return 2;
                }
                String url = "jdbc:mysql://localhost:3306/";
                String driver = "com.mysql.jdbc.Driver";
                Connection con=null;
                try
                {
                    Class.forName(driver).newInstance();
                    con = DriverManager.getConnection(url+schema, userName, password);
                        try
                        {
                                Statement st = con.createStatement();
                                int val = st.executeUpdate("delete from employees");
                                System.out.println("Data deleted successfully");
                        }
                        catch (SQLException s){
                                if (debug)
                                    s.printStackTrace();
                                throw new DataAccessException("Update failed.");
                        }
                    }
                catch (Exception e){
                            if (debug)
                                e.printStackTrace();
                        throw new DataAccessException("Database access failed.");
                }
                }
        } catch (DataAccessException exc)
        {
            exc.printStackTrace();
        }
        return 0;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        if (args.length == 0)
            System.err.println("Usage: java LoadXML xmlFileName");
        else
        {
            LoadXML loadXML = new LoadXML();
            try
            {
                loadXML.loadConfiguration();
                int rowCount  = loadXML.showTable();
                if (loadXML.prompt)
                    if (!doChoice("Do you want to continue?"))
                        return;
                if (rowCount > 0)
                    if (loadXML.checkDelete() != 0)
                        return;
                loadXML.loadFromXML(args[0]);
                loadXML.showTable();
            } catch (XMLParseException | DataAccessException exc)
            {
                exc.printStackTrace();
            }
        }
    }
}
