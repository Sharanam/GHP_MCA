CREATE DATABASE if not exists testemployees;
DROP TABLE if exists `testemployees`.`employees`;
CREATE TABLE if not exists `testemployees`.`employees`
(
  `empno` INTEGER  NOT NULL PRIMARY KEY,
  `name` varchar(20)  NOT NULL,
  `department` varchar(20) ,
  `designation` varchar(20) ,
  `salary` DOUBLE 
)
ENGINE = MyISAM;
INSERT INTO `testemployees`.`employees`(`empno`, `name`, `department`, `designation`, `salary`) values(101, 'Ankit', 'Software', 'Programmer', 12345.56);
INSERT INTO `testemployees`.`employees`(`empno`, `name`, `department`, `designation`, `salary`) values(102, 'Anita', 'Marketing', 'Executive', 5345.56);
INSERT INTO `testemployees`.`employees`(`empno`, `name`, `department`, `designation`, `salary`) values(103, 'Ashesh', 'Marketing', 'Manager', 25345.56);
