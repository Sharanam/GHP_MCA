/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jignesh
 */
public class LambdaFunctions3
{
    
    @FunctionalInterface
    interface IntegerOperation
    {
        int operation(int a, int b);
        
        default int sub(int a, int b)
        {
            return a - b;
        }
        
        default String greet(String name)
        {
            return "Hello " + name;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        
        int a = 45;
        int b = 15;
        int c;
        
        IntegerOperation opadd = (int x, int y) -> x + y;
        c = opadd.operation(a, b);
        System.out.println("a + b = " + c);
        
        IntegerOperation opsub = (int x, int y) -> x - y;
        c = opsub.operation(a, b);
        System.out.println("a - b = " + c);
        
        c = opadd.sub(a, b);
        System.out.println("a - b = " + c);
        
        String name = "abc";
        String greeting;
        greeting = opadd.greet(name);
        System.out.println(greeting);
        
    }

}
