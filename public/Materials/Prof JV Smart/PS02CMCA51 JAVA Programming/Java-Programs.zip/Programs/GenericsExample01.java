import java.util.ArrayList;
import java.util.Iterator;

 public class GenericsExample01
 {
     public static void main (String[] args)
     {
         // Create an ArrayList of Integer
         ArrayList<Integer> ArrayListInteger = new ArrayList<>();
         ArrayListInteger.add(10);
         ArrayListInteger.add(20);
         ArrayListInteger.add(30);
         // iterator() in ArrayList<Integer> returns Iteretor of Integer
         Iterator<Integer> iteratorInteger = ArrayListInteger.iterator();
         while(iteratorInteger.hasNext()) {
             System.out.println(iteratorInteger.next());
         }

         // Create an ArrayList of String
         ArrayList<String> ArrayListString = new ArrayList<>();
         ArrayListString.add("aaa");
         ArrayListString.add("bbb");
         ArrayListString.add("ccc");
         ArrayListString.add("ddd");
         // iterator() in ArrayList<String> returns Iteretor of String
         Iterator<String> iteratorString = ArrayListString.iterator();
         while(iteratorString.hasNext()) {
             System.out.println(iteratorString.next());
         }
     }

 }
