import java.awt.*;
import java.awt.event.*;
 
public class AWTKeyAdapter extends Frame
{
   private Label lblInput;
   private Label lblOutput;
   private TextField tfInput;
   private TextField tfOutput;
   private int sum = 0;
 
   public AWTKeyAdapter()
   {
      setLayout(new FlowLayout());
 
      lblInput = new Label("Enter an Integer: ");
      add(lblInput);
 
      tfInput = new TextField(10);
      add(tfInput);
 
      tfInput.addKeyListener(new MyKeyAdapter());
 
      lblOutput = new Label("The Accumulated Sum is: ");
      add(lblOutput);
 
      tfOutput = new TextField(30);
      tfOutput.setEditable(false);
      add(tfOutput);
 
      setTitle("AWT Accumulator");
      setSize(400, 120);
      setVisible(true);
      this.addWindowListener(
              new WindowAdapter()
              {
                  public void windowClosing(WindowEvent we)
                  {
                        dispose();
                  }
              }
                            );
   }
 
   public static void main(String[] args)
   {
      AWTKeyAdapter frame = new AWTKeyAdapter();
   }
 
    class MyKeyAdapter extends KeyAdapter
    {
       @Override
       public void keyTyped(KeyEvent evt)
       {
           int keyCode = evt.getKeyCode();
           char keyChar = evt.getKeyChar();
           System.out.println("Key Typed: Char=" + keyChar);
           tfOutput.setText("Key Typed: Char=" + keyChar);
       }

    }

}


