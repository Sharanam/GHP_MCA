public class First
{
    public static int count = 0;

    private int id;
    private String name;

    public First()
    {
        count++;
        id = 0;
        name = null;
    }

    public First(int id, String name)
    {
        count++;
        this.id = id;
        this.name = name;
    }

    public void display()
    {
        String className = this.getClass().getName();
        System.out.println("Class name=" + className + " count=" +
                                      count + " id=" + id + " name=" + name);
//        System.out.println("id=" + this.id + " name=" + this.name);
    }

    public static void main(String[] args)
    {
//        First f1 = null;
//        System.out.println(f1.id);
        System.out.println("count=" + count);
        First f1 = new First();
//        System.out.println(f1.id);
//        System.out.println(f1.name);
        f1.display();    // display(f1);
//        First f2 = new First(2, "bbb");
//        f2.id = 2;
//        f2.name = "bbb";
        First f2 = new First(2, "bbb");
        f2.display();    // display(f2);
        Second.displayFirstMembers(f1);
//        System.out.println(id);
//        display();
    }
}
//public class Second
class Second
{
    public static void displayFirstMembers(First f)
    {
//        System.out.println("id=" + f.id + " name=" + f.name);
        f.display();
    }
}
