package org.gdcst.jigneshsmart.handleintentimage;

public class DynamicArrayOfBytes
{
	private byte[] data;
	public int length;

	public DynamicArrayOfBytes()
	{
		data = new byte[1];
		length = 1;
	}

	public DynamicArrayOfBytes(int initialSize)
	{
		data = new byte[initialSize];
		length = initialSize;
	}

	public byte get(int position)
	{
		if (position >= length)
			throw new ArrayIndexOutOfBoundsException();
		else
			return data[position];
	}

	public void put(int position, byte value)
	{
		if (position >= data.length)
		{
			int newSize = 2 * data.length;
			if (position >= newSize)
				newSize = 2 * position;
			byte[] newData = new byte[newSize];
			System.arraycopy(data, 0, newData, 0, data.length);
			data = newData;
			// System.out.println("Size of dynamic array increased to " +
			// newSize);
		}
		if (position >= length)
			length = position + 1;
		data[position] = value;
	}

	public void append(byte value)
	{
		put(length, value);
	}

	public byte[] getArray()
	{
		return data;
	}
}