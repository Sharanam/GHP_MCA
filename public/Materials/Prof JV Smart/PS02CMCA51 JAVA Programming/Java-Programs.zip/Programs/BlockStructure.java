import java.util.Scanner;

public class BlockStructure
{
    public static void main (String[] args)
    {
        System.out.print("Enter an integer: ");
        Scanner scanner = new Scanner(System.in);
        int no = scanner.nextInt();
        for (int i = 0; i < no; i++)
            System.out.println(i);
        System.out.println("*****");
        for (int i = 0; i < no; i++)
        {
            System.out.println(i);
            System.out.println("------------");
        }
        System.out.println("===== The End =====");
    }
}
