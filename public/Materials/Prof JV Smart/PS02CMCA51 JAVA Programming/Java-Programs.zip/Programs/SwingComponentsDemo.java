import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 *
 * @author class
 */
public class SwingComponentsDemo
{

    JFrame frame;
    JLabel jLabelJTextField;
    JTextField jTextField;
    JLabel jLabelJCheckBox;
    JCheckBox jCheckBox;
    JLabel jLabelJRadioButtonDesktop;
    JRadioButton jRadioButtonDesktop;
    JLabel jLabelJRadioButtonLaptop;
    JRadioButton jRadioButtonLaptop;
    JComboBox<String> jComboBox;
    JList<String> jList;
    JTextArea jTextArea;
    JButton jButton;
    JOptionPane jOptionPane;

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private void createAndShowGUI()
    {
        //Create and set up the window.

        frame = new JFrame("SwingComponentsDemo");
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        jLabelJTextField = new JLabel("Enter an integer");
        frame.add(jLabelJTextField);
        
        jTextField = new JTextField(10);
        jTextField.addKeyListener(new MyKeyAdapter());
        frame.add(jTextField);

//        jLabelJCheckBox = new JLabel("JCheckBox");
//        frame.add(jLabelJCheckBox);
        
        jCheckBox = new JCheckBox("Graduate", true);
        frame.add(jCheckBox);

        jLabelJRadioButtonDesktop = new JLabel("RadioButton Desktop");
//        frame.add(jLabelJRadioButtonDesktop);
        
        jRadioButtonDesktop = new JRadioButton("Desktop", true);
        frame.add(jRadioButtonDesktop);

//        jLabelJRadioButtonLaptop = new JLabel("RadioButton Laptop");
//        frame.add(jLabelJRadioButtonLaptop);
        
        jRadioButtonLaptop = new JRadioButton("Laptop", true);
        frame.add(jRadioButtonLaptop);

        ButtonGroup radioButtonGroup = new ButtonGroup();
        radioButtonGroup.add(jRadioButtonDesktop);
        radioButtonGroup.add(jRadioButtonLaptop);

        jComboBox = new JComboBox<>();
        jComboBox.addItem("Mercury");
        jComboBox.addItem("Venus");
        jComboBox.addItem("Earth");
        jComboBox.addItem("Mars");
        jComboBox.addItem("Jupitor");
        jComboBox.addItem("Saturn");
        jComboBox.addItem("Uranus");
        jComboBox.addItem("Neptune");
        jComboBox.setSelectedIndex(2);
        frame.add(jComboBox);

        String[] jListItems = {"Mercury", "Venus", "Earth", "Mars", "Jupitor", "Saturn", "Uranus", "Neptune",};
        jList = new JList<>(jListItems);
//      Default Value        
//        jList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
//        jList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        jList.setSelectedIndex(2);
        frame.add(jList);

        jTextArea = new JTextArea(5, 30);
        jTextArea.setText("Type here...");
        frame.add(jTextArea);
        jTextArea.selectAll();

        jButton = new JButton("OK");
        jButton.addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent e)
                    {
//                        System.out.println("Waiting...");
//                        try
//                        {
//                            Thread.sleep(20000);
//                        }
//                        catch (InterruptedException ie)
//                        {
//                        }
                        System.out.println("----------------");
                        System.out.println("TextField:" + jTextField.getText());
                        System.out.println("CheckBox:" + jCheckBox.isSelected());
                        System.out.println("RadioButton Desktop:" + jRadioButtonDesktop.isSelected());
                        System.out.println("RadioButton Laptop:" + jRadioButtonLaptop.isSelected());
                        System.out.println("ComboBox:" + jComboBox.getSelectedItem());
                        System.out.print("List selected items (indices): ");
                        for (int selectedItem : jList.getSelectedIndices())
                        {
                            System.out.print(selectedItem + " ");
                        }
                        System.out.println();
                        System.out.print("List selected items (values): ");
                        for (String selectedItem : jList.getSelectedValuesList())
                        {
                            System.out.print(selectedItem + " ");
                        }
                        System.out.println();
                        System.out.println("TextArea:" + jTextArea.getText());
                    }
                });
        frame.add(jButton);

        //Display the window.
        frame.setSize(350, 350);
//        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                SwingComponentsDemo swingComponentsDemo = new SwingComponentsDemo();
                swingComponentsDemo.createAndShowGUI();
            }
        });
    }

    class MyKeyAdapter extends KeyAdapter
    {
       @Override
       public void keyTyped(KeyEvent evt)
       {
           int keyCode = evt.getKeyCode();
           char keyChar = evt.getKeyChar();
           System.out.println("Key Typed: Char=" + keyChar);
       }
    }

}
