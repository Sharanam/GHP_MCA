public class Example002
{
    public static void main (String[] args)
    {
       System.out.println("સ્વાગત છે");
    }
}
