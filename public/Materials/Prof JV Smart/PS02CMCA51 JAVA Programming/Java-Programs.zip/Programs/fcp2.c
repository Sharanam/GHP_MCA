#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
 int in, out;
 char buf[1];
 long count = 0;
 ssize_t retval;
 if (argc != 3)
  {
   fprintf(stderr, "Usage : %s source_filename destination_filename\n", argv[0]);
   exit(1);
  }
 in=open(argv[1], O_RDONLY);
/*
 if (in == -1)
  {
   fprintf(stderr, "Could not open file %s for reading\n", argv[1]);
   exit(2);
  }
*/

 out=creat(argv[2], S_IFREG|S_IRUSR|S_IWUSR);
/*
 if (out == -1)
  {
   fprintf(stderr, "Could not open file %s for writing\n", argv[2]);
   exit(3);
  }
*/
  while ((retval=read(in, buf, 1)) == 1)
   if (write(out, buf, 1) != 1)
     {
/*
      fprintf(stderr, "Error writing to file %s\n", argv[2]);
      exit(4);
*/
     }
   else
     count++;
/*
  if (retval == -1) 
     {
      fprintf(stderr, "Error reading from file %s\n", argv[1]);
      exit(5);
     }
*/
 if (in != -1)
   close(in);
 if (out != -1)
   close(out);
 printf("File copied successfully\n");
 printf("%ld bytes copied\n", count);
 return 0;
}
