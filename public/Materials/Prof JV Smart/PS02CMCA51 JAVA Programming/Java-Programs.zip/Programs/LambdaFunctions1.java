/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jignesh
 */
public class LambdaFunctions1
{

    interface IntegerOperation
    {
        int operation(int a, int b);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        IntegerOperation add = new IntegerOperation() {
            @Override
            public int operation(int a, int b) {
                return a + b;
            }
        };
//        IntegerOperation add = (int a, int b) -> a + b;
        IntegerOperation sub = (int a, int b) -> a - b;
        IntegerOperation mul = (int a, int b) -> a * b;
        IntegerOperation div = (int a, int b) -> a / b;
        
        int a = 45;
        int b = 15;
        int c;
        
        c = add.operation(a, b);
        System.out.println("a + b = " + c);
        
        c = sub.operation(a, b);
        System.out.println("a - b = " + c);
        
        c = mul.operation(a, b);
        System.out.println("a * b = " + c);
        
        c = div.operation(a, b);
        System.out.println("a / b = " + c);
        
    }
    
}
