class Employee {
    String name;

    public Employee(String name) {
        this.name = name;
    }

    public void describeSelf() {
        System.out.println("Hi! I am an ***employee***. My name is " + name);
    }

}

class Manager extends Employee {

    public Manager(String name) {
        super(name);
    }

    @Override
    public void describeSelf() {
        System.out.println("Hi! I am a ***manager***. My name is " + name);
    }
}

public class MethodOverriding
{
    public static void main (String[] args)
    {
        Employee e1 = new Employee("Abc");
        e1.describeSelf(); // describeSelf() method called on superclass object
        Manager m1 = new Manager("Xyz");
        m1.describeSelf(); // describeSelf() method called on subclass object
    }

}

