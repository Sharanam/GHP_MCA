public class SubClassOverridingExample
{
    public static void main (String[] args)
    {
        C1 c1 = new C1();
        c1.f1();   
        c1.f2();   
        c1.f3();   

        C2 c2 = new C2();
        c2.f1();   
        c2.f2();   
        c2.f3();   

    }
}

class C1
{
    public void f1()
    {
        System.out.println("f1");
    }

    public void f2()
    {
        System.out.println("f2");
    }

    public void f3()
    {
        System.out.println("f3");
    }

}

class C2 extends C1
{

    @Override
    public void f2()
    {
        System.out.println("C2 f2");
    }
}

