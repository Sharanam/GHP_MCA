public class EnhancedForLoopExample01
{
    public static void main (String[] args)
    {
        int[] arrayInt = {10, 20, 30, 40, 50, 60, 70};

        for (int value: arrayInt) {
            System.out.println(value);
        }
    }
}
