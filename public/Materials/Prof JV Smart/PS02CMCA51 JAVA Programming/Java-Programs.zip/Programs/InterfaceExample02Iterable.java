
import java.util.Iterator;


class FirstNPrimes implements Iterable<Integer> {

    private final int numberOfPrimes;
    private final Iterator<Integer> firstNPrimesIterator;
    private int currentPrime;
    private int primeCount;
    private int nextPrime;

    public FirstNPrimes() {
        numberOfPrimes = 1;
        currentPrime = 1;
        primeCount = 1;
        firstNPrimesIterator = new FirstNPrimesIterator();
    }

    public FirstNPrimes(int numberOfPrimes) {
        if (numberOfPrimes >= 1)
            this.numberOfPrimes = numberOfPrimes;
        else
            this.numberOfPrimes = 1;
        currentPrime = 1;
        primeCount = 1;
        firstNPrimesIterator = new FirstNPrimesIterator();
    }
   
    @Override
    public Iterator<Integer> iterator() {
        return firstNPrimesIterator;
    }

    class FirstNPrimesIterator implements Iterator<Integer> {

        @Override
        public boolean hasNext() {
            if (primeCount <= numberOfPrimes) {
                return true;
            } else {
                return false;
            }
        }

        @Override
        public Integer next() {
            if (primeCount > numberOfPrimes) {
                throw new UnsupportedOperationException();
            }
            calculateNextPrime();
            primeCount++;
            currentPrime = nextPrime;
            return currentPrime;
        }

        void calculateNextPrime() {
            int next = currentPrime + 1;
            while (!checkPrime(next)) {
                next++;
            }
            nextPrime = next;
        }
        
        boolean checkPrime(int no) {
            boolean isPrime = true;
            for (int i = 2; i <= Math.sqrt(no); i++) {
                if ((no%i) == 0) {
                    isPrime = false;
                    break;
                }
            }
            return isPrime;
        }
    }
}

public class InterfaceExample02Iterable
{
    public static void main (String[] args)
    {
        FirstNPrimes first20Primes = new FirstNPrimes(20);
        for (int prime :first20Primes)
            System.out.print(prime + " ");
        System.out.println();
        
        FirstNPrimes first30Primes = new FirstNPrimes(30);
        for (int prime :first30Primes)
            System.out.print(prime + " ");
        System.out.println();
    }
}
