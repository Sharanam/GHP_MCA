public class WrapperClassExample01
{
    public static void main (String[] args)
    {
        int no = 10;
        long no2 = 400000000l;
        System.out.println(Integer.MAX_VALUE);
        if (no2 > Integer.MAX_VALUE) {
            System.out.println(no2 + " cannot fit in int");
        } else {
            System.out.println(no2 + " can fit in int");
        }

        int i1 = 10;
        float f1 = 12.34f;
        Integer integer1;
        Float float1;

        // Conversion from primitive type to wrapper class type
        integer1 = Integer.valueOf(i1);
        float1 = Float.valueOf(f1);

        // Automatic boxing
        integer1 = i1;
        float1 = f1;

        // Conversion from wrapper class type to primitive type
        i1 = integer1.intValue();
        f1 = float1.floatValue();

        // Automatic unboxing
        i1 = integer1;
        f1 = float1;

    }
}
