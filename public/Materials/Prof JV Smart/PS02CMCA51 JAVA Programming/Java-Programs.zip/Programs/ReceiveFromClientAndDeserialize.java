import java.io.Serializable;
import java.util.ArrayList;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

class Department implements Serializable
{
    static final long serialVersionUID = 42234L;  
    int deptno;
    String name;
    ArrayList<Employee> employees;
    
    public Department(int deptno, String name)
    {
        this.deptno = deptno;
        this.name = name;
        employees = new ArrayList<>();
    }
    
    public void addEmployee(Employee employee)
    {
        employees.add(employee);
    }
    
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("Department\n{\n\tdeptno=").append(
                deptno).append(",\n\tname=").append(name).append(",\n\temployees=\n\t[\n");
        for (Employee emp : employees)
        {
            sb.append("\t\t").append(emp).append("\n");
        }
        sb.append("\t]\n}");
        return sb.toString();
    }
}

class Employee implements Serializable
{
    static final long serialVersionUID = 42234L;  
    int empno;
    String name;
    char gender;
    double salary;
    
    public Employee(int empno, String name, char gender, double salary)
    {
        this.empno = empno;
        this.name = name;
        this.gender = gender;
        this.salary = salary;
    }
    
    public String toString()
    {
        return "Employee{"+empno+", "+name+", "+gender+", "+salary+"}";
    }
}

public class ReceiveFromClientAndDeserialize
{

    public static void main(String[] args)
    {
        Department dept;
        try
        {
            ServerSocket serverSocket = new ServerSocket(4444);
            System.out.println("Waiting for connection from client...");
            Socket socket = serverSocket.accept();
            System.out.println("Client connected...");
            InputStream is = socket.getInputStream();
            ObjectInputStream ois = new ObjectInputStream(is);
            dept = (Department)ois.readObject();
            System.out.println(dept);
        }
        catch (IOException ex)
        {
            System.err.println(ex.getMessage());
        }
        catch (ClassNotFoundException ex)
        {
            System.err.println(ex.getMessage());
        }
    }
}
