public class TestcastFromPrimitiveTypeToreferenceType
{
	public static void main(String[] args) throws Exception
	{
			int t = 2;
			Object l = t;
            int locationCounter = -1;
            try
            {
                locationCounter = (int)l;
				System.out.println("locationCounter="+locationCounter);
            }
            catch (ClassCastException e)
            {
                throw new Exception(
                    "Internal error: Invalid object for location counter");
            }
	}
}
