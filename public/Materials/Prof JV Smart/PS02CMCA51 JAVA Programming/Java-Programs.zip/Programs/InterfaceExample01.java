interface Discuss {
    public void speak();
    public void listen();
}

class Talk implements Discuss {
    public void speak() {
        System.out.println("Speaking to another person...");
    }

    public void listen() {
        System.out.println("Listening to another person...");
    }

    public void nod() {
        System.out.println("Nodding to another person...");
    }
}

class Chat implements Discuss {
    public void speak() {
        System.out.println("Sending message to another person...");
    }

    public void listen() {
        System.out.println("Reading message from another person...");
    }

    public void sendEmoji() {
        System.out.println("Sending emoji to another person...");
    }

}

public class InterfaceExample01
{

    public static void communicate(Discuss discussion) {
        discussion.listen();
        discussion.speak();
//        discussion.nod();
//        discussion.sendEmoji();
    }

    public static void main (String[] args)
    {
        // Interface is an abstract class
        // We cannot create instances of it
        // Discuss o1 = new Discuss();

//        Talk o1 = new Talk();
//        This is possible because Talk implements Discuss
        Discuss o1 = new Talk();
        o1.speak();
        o1.listen();
//        o1.nod();

//        Chat o2 = new Chat();
//        This is possible because Chat implements Discuss
        Discuss o2 = new Chat();
        o2.speak();
        o2.listen();
//        o2.sendEmoji();

//        o1 = new Chat();
//        o1.speak();
//        o1.listen();

        Talk t1 = new Talk();
        communicate(t1); 
        Chat c1 = new Chat();
        communicate(c1);



//        Discuss o3 = new ChatInSignLanguage();
//        communicate(o3);
    }
}

class ChatInSignLanguage implements Discuss {
    public void speak() {
        System.out.println("Saying something in sign language to another person...");
    }

    public void listen() {
        System.out.println("\"Listening\" to sign language message from another person...");
    }

    public void sendEmoji() {
        System.out.println("Sending emoji to another person...");
    }
}


