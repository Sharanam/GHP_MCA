public class UnicodeCodePoint
{
    public static void main (String[] args)
    {
        String s;
        int i;
//        s = "a";
//        s = "કખગ";
//        s = "कखग";
//        s = "યુનિકોડ તમારું સ્વાગત કરે છે";
//        s = "युनिकोड आपका स्वागत करता है";
//        s="مرحبا بكم في يونيكود!";
//        s="یونیکوڈ میں خوش آمدید";

        s = "ગુજરાતી";

        System.out.println(s.length());
        for (i = 0; i < s.length(); i++)
        {
            int codePoint = s.codePointAt(i);
//            int codePointCount = Character.charCount(codePoint);
            System.out.println(String.format("%c\tU+%04X", codePoint, codePoint));
        }
    }
}
