import java.io.Console;

interface AuthenticationMethod
{
    boolean authenticate() throws Exception;
}

class PasswordAuthentication implements AuthenticationMethod
{
    String userName;
    String password;

    PasswordAuthentication(String userName, String password)
    {
        this.userName = userName;
        this.password = password;
    }

    public boolean authenticate() throws Exception
    {
        Console console = System.console();
        String userName = console.readLine("Enter your username: ");
//        For security reasons, password should be stored in character array, not String
//        Hence, Console.readPassword() returns char[]        
        String password = new String(console.readPassword("Enter your password: "));
        if (userName != null && userName.equalsIgnoreCase(this.userName)
                && password != null && password.equals(this.password))
            return true;
        return false;
    }

}

class PinAuthentication implements AuthenticationMethod
{
    String userName;
    int pin;

    PinAuthentication(String userName, int pin)
    {
        this.userName = userName;
        this.pin = pin;
    }

    public boolean authenticate() throws Exception
    {
        Console console = System.console();
        String userName = console.readLine("Enter your username: ");
//        For security reasons, password should be stored in character array, not String
//        Hence, Console.readPassword() returns char[]        
        String pinString = new String(console.readPassword("Enter your pin: "));
        int pin = Integer.parseInt(pinString);
        if (userName != null && userName.equalsIgnoreCase(this.userName)
                && pin == this.pin)
            return true;
        return false;
    }

}

class OtpAuthentication implements AuthenticationMethod
{
    String registeredPhone;
    int otp;

    OtpAuthentication(String registerdPhone, int otp)
    {
        this.registeredPhone = registerdPhone;
        this.otp = otp;
    }

    public boolean authenticate() throws Exception
    {
        Console console = System.console();
        String registeredPhone = console.readLine("Enter your registered phone number: ");
        if (registeredPhone == null || !registeredPhone.equals(this.registeredPhone))
            return false;
//        For security reasons, password should be stored in character array, not String
//        Hence, Console.readPassword() returns char[]        
        String pinString = new String(console.readPassword("Enter the OTP sent to your registered phone: "));
        int otp = Integer.parseInt(pinString);
        if (otp == this.otp)
            return true;
        return false;
    }

}

public class Polymorphism2
{
    public static void main (String[] args) throws Exception
    {
        AuthenticationMethod authenticationMethod1 = new PasswordAuthentication("abc", "abc123");
        if (authenticationMethod1.authenticate())
            System.out.println("Login successful");
        else
            System.out.println("Invalid username or password");
        AuthenticationMethod authenticationMethod2 = new PinAuthentication("abc", 1234);
        if (authenticationMethod2.authenticate())
            System.out.println("Login successful");
        else
            System.out.println("Invalid username or password");
        AuthenticationMethod authenticationMethod3 = new OtpAuthentication("9876543210", 1234);
        if (authenticationMethod3.authenticate())
            System.out.println("Login successful");
        else
            System.out.println("Invalid registered phone number or OTP");
    }
}
