import java.awt.GridLayout;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JFrame;
import javax.swing.JLabel;

class UnicodeJFrame extends JFrame
{
    public UnicodeJFrame()
    {
        super("Demonstrating Unicode");
        setLayout(new GridLayout(10, 1)); // set frame layout

        JLabel englishJLabel = new JLabel("\u0057\u0065\u006C\u0063" +
                        "\u006F\u006D\u0065\u0020\u0074\u006F\u0020Unicode\u0021");
        englishJLabel.setToolTipText("This is English");
        add(englishJLabel);
        
        JLabel gujaratiJLabel = new JLabel("\u0AAF\u0AC1\u0AA8\u0ABF\u0A95\u0ACB" +
                                           "\u0AA1\u0020\u0AA4\u0AAE\u0ABE\u0AB0" +
                                           "\u0AC1\u0A82\u0020\u0AB8\u0ACD\u0AB5" +
                                           "\u0ABE\u0A97\u0AA4\u0020\u0A95\u0AB0" +
                                           "\u0AC7\u0020\u0A9B\u0AC7\u0021");
        gujaratiJLabel = new JLabel("યુનિકોડ તમારું સ્વાગત કરે છે!");
        gujaratiJLabel.setToolTipText("This is Gujarati");
        add(gujaratiJLabel);
        
        JLabel hindiJLabel = new JLabel("\u092F\u0941\u0928\u093F\u0915\u094B" +
                                        "\u0921\u0020\u0906\u092A\u0915\u093E" +
                                        "\u0020\u0938\u094D\u0935\u093E\u0917" +
                                        "\u0924\u0020\u0915\u0930\u0924\u093E" +
                                        "\u0020\u0939\u0948\u0021");
        hindiJLabel = new JLabel("युनिकोड आपका स्वागत करता है!");
        hindiJLabel.setToolTipText("This is Hindi");
        add(hindiJLabel);
        
        JLabel chineseJLabel = new JLabel("\u6B22\u8FCE\u4F7F\u7528" +
        "\u0020\u0020Unicode\u0021");
        chineseJLabel.setToolTipText("This is Traditional Chinese");
        add(chineseJLabel);

        JLabel cyrillicJLabel = new JLabel("\u0414\u043E\u0431\u0440" +
        "\u043E\u0020\u043F\u043E\u0436\u0430\u043B\u043E\u0432" +
        "\u0430\u0442\u044A\u0020\u0432\u0020Unicode\u0021");
        cyrillicJLabel.setToolTipText("This is Russian");
        add(cyrillicJLabel);
        
        JLabel frenchJLabel = new JLabel("\u0042\u0069\u0065\u006E\u0076" +
        "\u0065\u006E\u0075\u0065\u0020\u0061\u0075\u0020Unicode\u0021");
        frenchJLabel.setToolTipText("This is French");
        add(frenchJLabel);
        
        JLabel germanJLabel = new JLabel("\u0057\u0069\u006C\u006B\u006F" +
        "\u006D\u006D\u0065\u006E\u0020\u007A\u0075\u0020Unicode\u0021");
        germanJLabel.setToolTipText("This is German");
        add(germanJLabel);
        
        JLabel japaneseJLabel = new JLabel("Unicode\u3078\u3087\u3045" +
        "\u3053\u305D\u0021");
        japaneseJLabel.setToolTipText("This is Japanese");
        add(japaneseJLabel);
        
        JLabel portugueseJLabel = new JLabel("\u0053\u00E9\u006A\u0061" +
        "\u0020\u0042\u0065\u006D\u0076\u0069\u006E\u0064\u006F\u0020" +
        "Unicode\u0021");
        portugueseJLabel.setToolTipText("This is Portuguese");
        add(portugueseJLabel);
        
//        JLabel arabicJLabel = new JLabel("\u0645\u0631\u062D\u0628\u0627\u0020" +
//                                         "\u0628\u0643\u0645\u0020\u0641\u064A" +
//                                         "\u0020\u064A\u0648\u0646\u064A\u0643" +
//                                         "\u0648\u062F\u0021");
//        arabicJLabel = new JLabel("مرحبا بكم في يونيكود!");
//        arabicJLabel.setToolTipText("This is Arabic");
//        add(arabicJLabel);

        JLabel urduJLabel = new JLabel("\u06CC\u0648\u0646\u06CC\u06A9\u0648" +
                                       "\u0688\u0020\u0645\u06CC\u06BA\u0020" +
                                       "\u062E\u0648\u0634\u0020\u0622\u0645" +
                                       "\u062F\u06CC\u062F\u0021");
        urduJLabel = new JLabel("یونیکوڈ میں خوش آمدید!");
        urduJLabel.setToolTipText("This is Urdu");
        add(urduJLabel);

    }
}

public class UnicodeExample1
{
    public static void main( String[] args )
    {
//        UIManager.put("JLabel.font", new Font("Serif", Font.BOLD, 18));
        setUIFont (new javax.swing.plaf.FontUIResource("Sans",Font.BOLD,20));
        UnicodeJFrame unicodeJFrame = new UnicodeJFrame();
        unicodeJFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        unicodeJFrame.setSize( 450, 350 );
        unicodeJFrame.setVisible( true );
    }

    public static void setUIFont (javax.swing.plaf.FontUIResource f)
    {
        java.util.Enumeration keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements())
        {
            Object key = keys.nextElement();
            Object value = UIManager.get (key);
            if (value != null && value instanceof javax.swing.plaf.FontUIResource)
                UIManager.put (key, f);
        }
    }     
}

