import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ButtonGroup;
import javax.swing.KeyStroke;

/**
 *
 * @author class
 */
public class SwingMenuDemo implements ActionListener
{

    JFrame frame;
    JPanel contentPane;
    JButton buttonValues;
    JLabel message;

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private void createAndShowGUI() {
        //Create and set up the window.

        frame = new JFrame("SwingMenuDemo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        contentPane = new JPanel();
        frame.add(contentPane);

        JMenuBar menuBar  = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        
        fileMenu.setMnemonic('f');

        JMenuItem newMenuItem = new JMenuItem("New");
        JMenuItem openMenuItem = new JMenuItem("Open");
        JMenuItem exitMenuItem = new JMenuItem("eXit");
        exitMenuItem.setActionCommand("Exit");
        
        newMenuItem.addActionListener(this);
        openMenuItem.addActionListener(this);
        exitMenuItem.addActionListener(this);
        
        newMenuItem.setMnemonic('n');
        openMenuItem.setMnemonic('o');
        exitMenuItem.setMnemonic('x');
        
        newMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.ALT_DOWN_MASK));
//        openMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, KeyEvent.ALT_DOWN_MASK));
        openMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, KeyEvent.ALT_DOWN_MASK));
        exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, KeyEvent.ALT_DOWN_MASK));
        
        fileMenu.add(newMenuItem) ;
        fileMenu.add(openMenuItem);
        fileMenu.add(exitMenuItem) ;
        
        menuBar.add(fileMenu) ;

        JMenu secondMenu = new JMenu("Second");

        JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem("Graduate", false);
        checkBoxMenuItem.addItemListener(new ItemListener()
                {
                    public void itemStateChanged(ItemEvent e)
                    {
                        System.out.println("CheckBox in Second Menu:" + checkBoxMenuItem.isSelected());
                    }
                });

        checkBoxMenuItem.setMnemonic('g');
        checkBoxMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, KeyEvent.ALT_DOWN_MASK));

        secondMenu.add(checkBoxMenuItem);

        JRadioButtonMenuItem radioButtonMenuItemDesktop = new JRadioButtonMenuItem("Desktop", false);
        radioButtonMenuItemDesktop.addItemListener(new ItemListener()
                {
                    public void itemStateChanged(ItemEvent e)
                    {
                        System.out.println("Desktop RadioButton:" + radioButtonMenuItemDesktop.isSelected());
                    }
                });

        radioButtonMenuItemDesktop.setMnemonic('d');
        radioButtonMenuItemDesktop.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, KeyEvent.ALT_DOWN_MASK));

        JRadioButtonMenuItem radioButtonMenuItemLaptop = new JRadioButtonMenuItem("Laptop", false);
        radioButtonMenuItemLaptop.addItemListener(new ItemListener()
                {
                    public void itemStateChanged(ItemEvent e)
                    {
                        System.out.println("Laptop RadioButton:" + radioButtonMenuItemLaptop.isSelected());
                    }
                });

        radioButtonMenuItemLaptop.setMnemonic('l');

        secondMenu.add(radioButtonMenuItemLaptop);
        radioButtonMenuItemLaptop.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, KeyEvent.ALT_DOWN_MASK));

        ButtonGroup radioButtonGroup = new ButtonGroup();
        radioButtonGroup.add(radioButtonMenuItemDesktop);
        radioButtonGroup.add(radioButtonMenuItemLaptop);

        secondMenu.add(radioButtonMenuItemDesktop);
        secondMenu.add(radioButtonMenuItemLaptop);

        secondMenu.setMnemonic('s');

        menuBar.add(secondMenu);

        frame.setContentPane(contentPane);
        frame.setJMenuBar(menuBar);

        buttonValues = new JButton("Get Menu CheckBox and RadioButton Values");
        buttonValues.addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent e)
                    {
                        StringBuilder sb = new StringBuilder();
                        sb.append("CheckBox: ").append(checkBoxMenuItem.isSelected());
                        sb.append("   ");
                        sb.append("RadioButton Desktop: ").append(radioButtonMenuItemDesktop.isSelected());
                        sb.append("   ");
                        sb.append("RadioButton Laptop: ").append(radioButtonMenuItemLaptop.isSelected());
                        message.setText(sb.toString());
                    }
                });

        buttonValues.setMnemonic('g');
//        buttonValues.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, KeyEvent.ALT_DOWN_MASK));

        contentPane.add(buttonValues);

        message = new JLabel();
        message.setVisible(true);
//        message.setText("aaaaaaaa");
        contentPane.add(message);
        

        //Display the window.
        frame.setSize(600, 300);
//        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        String actionCommand = e.getActionCommand();
        System.out.println("ActionCommand="+actionCommand);
//        message.setText(actionCommand);
        switch (actionCommand)
                {
                    case "New":
                        message.setText("New");
                        break;
                    case "Open":
                        message.setText("Open");
                        break;
                    case "Exit":
                        frame.dispose();
                        break;
                        
                }
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                SwingMenuDemo swingMenuDemo = new SwingMenuDemo();
                swingMenuDemo.createAndShowGUI();
            }
        });
    }
}
