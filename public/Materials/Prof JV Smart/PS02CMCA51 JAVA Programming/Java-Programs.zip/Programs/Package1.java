package org.gdcst.package1;

public class Package1
{

    public static void main(String[] args)
    {
        System.out.println("Package1");
    }
}
