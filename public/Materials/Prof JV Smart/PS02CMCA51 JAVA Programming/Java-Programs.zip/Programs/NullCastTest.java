public class NullCastTest
{
	public static void main(String[] args)
	{
		Object o = null;
		String o2 = null;
		try
		{
			o2 = (String) o;
			System.out.println("Success");
		} catch(ClassCastException ex)
			{
				ex.printStackTrace();
			}
	}
}
