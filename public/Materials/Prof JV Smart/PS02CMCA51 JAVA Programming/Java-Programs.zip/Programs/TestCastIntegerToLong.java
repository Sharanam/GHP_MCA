public class TestCastIntegerToLong
{
 public static void main(String[] args)
 {
	Integer i = 10;
	Long l = (Long) i.longValue();
	System.out.println("l="+l);	
 }
}
