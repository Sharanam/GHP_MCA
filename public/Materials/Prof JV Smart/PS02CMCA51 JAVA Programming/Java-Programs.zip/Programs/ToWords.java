public class ToWords
{
    public static String toWords(int value) throws NumberOutOfRangeException
    {
        StringBuilder sb = new StringBuilder();
        if (value == 0)
            sb.append("zero");
        else if (value == 1)
            sb.append("one");
        else if (value == 2)
            sb.append("two");
        else if (value == 3)
            sb.append("three");
        else if (value == 4)
            sb.append("four");
        else if (value == 5)
            sb.append("five");
        else if (value == 6)
            sb.append("six");
        else if (value == 7)
            sb.append("seven");
        else if (value == 8)
            sb.append("eight");
        else if (value == 9)
            sb.append("nine");
        else if (value == 10)
            sb.append("ten");
        else if (value == 11)
            sb.append("eleven");
        else if (value == 12)
            sb.append("twelve");
        else if (value == 13)
            sb.append("thirteen");
        else if (value == 14)
            sb.append("fourteen");
        else if (value == 15)
            sb.append("fifteen");
        else if (value == 16)
            sb.append("sixteen");
        else if (value == 17)
            sb.append("seventeen");
        else if (value == 18)
            sb.append("eighteen");
        else if (value == 19)
            sb.append("nineteen");
        else if (value == 20)
            sb.append("twenty");
        else if (value == 30)
            sb.append("thirty");
        else if (value == 40)
            sb.append("forty");
        else if (value == 50)
            sb.append("fifty");
        else if (value == 60)
            sb.append("sixty");
        else if (value == 70)
            sb.append("seventy");
        else if (value == 80)
            sb.append("eighty");
        else if (value == 90)
            sb.append("ninety");
        else if (value > 20 && value < 100)
        {
            int v1 = value / 10;
            int v2 = value - v1 * 10;
            sb.append(toWords(v1 * 10)).append(" ").append(toWords(v2));
        }
        else if (value >= 100 && value < 1000)
        {
            int v1 = value / 100;
            int v2 = value - v1 * 100;
            sb.append(toWords(v1)).append(" hundred ").append(toWords(v2));
        }
        else if (value >= 1000 && value < 100000)
        {
            int v1 = value / 1000;
            int v2 = value - v1 * 1000;
            sb.append(toWords(v1)).append(" thousand ").append(toWords(v2));
        }
        else if (value >= 100000 && value < 10000000)
        {
            int v1 = value / 100000;
            int v2 = value - v1 * 100000;
            sb.append(toWords(v1)).append(" lakh ").append(toWords(v2));
        }
        else if (value < 0)
        {
            throw new NumberOutOfRangeException("ToWords.toWords() does not support negative values");
        }
        else
        {
            throw new NumberOutOfRangeException("Value " + value + " too large for ToWords.toWords()");
        }
        return sb.toString();
    }

    public static void main (String[] args)
    {
        int value = 1234567;
        try
        {
            String str = toWords(value);
            System.out.println(str);
        }
        catch (NumberOutOfRangeException ex)
        {
            System.err.println(ex.getMessage());
        }
    }
}
