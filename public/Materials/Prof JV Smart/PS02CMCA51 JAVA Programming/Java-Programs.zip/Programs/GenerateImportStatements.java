import java.util.ArrayList;
import java.util.Set;
import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;

public class GenerateImportStatements
{
    public static void main (String[] args)
    {
        ArrayList<String> classList;
        classList = new ArrayList<>();
        Properties properties = new Properties();
        GenerateImportStatements generateImportStatements = new GenerateImportStatements();
        InputStream inputStream = generateImportStatements.getClass().
            getResourceAsStream("AllClasses.properties");
        try
        {
            properties.load(inputStream);
        }
        catch (IOException ioe)
        {
            ioe.printStackTrace();
        }
        Set<String> propertyKeys = properties.stringPropertyNames();
        for (String key : propertyKeys)
        {
            classList.add(properties.getProperty(key));
        }
        for (String arg : args)
        {
            for (String className : classList)
            {
                String classNameProper = className;
                int indexOfDot = className.lastIndexOf('.');
                if (indexOfDot >= 0)
                    classNameProper = className.substring(indexOfDot+1);
               if (classNameProper.equalsIgnoreCase(arg))
                   System.out.println("import " + className);
            }
        }
    }
}
