import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SwingScrollBarDemo
{

    private JFrame mainFrame;
    private JLabel headerLabel;
    private JLabel statusLabel;

    public SwingScrollBarDemo()
    {
        prepareGUI();
    }

    public static void main(String[] args)
    {
        SwingScrollBarDemo swingControlDemo = new SwingScrollBarDemo();
    }

    private void prepareGUI()
    {
        mainFrame = new JFrame("SwingScrollBarDemo");
        mainFrame.setSize(400, 400);
        mainFrame.setLayout(new BorderLayout());

        mainFrame.addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent windowEvent)
            {
                System.exit(0);
            }
        });
        headerLabel = new JLabel("SwingScrollBarDemo");
        statusLabel = new JLabel("");
        statusLabel.setSize(350, 100);

        mainFrame.add(headerLabel, BorderLayout.NORTH);
        mainFrame.add(statusLabel, BorderLayout.CENTER);

//        initial_position, step, range
        final JScrollBar horizontalScroller = new JScrollBar(
                JScrollBar.HORIZONTAL, 20, 5, 0, 50);
        //
//        initial_position, step, range
        final JScrollBar verticalScroller = new JScrollBar(JScrollBar.VERTICAL,
                30, 10, 0, 100);
//        horizontalScroller.setMaximum(100);
//        horizontalScroller.setMinimum(0);
//        verticalScroller.setMaximum(100);
//        verticalScroller.setMinimum(0);
        statusLabel.setText("Horizontal: " +
                horizontalScroller.getValue() +
                " ,Vertical: " +
                verticalScroller.getValue());

        horizontalScroller.addAdjustmentListener(new AdjustmentListener()
        {
            @Override
            public void adjustmentValueChanged(AdjustmentEvent e)
            {
                statusLabel.setText("Horizontal: " +
                        horizontalScroller.getValue() +
                        " ,Vertical: " +
                        verticalScroller.getValue());
            }
        });
        verticalScroller.addAdjustmentListener(new AdjustmentListener()
        {
            @Override
            public void adjustmentValueChanged(AdjustmentEvent e)
            {
                statusLabel.setText("Horizontal: " +
                        horizontalScroller.getValue() +
                        " ,Vertical: " + verticalScroller.getValue());
            }
        });

        mainFrame.add(horizontalScroller, BorderLayout.SOUTH);
        mainFrame.add(verticalScroller, BorderLayout.EAST);
//        mainFrame.add(horizontalScroller, BorderLayout.NORTH);
//        mainFrame.add(verticalScroller, BorderLayout.WEST);

        mainFrame.setVisible(true);
    }

}
