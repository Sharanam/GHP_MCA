import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedReader;

// No Exception handling.
// The program cannot compile

public class ExceptionHandlingDisplayFile01
{
    public static void main (String[] args)
    {
        String inputFilename=null, line;

        if (args.length != 1)
        {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        }
        else
            inputFilename = args[0];


        if (args.length != 1)
        {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        }
        else
            inputFilename = args[0];

        File inputFile = new File(inputFilename);
        FileReader fr = new FileReader(inputFile);
        BufferedReader br = new BufferedReader(fr);
        while (true)
        {
            line = br.readLine();
            if (line == null)
                break;
            System.out.println(line);
        }
        br.close();
        fr.close();
    }
}
