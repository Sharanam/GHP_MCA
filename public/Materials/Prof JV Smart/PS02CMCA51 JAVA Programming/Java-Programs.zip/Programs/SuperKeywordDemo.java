class Person
{
    String name;

    Person()
    {
        name = "NO NAME";
    }

    Person(String name)
    {
        this.name = name;
    }

    @Override
    public String toString()
    {
        return "Person[" + name + "]";
    }
}

class Employee extends Person
{
    String designation;

//    No call to super() in this constructor
//    Default (no-argument) constructor of the parent class (Person)
//    will be called automatically
//    Error in this constructor if Person does not have
//    a default constructor    
    Employee()
    {
        designation = "NO DESIGNATION";
    }

    Employee(String name, String designation)
    {
//        super() must be the first statement in the constructor
//        If super() is not called, default (no-argument) constructor
//        of the parent class (Person) will be called. If it does not
//        exist, that would be a compilation error
        super(name);
        this.designation = designation;
    }

    @Override
    public String toString()
    {
        return "Employee[" + name + ", " + designation + "]";
    }

}

public class SuperKeywordDemo
{
    public static void main (String[] args)
    {
        Employee e1 = new Employee("aaa", "ddd");
        System.out.println(e1);
        Employee e2 = new Employee();
        System.out.println(e2);
    }

}
