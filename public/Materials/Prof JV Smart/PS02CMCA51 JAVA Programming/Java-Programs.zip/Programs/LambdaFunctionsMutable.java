import java.util.ArrayList;

public class LambdaFunctionsMutable
{
    
    @FunctionalInterface
    interface AppendOperation
    {
        ArrayList<String> appendName(ArrayList<String> a, String s);
    }

    public static void main(String[] args)
    {
        
        AppendOperation appendOperation = (x, y) -> { x.add(y); return x; };
        ArrayList<String> names = new ArrayList<>();
        appendOperation.appendName(names, "Aaa");
        appendOperation.appendName(names, "Bbb");
        appendOperation.appendName(names, "Ccc");
        for (String name : names) {
            System.out.println(name);
        }
    }

}
