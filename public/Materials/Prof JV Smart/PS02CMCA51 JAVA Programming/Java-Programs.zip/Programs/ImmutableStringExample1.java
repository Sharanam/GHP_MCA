// import java.lang.StringBuffer;
// import java.lang.StringBuilder;

public class ImmutableStringExample1
{
    public static void main (String[] args)
    {
        String s1, s2, s3, s4;

        s1 = "Programmer";
        s2 = "Programmer";
        System.out.println("1");
        System.out.println("s1=" + s1 + " s2=" + s2);
        if (s1 == s2)
            System.out.println("Both the strings are same");
        else
            System.out.println("The two strings are different");

        s1 = "Programmer";
        s2 = "Progra" + "mmer";
        System.out.println("2");
        System.out.println("s1=" + s1 + " s2=" + s2);
        if (s1 == s2)
            System.out.println("Both the strings are same");
        else
            System.out.println("The two strings are different");

        s3 = "Progra";
        s4 = "mmer";
        s1 = "Programmer";
        s2 = s3 + s4;
        System.out.println("3");
        System.out.println("s1=" + s1 + " s2=" + s2);
        if (s1 == s2)
            System.out.println("Both the strings are same");
        else
            System.out.println("The two strings are different");

        s1 = "Programmer";
        s2 = s1.substring(0, 6) + s1.substring(6, 10);
        System.out.println("4");
        System.out.println("s1=" + s1 + " s2=" + s2);
        if (s1 == s2)
            System.out.println("Both the strings are same");
        else
            System.out.println("The two strings are different");

        s1 = "Programmer";
        s2 = new String(s1);
        System.out.println("5");
        System.out.println("s1=" + s1 + " s2=" + s2);
        if (s1 == s2)
            System.out.println("Both the strings are same");
        else
            System.out.println("The two strings are different");

        s1 = "P" + "r" + "o" + "g" + "r" + "a" + "m" + "m" + "e" + "r";
        System.out.println("6");
        System.out.println("s1=" + s1);
//         StringBuffer sb = new StringBuffer();
        StringBuilder sb = new StringBuilder();
        sb.append("P");
        sb.append("r");
        sb.append("o");
        sb.append("g");
        sb.append("r");
        sb.append("a");
        sb.append("m");
        sb.append("m");
        sb.append("e");
        sb.append("r");
        s1 = sb.toString();
        System.out.println("s1=" + s1);

        sb = new StringBuilder();
        sb.append("P").append("r").append("o").append("g").append("r").append("a").append("m").append("m").append("e").append("r");
        s1 = sb.toString();
        System.out.println("s1=" + s1);
    }
}
