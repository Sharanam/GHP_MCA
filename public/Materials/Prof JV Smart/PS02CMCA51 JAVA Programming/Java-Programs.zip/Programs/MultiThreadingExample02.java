public class MultiThreadingExample02
{
    public static void main (String[] args)
    {
        System.out.println("Main thread started...");
        char[] displayCharacters = { '@', '#', '$' };
        for (int i = 0; i < displayCharacters.length; i++)
        {
            MyTask myTask = new MyTask(displayCharacters[i], i+1);
            Thread thread = new Thread(myTask);
            thread.start();
        }
        System.out.println("Main thread terminated...");
    }
}

class MyTask implements Runnable
{
    private char displayChar;
    private int delayPeriod;

    MyTask(char displayChar, int delayPeriod)
    {
        this.displayChar = displayChar;
        this.delayPeriod = delayPeriod;
    }

    @Override
    public void run()
    {
        for (int i = 1; i <= 10; i++)
        {
            System.out.print(displayChar + String.valueOf(i) + "  ");
            try
            {
                Thread.sleep(delayPeriod * 1000);
            }
            catch (InterruptedException ex)
            { 
            }
        }
        System.out.println();
    }

}

