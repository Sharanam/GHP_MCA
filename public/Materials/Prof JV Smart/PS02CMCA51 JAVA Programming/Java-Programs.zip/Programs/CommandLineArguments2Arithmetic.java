public class CommandLineArguments2Arithmetic
{
    public static void main (String[] args)
    {
        if (args.length != 3)
        {
            System.err.println(
                    "USAGE: java CommandLineArguments2Arithmetic integer1 operator integer2");
            System.exit(1);
        }
        int no1=0;
        int no2=0;
        char op='+';
        try
        {
            no1 = Integer.parseInt(args[0]);
        }
        catch (NumberFormatException ex)
        {
            System.err.println("Invalid integer " + args[0]);
            System.exit(2);
        }
        if (args[1].length() != 1)
        {
            System.err.println("Invalid operator " + args[1]);
            System.exit(3);
        }
        else
            op = args[1].charAt(0);
        try
        {
            no2 = Integer.parseInt(args[2]);
        }
        catch (NumberFormatException ex)
        {
            System.err.println("Invalid integer " + args[2]);
            System.exit(4);
        }
        int result=0;
        switch (op)
        {
            case '+':
                result = no1 + no2;
                break;
            case '-':
                result = no1 - no2;
                break;
            case '*':
                result = no1 * no2;
                break;
            case '/':
                result = no1 / no2;
                break;
            case '%':
                result = no1 % no2;
                break;
            default:
                System.err.println("Invalid operator " + args[1]);
                System.exit(5);
        }
        System.out.println(args[0] + args[1] + args[2] + "=" + result);
    }
}
