
class SuperClass
{

    String greet(String name)
    {
        return "Welcome " + name;
    }

}

class SubClass extends SuperClass
{
    String place;

    SubClass()
    {
        this.place = "India";
    }

    SubClass(String place)
    {
        this.place = place;
    }

    @Override
    String greet(String name)
    {
        StringBuilder sb = new StringBuilder();
        sb.append("Welcome ").append(name).append(" to ").append(place);
        return sb.toString();
    }

}

class UnrelatedClass {

}

public class DataTypeCheckingExample01
{
    public static void main (String[] args)
    {
//        SuperClass s1 = new SuperClass();
//        SubClass s2 = new SubClass();
        SuperClass s1 = new SubClass();
//        SuperClass s1 = new UnrelatedClass();
//        SuperClass s1 = (SuperClass)(new UnrelatedClass());
//        Object o1 = new UnrelatedClass();
//        SuperClass s1 = (SuperClass) o1;
        System.out.println("Execution successful");
    }
}
