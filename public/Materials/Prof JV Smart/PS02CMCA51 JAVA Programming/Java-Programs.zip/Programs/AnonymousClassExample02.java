public class AnonymousClassExample02
{
    public static void main (String[] args)
    {
        Thread myThread = new Thread(new Runnable() {
            public void run() {
                System.out.println("New thread started...");
                for (int i = 0; i < 10; i++) {
                    System.out.print("=");
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException ie) { }
                }
                System.out.println();
            }
        });
        myThread.start();
        for (int i = 0; i < 10; i++) {
            System.out.print("@");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ie) { }
        }
        System.out.println();
    }
}

