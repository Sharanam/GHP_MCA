// With object-orientation
// Data and operations on the data are in the same place
// (bundled in a single class)
class Student
{
    String name;
    final int SUBJECT_COUNT;
    int[] marks;

    Student(String name, final int SUBJECT_COUNT, int[] marks)
    {
        this.name = name;
        this.SUBJECT_COUNT = SUBJECT_COUNT;
        this.marks = marks;
    }

    void calculatePercentage() {
        float total = 0;
        for (int i = 0; i < SUBJECT_COUNT; i++) {
            total += marks[i];
        }
        float percentage = (float)total / SUBJECT_COUNT;
        System.out.println("name=" + name + " percentage=" + percentage);
    }

}

public class StudentsResult2
{

    public static void main (String[] args)
    {
        String name;
        int[] marks;

        name = "Abc";
        marks = new int[6];
        marks[0]=45; marks[1]=54; marks[2]=61; marks[3]=65; marks[4]=71;  marks[5]=81;
        Student student1 = new Student(name, 6, marks);
        student1.calculatePercentage(); // Correct result

        name = "Xyz";
        marks = new int[7];
        marks[0]=45; marks[1]=54; marks[2]=61; marks[3]=65; marks[4]=71;  marks[5]=81; marks[6]=93;
        Student student2 = new Student(name, 7, marks);
        student2.calculatePercentage(); // Correct result
    }
}
