import java.io.*;
import java.util.*;

public class MultiThreadingExample01
{

static void processInput(String input) {
    System.out.println("Processing input " + input + "...");
    for (int i = 0; i < 20; i++) {
        try {
            System.out.print(".");
            Thread.sleep(500);
        } catch (InterruptedException ie) {
        }
    }
    System.out.println("\nFinished processing input " + input + "...");
}

public static void main (String[] args)
{
    Scanner scanner = new Scanner(System.in);
    while(true) {
        System.out.print("Enter input(bye to quit): ");
        String input = scanner.nextLine();
        if (input.equalsIgnoreCase("bye")) {
            break;
        }
        processInput(input);
    }
}
}
