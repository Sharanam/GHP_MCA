import java.util.Optional;
import java.util.NoSuchElementException;

public class OptionalsExample1
{

    public static void main(String[] args)
    {
//        Optionals are available starting with JDK 8
        Optional<String> nullName = Optional.empty();
        Optional<String> presentName = Optional.of("aaa");
        
        String name1 = null;
        String name2 = "bbb";
        Optional<String> optionalName = Optional.ofNullable(name2);
        
        System.out.println("nullName.isPresent()=" + nullName.isPresent());
        System.out.println("presentName.isPresent()=" + presentName.isPresent());
        System.out.println("optionalName.isPresent()=" + optionalName.isPresent());
        
        String testName;
        try
        {
            testName = nullName.get();
            System.out.println("get() " + testName);
        }
        catch (NoSuchElementException ex)
        {
            System.err.println("get() " + ex.getClass().getName());
        }
        try
        {
            testName = presentName.get();
            System.out.println("get() " + testName);
        }
        catch (NoSuchElementException ex)
        {
            System.err.println("get() " + ex.getClass().getName());
        }
        try
        {
            testName = optionalName.get();
            System.out.println("get() " + testName);
        }
        catch (NoSuchElementException ex)
        {
            System.err.println("get() " + ex.getClass().getName());
        }
        

        try
        {
            testName = nullName.orElseThrow(NullPointerException::new);
            System.out.println("orElseThrow() " + testName);
        }
        catch (NullPointerException ex)
        {
            System.err.println("orElseThrow() " + ex.getClass().getName());
        }
        try
        {
            testName = presentName.orElseThrow(NullPointerException::new);
            System.out.println("orElseThrow() " + testName);
        }
        catch (NullPointerException ex)
        {
            System.err.println("orElseThrow() " + ex.getClass().getName());
        }
        try
        {
            testName = optionalName.orElseThrow(NullPointerException::new);
            System.out.println("orElseThrow() " + testName);
        }
        catch (NullPointerException ex)
        {
            System.err.println("orElseThrow() " + ex.getClass().getName());
        }
        
        System.out.println("nullName=" + nullName.orElse("NO NAME"));
        System.out.println("presentName=" + presentName.orElse("NO NAME"));
        System.out.println("optionalName=" + optionalName.orElse("NO NAME"));

        nullName.ifPresent(name ->
            { System.out.println("length of nullName=" + name.length()); });
        
        presentName.ifPresent(name ->
            { System.out.println("length of presentName=" + name.length()); });
        
        optionalName.ifPresent(name ->
            { System.out.println("length of optionalName=" + name.length()); });
        
//        Starting with JDK 9
        nullName.ifPresentOrElse(
                name -> System.out.println(
                            "nullName in uppercase=" + name.toUpperCase()),
                () -> System.out.println("nullName is null")
            );

        presentName.ifPresentOrElse(
                name -> System.out.println(
                            "presentName in uppercase=" + name.toUpperCase()),
                () -> System.out.println("presentName is null")
            );
        
        optionalName.ifPresentOrElse(
            name ->
                {
                    System.out.println("optionalName in uppercase=" + name.toUpperCase());
                },
            () ->
                {
                    System.out.println("optionalName is null");
                }
            );
        
    }
    
}
