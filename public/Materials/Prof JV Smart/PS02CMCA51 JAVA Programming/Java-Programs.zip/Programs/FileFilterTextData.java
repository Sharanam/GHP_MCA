import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class FileFilterTextData
{
    public static void main (String[] args)
    {
        if (args.length != 1)
        {
            System.err.println("USAGE: Java FileFilterTextData text-file");
            System.exit(1);
        }
        String sourceFileName = args[0];
        File sourceFile = new File(sourceFileName);
        if (!sourceFile.exists() || !sourceFile.isFile())
        {
            System.err.println("The source file " + sourceFileName +
                    " does not exist or is not a regular file");
            System.exit(2);
        }
        FileInputStream fis = null;
        int count = 0, total = 0;
        try
        {
            fis = new FileInputStream(sourceFile);
            Scanner scanner = new Scanner(fis);
            String line;
            while (scanner.hasNextLine())
            {
                line = scanner.nextLine();
//                System.out.println("line=" + line);
                String[] fields = line.split("[ ]+");
                String percentageString = fields[fields.length-1];
                percentageString = percentageString.
                    substring(0, percentageString.length()-1);
//                System.out.println(percentageString);
                int percentage = Integer.parseInt(percentageString);
                if (percentage < 80)
                {
                    System.out.println(line);
                    count++;
                }
                total++;
            }
            System.out.println(count + " out of " + total);
        }
        catch (FileNotFoundException ex)
        {
            System.err.println(ex.getMessage());
            System.exit(3);
        }
        finally
        {
            try
            {
                if (fis != null)
                    fis.close();
            }
            catch (IOException ex)
            {
            }
        }
    }
}
