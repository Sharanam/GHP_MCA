abstract class AbstractClass {

double calculatePF(double basic) {
    return basic * 10 /100;
}

abstract double calculateIncomeTax(double basic, double hra);

}

class ConcreteClass extends AbstractClass {

    @Override
    double calculateIncomeTax(double basic, double hra) {
        double pf = calculatePF(basic);
        return (basic + pf + hra)*20/100;
    }

}

public class AbstractClassExample1
{
    public static void main (String[] args)
    {
//        AbstractClass abstractClass = new AbstractClass();
        ConcreteClass concreteClass = new ConcreteClass();
        System.out.println(concreteClass.calculateIncomeTax(25000, 1500)); 
    }
}
