import javax.swing.UIManager;

public class GetAvailableLookAndFeel
{
    public static void main (String[] args)
    {
        UIManager.LookAndFeelInfo[] lafInfoList = UIManager.getInstalledLookAndFeels();
        for (UIManager.LookAndFeelInfo lafInfo : lafInfoList)
        {
            System.out.println("LAF Name=" + lafInfo.getName() +
                    " LAF class=" + lafInfo.getClassName());
        }
    }
}
