import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

/**
 *
 * @author class
 */
public class SwingAccumulator
{

    JFrame frame;
    JLabel jLabelInput;
    JTextField jTextFieldInput;
    JLabel jLabelAccumulator;
    JTextField jTextFieldAccumulator;
    int sum = 0;

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private void createAndShowGUI()
    {
        //Create and set up the window.

        frame = new JFrame("SwingAccumulator");
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        jLabelInput = new JLabel("Enter an integer");
        frame.add(jLabelInput);
        
        jTextFieldInput = new JTextField(10);
        jTextFieldInput.addActionListener(new MyActionListener());
        frame.add(jTextFieldInput);
        
        jLabelAccumulator = new JLabel("The accumulated sum is:");
        frame.add(jLabelAccumulator);
        
        jTextFieldAccumulator = new JTextField(10);
        jTextFieldAccumulator.setEnabled(false);
//        jTextFieldAccumulator.setDisabledTextColor(Color.DARK_GRAY);
        jTextFieldAccumulator.setDisabledTextColor(Color.RED);
        frame.add(jTextFieldAccumulator);

        //Display the window.
        frame.setSize(350, 350);
//        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                SwingAccumulator swingAccumulator = new SwingAccumulator();
                swingAccumulator.createAndShowGUI();
            }
        });
    }

    class MyActionListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent evt)
        {
            int numberInput = Integer.parseInt(jTextFieldInput.getText());
            sum += numberInput;
            jTextFieldAccumulator.setText(sum + "");
            jTextFieldInput.setText("");
        }
    }

}
