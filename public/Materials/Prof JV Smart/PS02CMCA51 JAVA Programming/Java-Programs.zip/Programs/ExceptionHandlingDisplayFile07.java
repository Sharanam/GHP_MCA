import java.io.FileNotFoundException;

// Checked v/s unchecked exceptions
// Does not compile successfully because
// attempt is made to catch a checked exception
// that is never thrown in the body of try

public class ExceptionHandlingDisplayFile07
{
    public static void main (String[] args)
    {
//      Throwable -> Exception -> RuntimeException
//
//      Checked exception is subclass of Exception but not subsclass of RuntimeException
//      Uncheckeed exception is subclass of Throwable, but not subclass of Exception
//      or subclass of RuntimeException, which is subclass of Exception
//
        try
        {
            System.out.println("Test...");
        }
//      Checked exception
//      Compile-time error
//      Exception is never thrown in the body        
        catch(FileNotFoundException e)
        {
            System.err.println(e);
        }
//      Unchecked exception
//      because subclass of RuntimeException
//      No compile-time error
        catch(NumberFormatException e)
        {
            System.err.println(e);
        }
    }
}
