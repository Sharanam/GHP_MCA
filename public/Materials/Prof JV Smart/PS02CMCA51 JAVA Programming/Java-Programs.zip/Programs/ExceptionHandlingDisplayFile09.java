class NegativeSalaryException extends Exception
{
    NegativeSalaryException()
    {
        super();
    }
    NegativeSalaryException(String message)
    {
        super(message);
    }

}

class Employee
{
    private String name;
    private String phoneNumber;
    private double salary;

    Employee()
    {
        name = null;
        phoneNumber = null;
        salary = -1;
    }

    Employee(String name, String phoneNumber, double salary)
    {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.salary = salary;
    }

    void paySalary() throws NegativeSalaryException
    {
        if (salary < 0)
            throw new NegativeSalaryException("Cannot pay negative salary");
        else
//            System.out.println("Paid salary of ₹" + salary + " to " + name);
            System.out.println("Paid salary of \u20B9" + salary + " to " + name);
    }

}

public class ExceptionHandlingDisplayFile09
{
    public static void main (String[] args) throws NegativeSalaryException
    {
        Employee employee1 = new Employee("Xyz", "9876543210", 12345.67);
        employee1.paySalary();
        Employee employee2 = new Employee();
        employee2.paySalary();
    }
}
