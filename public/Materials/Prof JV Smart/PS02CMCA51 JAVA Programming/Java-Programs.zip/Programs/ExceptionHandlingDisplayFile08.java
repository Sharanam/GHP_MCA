import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;

// Checked v/s unchecked exceptions
// Compiles successfully

public class ExceptionHandlingDisplayFile08
{
    public static void main (String[] args)
    {
//      Throwable -> Exception -> RuntimeException
//
//      Checked exception is subclass of Exception but not subsclass of RuntimeException
//      Uncheckeed exception is subclass of Throwable, but not subclass of Exception
//      or subclass of RuntimeException, which is subclass of Exception

        String inputFilename=null, line;

        if (args.length != 1)
        {
            System.err.println("Usage: java classname filename");
            System.exit(1);
        }
        else
            inputFilename = args[0];

        File inputFile = new File(inputFilename);
        FileReader fr;
        try
        {
            fr = new FileReader(inputFile);
            BufferedReader br = new BufferedReader(fr);
            while (true)
            {
                line = br.readLine();
                if (line == null)
                    break;
                System.out.println("line=" + line);
                int number = Integer.parseInt(line);
                System.out.println("number=" + number);
            }
            br.close();
            fr.close();
        }
        catch(FileNotFoundException e)
        {
            System.err.println("File " + inputFilename + " not found");
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
        catch(IOException e)
        {
            System.err.println("IOException " + e.getMessage());
            e.printStackTrace();
        }
    }
}
