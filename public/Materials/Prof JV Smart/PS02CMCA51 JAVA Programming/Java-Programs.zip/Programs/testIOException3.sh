#!/bin/bash
java ExceptionHandlingDisplayFile3 input
fiu-run -x -c "enable_random name=posix/io/rw/read,probability=0.05" java ExceptionHandlingDisplayFile3 input
