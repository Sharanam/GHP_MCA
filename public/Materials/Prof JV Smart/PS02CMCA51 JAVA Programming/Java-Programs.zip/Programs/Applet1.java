import java.awt.*; 
import java.applet.*;
/*
    <applet code="Applet1" width="300" height="300">
    </applet>
*/

// The above comment is for running the applet
// using appletviewer without creating an HTML file.
// Compile the Java file to create the class file; and then run
// appletviewer Applet1.java
// The appletviewer only looks for applet-related
// HTML tags in the argument file and ignores everything else

public class Applet1 extends Applet
{

    public void paint(Graphics g)
    {
        System.out.println("paint()");
        setBackground(Color.cyan);
        Font font = g.getFont().deriveFont(Font.BOLD).deriveFont(20.0f);
        g.setFont(font);
        g.drawString("First Applet", 20, 20);
    }

}

