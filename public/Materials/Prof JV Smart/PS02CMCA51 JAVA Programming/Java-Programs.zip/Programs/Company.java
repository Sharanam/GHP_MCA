class Company
{
  String name;
  int phone;
  String address;
  String city;
  boolean isImporter;
  double paymentDue;

  Company(String name, String city)
  {
    this.name = name;
    this.city = city;
  }

  Company(String name, int phone, String address, String city, boolean isImporter, double paymentDue)
  {
    this.name = name;
    this.phone = phone;
    this.address = address;
    this.city = city;
    this.isImporter = isImporter;
    this.paymentDue = paymentDue;
  }

  @Override
  public int hashCode()
  {
    int prime = 31;
    int result = 1;
    result = result * prime + ((name == null) ? 0 : name.hashCode());
    result = result * prime + ((city == null) ? 0 : city.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object other)
  {
    if (this == other)
        return true;
    if (!(other instanceof Company))
        return false;
    Company otherCompany = (Company) other;
    return 
      (
       ((name == null) 
          ? otherCompany.name == null 
          : name.equals(otherCompany.name))
       &&
       ((city == null)
          ? otherCompany.city == null
          : city.equals(otherCompany.city))
      );
  }

  @Override
  public String toString()
  {
      return name + "," + city;
  }

  public static void main (String[] args)
  {
      Company company1 = new Company("Abc Pvt. Ltd.", 2345678, "City Light Road", "Surat", false, 40000);
      Company company2 = new Company("Xyz Ltd.", 24567890, "Race Course Road", "Vadodara", true, 70000);
      Company company3 = new Company("Abc Pvt. Ltd.", 2345678, "City Light Road", "Surat", false, 40000);
      Company company4 = company2;
      if (company2 == company4)
          System.out.println("References are equal");
      else
          System.out.println("References are not equal");
      if (company1 == company3)
          System.out.println("Objects are equal");
      else
          System.out.println("Objects are not equal");
      System.out.println(company1.hashCode());
      System.out.println(company2.hashCode());
      System.out.println(company3.hashCode());
      System.out.println(company4.hashCode());
      if (company2.equals(company4))
          System.out.println("equals() returns true");
      else
          System.out.println("equals() returns false");
      if (company1.equals(company3))
          System.out.println("equals() returns true");
      else
          System.out.println("equals() returns false");
      System.out.println(company1);
      System.out.println(company2);
      System.out.println(company3);
      System.out.println(company4);
  }
}
