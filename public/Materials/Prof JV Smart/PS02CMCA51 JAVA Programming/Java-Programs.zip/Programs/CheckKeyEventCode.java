import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;

public class CheckKeyEventCode implements KeyListener {
    private JLabel label = new JLabel("Hello");
    private JPanel panel = new JPanel(new BorderLayout());
    private JFrame frame = new JFrame("CheckKeyEventCode");

    public CheckKeyEventCode() {
        panel.add("North", label);
        frame.setContentPane(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.pack();
        frame.setSize(500, 300);
        frame.setVisible(true);
        panel.addKeyListener(this);
        frame.addKeyListener(this);
        label.addKeyListener(this);
        panel.setVisible(true);

    }

    public static void main(String[] args) {
        new CheckKeyEventCode();
    }

    @Override
    public void keyPressed(KeyEvent key) {
        System.out.print("key.getExtendedKeyCode()=" + key.getExtendedKeyCode());
        System.out.print(" key.getKeyCode()=" + key.getKeyCode());
        System.out.println(" key.getModifiers()=" + key.getModifiers());
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }
}
