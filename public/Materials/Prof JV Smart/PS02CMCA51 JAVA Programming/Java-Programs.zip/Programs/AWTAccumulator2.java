import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class AWTAccumulator2 extends Frame implements ActionListener
{
    private Label lblInput;
    private Label lblOutput;
    private TextField tfInput;
    private TextField tfOutput;
    private Dialog dialog;
    private int originalSum = 0;
    private int sum = 0;

    public AWTAccumulator2()
    {
        setLayout(new FlowLayout());

        lblInput = new Label("Enter an Integer: ");
        add(lblInput);

        tfInput = new TextField(10);
        add(tfInput);

        tfInput.addActionListener(this);

        lblOutput = new Label("The Accumulated Sum is: ");
        add(lblOutput);

        tfOutput = new TextField(10);
        tfOutput.setEditable(false);
        add(tfOutput);

        try {
            File dataFile = new File("AWTAccumulator2Value.txt");
            BufferedReader br = new BufferedReader(new FileReader(dataFile));
            String line = br.readLine();
            Integer savedAccumulatorValue = Integer.parseInt(line);
            originalSum = savedAccumulatorValue;
            sum = savedAccumulatorValue;
            System.out.println("Loaded accumulator value " + savedAccumulatorValue);
            tfOutput.setText(String.valueOf(savedAccumulatorValue));
            br.close();
        } catch(FileNotFoundException ex) {
            System.out.println("Data file does not exist");
        } catch(Exception ex) {
            System.err.println("Error saving accumulator value: " + ex);
        }

        setTitle("AWT Accumulator");
        setSize(350, 350);
        setVisible(true);

        MyWindowAdapter myWindowAdapter =
            new MyWindowAdapter();
        this.addWindowListener(myWindowAdapter);

        /*
           this.addWindowListener(
           new WindowAdapter()
           {
           public void windowClosing(WindowEvent we)
           {
           dispose();
           }
           }
           );
           */

    }

    class MyWindowAdapter extends WindowAdapter
    {
        @Override
        public void windowClosing(WindowEvent we)
        {
            System.out.println("windowClosing()...");
            String accumulatorValue = tfOutput.getText();
            if (accumulatorValue.isEmpty())
                accumulatorValue = "0";
            int numberOut = Integer.parseInt(accumulatorValue);
            if (numberOut != originalSum) {
                MyDialogActionListener myDialogActionListener = new MyDialogActionListener();
                dialog = new Dialog(AWTAccumulator2.this, "Confirmation", true);
                dialog.setLayout(new FlowLayout());
                Label labelDialog = new Label("Do you want to save the accumulator value?");
                dialog.add(labelDialog);
                Button buttonYes = new Button("Yes");
                buttonYes.addActionListener(myDialogActionListener);
                dialog.add(buttonYes);
                Button buttonNo = new Button("No");
                buttonNo.addActionListener(myDialogActionListener);
                dialog.add(buttonNo);
                Button buttonCancel = new Button("Cancel");
                buttonCancel.addActionListener(myDialogActionListener);
                dialog.add(buttonCancel);
                dialog.setSize(300,100);
                dialog.setVisible(true);
            } else {
                dispose();
            }
        }

    }

    class MyDialogActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event)
        {
            String actionCommand = event.getActionCommand();
            System.out.println("Button pressed: " + actionCommand);
            switch(actionCommand) {
                case "Yes":
                    int numberOut = Integer.parseInt(tfOutput.getText());
                    try {
                        File dataFile = new File("AWTAccumulator2Value.txt");
                        PrintWriter out = new PrintWriter(new FileWriter(dataFile));
                        out.println(numberOut);
                        out.close();
                        System.out.println("Saved accumulator value " + numberOut);
                    } catch(Exception ex) {
                        System.err.println("Error saving accumulator value: " + ex);
                    }
                    dispose();
                    break;
                case "No":
                    System.out.println("Not saving accumulator value...");
                    dispose();
                    break;
                case "Cancel":
                    break;
                default:
                    System.err.println("Invalid ActionCommand in dialog");
            }
            dialog.setVisible(false);
        }


    }

    public static void main(String[] args)
    {
        AWTAccumulator2 frame = new AWTAccumulator2();
    }

    @Override
    public void actionPerformed(ActionEvent event)
    {
        String inputNumber = tfInput.getText();
        try {
            int numberIn = Integer.parseInt(inputNumber);
            sum += numberIn;
            tfOutput.setText(sum + "");
            tfInput.setText("");
        } catch(NumberFormatException nfe) {
            System.err.println("Invalid number: " + inputNumber);
        }
    }

}
