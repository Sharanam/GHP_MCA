public class AnonymousClassExample01
{
    public static void main (String[] args)
    {
        MyTask myTask = new MyTask();
        Thread myThread = new Thread(myTask);
        myThread.start();
        for (int i = 0; i < 10; i++) {
            System.out.print("@");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ie) { }
        }
        System.out.println();
    }
}

class MyTask implements Runnable {

    @Override
    public void run() {
        System.out.println("New thread started...");
        for (int i = 0; i < 10; i++) {
            System.out.print("=");
            try {
                Thread.sleep(500);
            } catch (InterruptedException ie) { }
        }
        System.out.println();
    }

}

