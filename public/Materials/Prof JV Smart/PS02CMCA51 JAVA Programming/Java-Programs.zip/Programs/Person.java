public class Person
{
  int pid;
  String name;
  String address;

  Person() {
  }
 
  Person(String name)
  {
    this.name = name;
  }

  void introduction() {
      System.out.println("I am a person. My name is " + name);
  }

  public static void main (String[] args)
  {
      Person p1 = new Person("Abc");
      p1.introduction();
      Manager m1 = new Manager("Xyz");
      m1.introduction();
  }
}

class Manager extends Person {
    Manager(String name) {
        super(name);
    }

    // Redefinition of the method introduction()
    // We are overriding the definition of introduction()
    // which we inherited from Person
  @Override
  void introduction() {
      super.introduction();
      System.out.println("I am a manager. My name is " + name);
  }

}

