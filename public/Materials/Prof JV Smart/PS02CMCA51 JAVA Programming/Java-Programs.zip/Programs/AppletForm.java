import java.awt.*; 
import java.applet.*;
/*
    <applet code="AppletForm" width="800" height="700">
    </applet>
*/

// The above comment is for running the applet
// using appletviewer without creating an HTML file.
// Compile the Java file to create the class file; and then run
// appletviewer Applet1.java
// The appletviewer only looks for applet-related
// HTML tags in the argument file and ignores everything else

public class AppletForm extends Applet
{
    public void init()
    {
        GridBagConstraints headingConstraints,labelConstraints,
                           middleConstraints, lastConstraints,
                           finalVerticalSpaceConstraints,
                           middleHorizontallyConstraints;

        headingConstraints = new GridBagConstraints();
        headingConstraints.fill = GridBagConstraints.HORIZONTAL;
        headingConstraints.anchor = GridBagConstraints.NORTHWEST;
        headingConstraints.weightx = 1;
        headingConstraints.weighty = 0.01;
        headingConstraints.gridwidth = GridBagConstraints.REMAINDER;
 
        // Set up the constraints for the "last" field in each 
        // row first, then copy and modify those constraints.

        // weightx is 1.0 for fields, 0.0 for labels
        // gridwidth is REMAINDER for fields, 1 for labels
        lastConstraints = new GridBagConstraints();

        // Components that are too short or narrow for their space
        // Should be pinned to the northwest (upper left) corner
        lastConstraints.anchor = GridBagConstraints.NORTHWEST;

        // Give the "last" component as much space as possible
        lastConstraints.weightx = 1.0;
        lastConstraints.weighty = 0.01;

        // Add a little padding
        lastConstraints.insets = new Insets(1, 1, 1, 1);

        // Now for the "middle" field components
        middleConstraints = 
             (GridBagConstraints) lastConstraints.clone();

        // Stretch components horizontally (but not vertically)
        lastConstraints.fill = GridBagConstraints.HORIZONTAL;

        // Give the "last" component the remainder of the row
        lastConstraints.gridwidth = GridBagConstraints.REMAINDER;

        // These still get as much space as possible, but do
        // not close out a row
        middleConstraints.weighty = 0.01;
        middleConstraints.gridwidth = GridBagConstraints.RELATIVE;

        middleHorizontallyConstraints = 
            (GridBagConstraints) middleConstraints.clone();
        middleHorizontallyConstraints.anchor = GridBagConstraints.PAGE_START;

        // And finally the "label" constrains, typically to be
        // used for the first component on each row
        labelConstraints = 
            (GridBagConstraints) lastConstraints.clone();

        // Give these as little space as necessary
        labelConstraints.weightx = 0.0;
        labelConstraints.gridwidth = 1;

        finalVerticalSpaceConstraints = (GridBagConstraints)headingConstraints.clone();
        finalVerticalSpaceConstraints.weighty = 1;

        setLayout(new GridBagLayout());
        Font headingFont = getFont().deriveFont(Font.BOLD).deriveFont(16.0f);

        Label labelHeading = new Label("Applet Form Demo");
        labelHeading.setFont(headingFont);
        labelHeading.setForeground(Color.RED);
        labelHeading.setAlignment(Label.CENTER);
        add(labelHeading, headingConstraints);

        Label labelBookCode = new Label("Book Code");
        labelBookCode.setAlignment(Label.RIGHT);
        add(labelBookCode, labelConstraints);
        TextField textFieldBookCode = new TextField("", 6);
        add(textFieldBookCode, middleConstraints);
        Label labelFinalBookCode = new Label("");
        add(labelFinalBookCode, lastConstraints);

        Label labelBookTitle = new Label("Book Title");
        labelBookTitle.setAlignment(Label.RIGHT);
        add(labelBookTitle, labelConstraints);
        TextField textFieldBookTitle = new TextField("", 30);
        add(textFieldBookTitle, middleConstraints);
        Label labelFinalBookTitle = new Label("");
        add(labelFinalBookTitle, lastConstraints);

        Button buttonInsert = new Button("Insert");
        add(buttonInsert, middleHorizontallyConstraints);

        Label finalVerticalSpace = new Label("");
        add(finalVerticalSpace, finalVerticalSpaceConstraints);

    }
}

