#!/bin/bash
sleep 5
(java ExceptionHandlingDisplayFile3 input)
