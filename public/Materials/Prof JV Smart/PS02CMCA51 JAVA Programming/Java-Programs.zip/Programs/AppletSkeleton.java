import java.awt.*; 
import java.applet.*;
/*
    <applet code="AppletSkeleton" width="300" height="300">
    </applet>
*/
public class AppletSkeleton extends Applet
{

    // Called first, called one time only.
    public void init()
    {
        // initialization
    }

    /* Called  after init().  Also called whenever the applet is restarted. */
    public void start()
    {
        // start or resume execution
    }

    // Called when the applet is stopped.
    public void stop()
    {
        // suspends execution
    }

    /* Called when applet is terminated.  This is the last method executed. */
    public void destroy()
    {
        // perform shutdown activities
    }

    // Called when an applet's window must be restored.
    public void paint(Graphics g)
    {
        // redisplay contents of window
    }

}

