#!/usr/bin/env python3

import sys
from gpiozero import LED
from time import sleep

# print('sys.path:')
# print(*sys.path)
# print()

led14 = LED(14)
led15 = LED(15)
led18 = LED(18)
delay=5

while True:
    print('Turning LED-14 On...')
    led14.on()
    sleep(delay)
    print('Turning LED-14 Off...')
    led14.off()
    sleep(delay)
    print('Turning LED-15 On...')
    led15.on()
    sleep(delay)
    print('Turning LED-15 Off...')
    led15.off()
    sleep(delay)
    print('Turning LED-18 On...')
    led18.on()
    sleep(delay)
    print('Turning LED-18 Off...')
    led18.off()
    sleep(delay)

