#!/usr/bin/env python3

from gpiozero import LED
from time import sleep

led = LED(14)

while True:
    print('Turning LED On...')
    led.on()
    sleep(2)
    print('Turning LED Off...')
    led.off()
    sleep(2)

