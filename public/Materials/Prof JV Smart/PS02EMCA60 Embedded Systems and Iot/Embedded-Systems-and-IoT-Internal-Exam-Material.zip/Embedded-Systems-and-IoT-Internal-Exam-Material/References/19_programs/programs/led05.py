#!/usr/bin/env python3

from gpiozero import LED
from gpiozero import RGBLED
from time import sleep

led = RGBLED(red=14, green=15, blue=18)
#led.red = 0
#led.green = 1
#led.blue = 0

delay=10

while True:
    print('led.on()')
    led.on()
    sleep(delay)
    led.off()
    print('led.blink()')
    led.blink()
    sleep(delay)
    led.off()
    print('led.color = (1, 0, 0)')
    led.color = (1, 0, 0)
    sleep(delay)
    led.off()
    print('led.color = (0, 1, 0)')
    led.color = (0, 1, 0)
    sleep(delay)
    led.off()
    print('led.color = (0, 0, 1)')
    led.color = (0, 0, 1)
    sleep(delay)
    led.off()
    print('led.color = (1, 1, 0)')
    led.color = (1, 1, 0)
    sleep(delay)
    led.off()

