'''
Control the Brightness of LED using PWM on Raspberry Pi
http://www.electronicwings.com
'''

import RPi.GPIO as GPIO
from time import sleep

redpin = 8                              # PWM pin connected to LED
greenpin = 10                           # PWM pin connected to LED
bluepin = 12                            # PWM pin connected to LED

GPIO.setwarnings(False)                 #disable warnings

GPIO.setmode(GPIO.BOARD)                #set pin numbering system
GPIO.setup(redpin,GPIO.OUT)
GPIO.setup(greenpin,GPIO.OUT)
GPIO.setup(bluepin,GPIO.OUT)

pi_pwm_red = GPIO.PWM(redpin,1000)      #create PWM instance with frequency
pi_pwm_green = GPIO.PWM(greenpin,1000)  #create PWM instance with frequency
pi_pwm_blue = GPIO.PWM(bluepin,1000)    #create PWM instance with frequency

pi_pwm_red.start(0)                     #start PWM of required Duty Cycle 
pi_pwm_green.start(0)                     #start PWM of required Duty Cycle 
pi_pwm_blue.start(0)                     #start PWM of required Duty Cycle 

while True:
    for duty in range(0,101,1):
        pi_pwm_red.ChangeDutyCycle(duty) #provide duty cycle in the range 0-100
        sleep(0.01)
    sleep(0.5)
    
    for duty in range(100,-1,-1):
        pi_pwm_red.ChangeDutyCycle(duty)
        sleep(0.01)
    sleep(0.5)

    for duty in range(0,101,1):
        pi_pwm_green.ChangeDutyCycle(duty) #provide duty cycle in the range 0-100
        sleep(0.01)
    sleep(0.5)
    
    for duty in range(100,-1,-1):
        pi_pwm_green.ChangeDutyCycle(duty)
        sleep(0.01)
    sleep(0.5)

    for duty in range(0,101,1):
        pi_pwm_blue.ChangeDutyCycle(duty) #provide duty cycle in the range 0-100
        sleep(0.01)
    sleep(0.5)
    
    for duty in range(100,-1,-1):
        pi_pwm_blue.ChangeDutyCycle(duty)
        sleep(0.01)
    sleep(0.5)

    for duty in range(0,101,1):
        pi_pwm_red.ChangeDutyCycle(duty) #provide duty cycle in the range 0-100
        pi_pwm_green.ChangeDutyCycle(duty) #provide duty cycle in the range 0-100
        pi_pwm_green.ChangeFrequency(853) #provide duty cycle in the range 0-100
        sleep(0.01)
    sleep(0.5)
    
    for duty in range(100,-1,-1):
        pi_pwm_red.ChangeDutyCycle(duty)
        pi_pwm_green.ChangeDutyCycle(duty)
        pi_pwm_green.ChangeFrequency(853) #provide duty cycle in the range 0-100
        sleep(0.01)
    sleep(0.5)


