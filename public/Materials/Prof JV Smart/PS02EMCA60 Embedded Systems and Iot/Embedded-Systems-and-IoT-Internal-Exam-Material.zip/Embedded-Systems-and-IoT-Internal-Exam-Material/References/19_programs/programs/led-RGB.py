import time, sys
import RPi.GPIO as GPIO

redPin = 8          #Set to appropriate GPIO
greenPin = 10       #Should be set in the 
bluePin = 12        #GPIO.BOARD format

def turnOn(pin):
#    print('turnOn(' + str(pin) + ')')
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.HIGH)
    
def turnOff(pin):
#    print('turnOff(' + str(pin) + ')')
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, GPIO.LOW)
    
def redOn():
    turnOn(redPin)

def redOff():
    turnOff(redPin)

def greenOn():
    turnOn(greenPin)

def greenOff():
    turnOff(greenPin)

def blueOn():
    turnOn(bluePin)

def blueOff():
    turnOff(bluePin)

def yellowOn():
    turnOn(redPin)
    turnOn(greenPin)

def yellowOff():
    turnOff(redPin)
    turnOff(greenPin)

def cyanOn():
    turnOn(greenPin)
    turnOn(bluePin)

def cyanOff():
    turnOff(greenPin)
    turnOff(bluePin)

def magentaOn():
    turnOn(redPin)
    turnOn(bluePin)

def magentaOff():
    turnOff(redPin)
    turnOff(bluePin)

def whiteOn():
    turnOn(redPin)
    turnOn(greenPin)
    turnOn(bluePin)

def whiteOff():
    turnOff(redPin)
    turnOff(greenPin)
    turnOff(bluePin)
    
print("""Ensure the following GPIO connections: R-8, G-10, B-12
Colors: Red, Green, Blue, Yellow, Cyan, Magenta, and White
Use the format: color on/color off
Use bye to quit""")

def main():
    GPIO.setwarnings(False)
    while True:
        cmd = input("-->")
#        print(cmd)
        if cmd.lower() == 'bye':
            break
        else:
#            print('cmd=' + cmd + ';')
            args = cmd.split(' ')
            color = args[0].lower()
            op = args[1].lower()
#            print(color + ':' + op)
            if color == 'red' and op == 'on':
                redOn()
            elif color == 'red' and op == 'off':
                redOff()
            elif color == 'green' and op == 'on':
                greenOn()
            elif color == 'green' and op == 'off':
                greenOff()
            elif color == 'blue' and op == 'on':
                blueOn()
            elif color == 'blue' and op == 'off':
                blueOff()
            elif color == 'cyan' and op == 'on':
                cyanOn()
            elif color == 'cyan' and op == 'off':
                cyanOff()
            elif color == 'magenta' and op == 'on':
                magentaOn()
            elif color == 'magenta' and op == 'off':
                magentaOff()
            elif color == 'yellow' and op == 'on':
                yellowOn()
            elif color == 'yellow' and op == 'off':
                yellowOff()
            elif color == 'white' and op == 'on':
                whiteOn()
            elif color == 'white' and op == 'off':
                whiteOff()
            else:
                print('command not understood')

if __name__ == '__main__':
    main()

