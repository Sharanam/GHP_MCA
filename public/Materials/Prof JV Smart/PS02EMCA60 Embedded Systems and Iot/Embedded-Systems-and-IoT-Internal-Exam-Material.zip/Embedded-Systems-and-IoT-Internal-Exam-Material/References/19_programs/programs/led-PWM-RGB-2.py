'''
Control the Brightness of LED using PWM on Raspberry Pi
http://www.electronicwings.com
'''

import RPi.GPIO as GPIO
from time import sleep

redpin = 8                              # PWM pin connected to LED
greenpin = 10                           # PWM pin connected to LED
bluepin = 12                            # PWM pin connected to LED

GPIO.setwarnings(False)                 #disable warnings

GPIO.setmode(GPIO.BOARD)                #set pin numbering system
GPIO.setup(redpin,GPIO.OUT)
GPIO.setup(greenpin,GPIO.OUT)
GPIO.setup(bluepin,GPIO.OUT)

pi_pwm_red = GPIO.PWM(redpin,1000)      #create PWM instance with frequency
pi_pwm_green = GPIO.PWM(greenpin,1000)  #create PWM instance with frequency
pi_pwm_blue = GPIO.PWM(bluepin,1000)    #create PWM instance with frequency

pi_pwm_red.start(0)                     #start PWM of required Duty Cycle 
pi_pwm_green.start(0)                   #start PWM of required Duty Cycle 
pi_pwm_blue.start(0)                    #start PWM of required Duty Cycle 

while True:
    pi_pwm_red.ChangeDutyCycle(90)          #provide duty cycle in the range 0-100
    pi_pwm_red.ChangeFrequency(999)       #provide frequency in Hz
    pi_pwm_green.ChangeDutyCycle(50)        #provide duty cycle in the range 0-100
    pi_pwm_green.ChangeFrequency(853)       #provide frequency in Hz


